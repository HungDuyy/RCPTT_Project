/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name     : test_cases.c
* Description   : Unity unit tests for RX LVD module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 24.04.2019 2.70     Test for RX72M
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "platform.h"
#include "unity_fixture.h"
#include "r_lvd_rx_if.h"        // The LVD module API interface file.
#include "r_lvd_rx_config.h"    // User configurable options for the LVD module
#include "r_lvd_rx_private.h"
#include "r_lvd_rx_private_targets.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Imported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
/* Declare test groups. */
TEST_GROUP(R_LVD_GetVersion_Test);
TEST_GROUP(R_LVD_Open_Test);
TEST_GROUP(R_LVD_Close_Test);
TEST_GROUP(R_LVD_GetStatus_Test);
TEST_GROUP(R_LVD_ClearStatus_Test);
TEST_GROUP(lvd_init_lvd_Test);
TEST_GROUP( lvd_start_lvd_Test);
TEST_GROUP(lvd_stop_int_Test);
TEST_GROUP(lvd_hw_check_param_ch_Test);
TEST_GROUP(lvd_hw_check_ptr_Test);
TEST_GROUP(lvd_hw_check_already_open_Test);
TEST_GROUP(lvd_hw_check_not_opened_Test);
TEST_GROUP(lvd_hw_check_getstatus_Test);
TEST_GROUP(lvd_hw_check_clearstatus_Test);
TEST_GROUP(lvd_hw_check_param_open_Test);
TEST_GROUP(lvd_hw_check_loco_limitation_Test);
TEST_GROUP(lvd_hw_clear_lvd_status_Test);
TEST_GROUP(lvd_hw_get_lvd_status_Test);
TEST_GROUP(lvd_hw_set_level_Test);
TEST_GROUP(lvd_hw_set_trigger_Test);
TEST_GROUP(lvd_hw_set_target_Test);
TEST_GROUP(lvd_hw_select_reset_Test);
TEST_GROUP(lvd_hw_setup_reset_Test);
TEST_GROUP(lvd_hw_select_int_Test);
TEST_GROUP(lvd_hw_select_mi_Test);
TEST_GROUP(lvd_hw_select_nmi_Test);
TEST_GROUP(lvd_hw_setup_dfilter_Test);
TEST_GROUP(lvd_hw_get_circuit_enable_Test);
TEST_GROUP(lvd_hw_get_reset_int_enable_Test);
TEST_GROUP(lvd_hw_get_dfilter_enable_Test);
TEST_GROUP(lvd_hw_enable_output_Test);
TEST_GROUP(lvd_hw_enable_circuit_Test);
TEST_GROUP(lvd_hw_enable_reset_int_Test);
TEST_GROUP(lvd_hw_enable_dfilter_Test);
TEST_GROUP(lvd_hw_enable_mi_Test);
TEST_GROUP(lvd_hw_enable_nmi_Test);
TEST_GROUP(lvd_hw_dummy_read_dfilter_Test);
TEST_GROUP(lvd_hw_dummy_read_circuit_Test);
TEST_GROUP(lvd_hw_dummy_read_output_Test);

void lvd_callback_func(void *pArgs);

/*****************************************************************************
* Function Name: lvd_callback_func
* Description  : This is a template for an LVD Async Mode callback function.
* Arguments    : pArgs -
*                    pointer to lvd_cb_args_t structure cast to a void. Structure
*                    contains event and associated data.
* Return Value : none
******************************************************************************/
void lvd_callback_func(void *pArgs)
{
	nop();
}
/***********************************************************************************************************************
* Function Name:R_LVD_GetVersion_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_LVD_GetVersion_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_LVD_GetVersion_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_LVD_GetVersion_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_LVD_GetVersion_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_R_LVD_GetVersion_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_001
* Description  : Test API function R_LVD_GetVersion()
***********************************************************************************************************************/
TEST(R_LVD_GetVersion_Test, TG001_001)
{
    TEST_ASSERT_EQUAL(0x00030014, R_LVD_GetVersion());
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetVersionTest_TG001_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_LVD_Open_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_LVD_Open_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_LVD_Open_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_LVD_Open_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_LVD_Open_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_R_LVD_Open_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_001
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_001)
{
/* Check digital channel */
/*
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 0 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 0 before executing test")
#endif
*/
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_INVALID;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_002
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_RISE;

    SYSTEM.LOCOCR.BIT.LCSTP = 0;
    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL(LVD_SUCCESS, ret);

    /* Reopen LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL(LVD_ERR_ALREADY_OPEN, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_003
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Reopen LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_ALREADY_OPEN, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_004
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, NULL, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_PTR, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_005
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_005)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, FIT_NO_PTR, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_PTR, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_006
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_006)
{
#if (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE)
    TEST_IGNORE_MESSAGE("Please set LVD_VOLTAGE_LEVEL_VALUE_CH to LVD_INVALID_VALUE before executing test")
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_007
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_007)
{
    TEST_IGNORE_MESSAGE("Ignored due to LVD_SUPPORT_DFILTER_CH1 and LVD_SUPPORT_DFILTER_CH2 are always set to LVD_ENABLE, then result_code = LVD_ERR_UNSUPPORTED (line 274 of r_lvd_rx_hw.c) could not be reached.")

#if (LVD_SUPPORT_DFILTER_CH2 != LVD_ENABLE)
    TEST_IGNORE_MESSAGE("Please set LVD_SUPPORT_DFILTER_CH2 to LVD_ENABLE before executing test")
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_UNSUPPORTED, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_008
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_008)
{
#if (LVD_CFG_ACTION_CHANNEL_1 != 2)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 2 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, FIT_NO_FUNC);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_FUNC, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_009
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_009)
{
#if (LVD_CFG_ACTION_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, NULL);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_FUNC, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_010
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_010)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_INVALID;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_ARG, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_011
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_011)
{
/* Check interrupt action */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NONE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_NONE before executing test");
#endif

/* Check the reset negation timing */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != LVD_STAB_RECOVARY)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to LVD_STAB_RECOVARY before executing test");
#endif

/* Check Digital filter */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != LVD_ENABLE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to LVD_ENABLE before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    SYSTEM.LOCOCR.BIT.LCSTP = 1;

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_LOCO_STOPPED, ret);

    SYSTEM.LOCOCR.BIT.LCSTP = 0;

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_012
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_012)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_RISE;

    ret = R_LVD_Close(channel);

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_013
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_013)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_FALL;
    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_014
* Description  : Test API function R_LVD_Open()
***********************************************************************************************************************/
TEST(R_LVD_Open_Test, TG002_014)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_BOTH;
    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_OpenTest_TG002_014
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_LVD_Close_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_LVD_Close_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_LVD_Close_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_LVD_Close_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_LVD_Close_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_R_LVD_Close_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_001
* Description  : Test API function R_LVD_Close()
***********************************************************************************************************************/
TEST(R_LVD_Close_Test, TG003_001)
{
    lvd_err_t     ret;      /* Return code */
    lvd_channel_t channel;  /* LVD channel */

    /* Data for test */
    channel = LVD_CHANNEL_1;

    /* Close LVD of specific channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_CloseTest_TG003_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_002
* Description  : Test API function R_LVD_Close()
***********************************************************************************************************************/
TEST(R_LVD_Close_Test, TG003_002)
{
    lvd_err_t     ret;      /* Return code */
    lvd_channel_t channel;  /* LVD channel */

    /* Data for test */
    channel = LVD_CHANNEL_2;

    /* Close LVD of specific channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_CloseTest_TG003_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_003
* Description  : Test API function R_LVD_Close()
***********************************************************************************************************************/
TEST(R_LVD_Close_Test, TG003_003)
{
    lvd_err_t     ret;      /* Return code */
    lvd_channel_t channel;  /* LVD channel */

    /* Data for test */
    channel = LVD_CHANNEL_INVALID;

    /* Close LVD of specific channel */
    ret = R_LVD_Close(channel);


    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_CloseTest_TG003_003
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_LVD_GetStatus_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_LVD_GetStatus_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_LVD_GetStatus_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_LVD_GetStatus_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_LVD_GetStatus_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_R_LVD_GetStatus_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_001
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_001)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD1SR.BIT.LVD1DET = 0;
    SYSTEM.LVD1SR.BIT.LVD1MON = 0;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_BELOW, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_NONE, cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_002
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_002)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD1SR.BIT.LVD1DET = 1;
    SYSTEM.LVD1SR.BIT.LVD1MON = 1;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

     /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_ABOVE, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_OVER, cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_003
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_003)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD2SR.BIT.LVD2DET = 0;
    SYSTEM.LVD2SR.BIT.LVD2MON = 0;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_BELOW, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_NONE, cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_004
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_004)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD2SR.BIT.LVD2DET = 1;
    SYSTEM.LVD2SR.BIT.LVD2MON = 1;
    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

     /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_ABOVE, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_OVER, cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_005
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_005)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_NOT_OPENED, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_006
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_006)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(LVD_CHANNEL_INVALID, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_007
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_007)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, NULL, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_008
* Description  : Test API function R_LVD_GetStatus()
***********************************************************************************************************************/
TEST(R_LVD_GetStatus_Test, TG004_008)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, NULL);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_GetStatusTest_TG004_008
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_LVD_ClearStatus_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_LVD_ClearStatus_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_LVD_ClearStatus_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_LVD_ClearStatus_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_LVD_ClearStatus_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_R_LVD_ClearStatus_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_001
* Description  : Test API function R_LVD_ClearStatus()
***********************************************************************************************************************/
TEST(R_LVD_ClearStatus_Test, TG005_001)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* LVD Configuration */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);

   /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_ClearStatusTest_TG005_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_002
* Description  : Test API function R_LVD_ClearStatus()
***********************************************************************************************************************/
TEST(R_LVD_ClearStatus_Test, TG005_002)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* LVD Configuration */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);

   /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_2);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_ClearStatusTest_TG005_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_003
* Description  : Test API function R_LVD_ClearStatus()
***********************************************************************************************************************/
TEST(R_LVD_ClearStatus_Test, TG005_003)
{
    lvd_err_t       ret;    /* Return code */

   /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_2);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_NOT_OPENED, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_ClearStatusTest_TG005_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_004
* Description  : Test API function R_LVD_ClearStatus()
***********************************************************************************************************************/
TEST(R_LVD_ClearStatus_Test, TG005_004)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* LVD Configuration */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);

   /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_INVALID);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_LVD_ClearStatusTest_TG005_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_init_lvd_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_init_lvd_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_init_lvd_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_init_lvd_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_init_lvd_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_init_lvd_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_001
* Description  : Test API function lvd_init_lvd()
***********************************************************************************************************************/
TEST(lvd_init_lvd_Test, TG006_001)
{
    lvd_err_t       ret;
    lvd_config_t    config;

    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_LVD);
    SYSTEM.LVCMPCR.BIT.LVD1E   = 0;
    SYSTEM.LVCMPCR.BIT.LVD2E   = 0;
    SYSTEM.LVDLVLR.BIT.LVD1LVL = 0;
    SYSTEM.LVDLVLR.BIT.LVD2LVL = 0;
    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_LVD);

    /* Close LVD channel */
    R_LVD_Close(LVD_CHANNEL_2);

    config.trigger = LVD_TRIGGER_RISE;
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    TEST_ASSERT_EQUAL_UINT32(11, SYSTEM.LVDLVLR.BIT.LVD1LVL);
    TEST_ASSERT_EQUAL_UINT32(11, SYSTEM.LVDLVLR.BIT.LVD2LVL);

    /* Close LVD channel */
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
* End of function TEST_lvd_init_lvdTest_TG006_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_002
* Description  : Test API function lvd_init_lvd()
***********************************************************************************************************************/
TEST(lvd_init_lvd_Test, TG006_002)
{
    lvd_err_t       ret;
    lvd_config_t    config;

    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_LVD);
    SYSTEM.LVCMPCR.BIT.LVD1E   = 1;
    SYSTEM.LVCMPCR.BIT.LVD2E   = 0;
    SYSTEM.LVDLVLR.BIT.LVD1LVL = 0;
    SYSTEM.LVDLVLR.BIT.LVD2LVL = 0;
    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_LVD);

    config.trigger = LVD_TRIGGER_RISE;
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVDLVLR.BIT.LVD1LVL);
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVDLVLR.BIT.LVD2LVL);

    /* Close LVD channel */
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
* End of function TEST_lvd_init_lvdTest_TG006_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_003
* Description  : Test API function lvd_init_lvd()
***********************************************************************************************************************/
TEST(lvd_init_lvd_Test, TG006_003)
{
    lvd_err_t       ret;
    lvd_config_t    config;

    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_LVD);
    SYSTEM.LVCMPCR.BIT.LVD1E   = 0;
    SYSTEM.LVCMPCR.BIT.LVD2E   = 1;
    SYSTEM.LVDLVLR.BIT.LVD1LVL = 0;
    SYSTEM.LVDLVLR.BIT.LVD2LVL = 0;
    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_LVD);

    config.trigger = LVD_TRIGGER_RISE;
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    TEST_ASSERT_EQUAL_UINT32(11, SYSTEM.LVDLVLR.BIT.LVD1LVL);
    TEST_ASSERT_EQUAL_UINT32(11, SYSTEM.LVDLVLR.BIT.LVD2LVL);

    /* Close LVD channel */
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
* End of function TEST_lvd_init_lvdTest_TG006_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_004
* Description  : Test API function lvd_init_lvd()
***********************************************************************************************************************/
TEST(lvd_init_lvd_Test, TG006_004)
{
    lvd_err_t       ret;
    lvd_config_t    config;

    R_BSP_RegisterProtectDisable(BSP_REG_PROTECT_LVD);
    SYSTEM.LVCMPCR.BIT.LVD1E   = 1;
    SYSTEM.LVCMPCR.BIT.LVD2E   = 1;
    SYSTEM.LVDLVLR.BIT.LVD1LVL = 0;
    SYSTEM.LVDLVLR.BIT.LVD2LVL = 0;
    R_BSP_RegisterProtectEnable(BSP_REG_PROTECT_LVD);

    /* Close LVD channel */
    R_LVD_Close(LVD_CHANNEL_2);

    config.trigger = LVD_TRIGGER_RISE;
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVDLVLR.BIT.LVD1LVL);
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVDLVLR.BIT.LVD2LVL);

    /* Close LVD channel */
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
* End of function TEST_lvd_init_lvdTest_TG006_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_start_lvd_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_start_lvd_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_start_lvd_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_start_lvd_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_start_lvd_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_start_lvd_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_001
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_001)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 0 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 0 before executing test")
#endif

/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_RESET)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_RESET before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_002
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_002)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test")
#endif
/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NMI )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_NMI before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_FALL;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_003
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_003)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test")
#endif
/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_MI )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_MI before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_BOTH;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_004
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_004)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test")
#endif
/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NONE )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_NONE before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_1;
    config.trigger = LVD_TRIGGER_BOTH;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_005
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_005)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 0 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 0 before executing test")
#endif

/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_RESET )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_RESET before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_006
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_006)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test")
#endif
/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_NMI )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_NMI before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_FALL;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_007
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_007)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test")
#endif
/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_MI )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_MI before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_BOTH;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_008
* Description  : Test API function lvd_start_lvd()
***********************************************************************************************************************/
TEST(lvd_start_lvd_Test, TG007_008)
{
/* Check digital channel */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1 )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test")
#endif
/* Check action interrupt */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_NONE )
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_NONE before executing test")
#endif

    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    channel        = LVD_CHANNEL_2;
    config.trigger = LVD_TRIGGER_BOTH;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_start_lvdTest_TG007_008
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_stop_int_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_stop_int_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_stop_int_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_stop_int_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_stop_int_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_stop_int_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_001
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_001)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_002
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_002)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_003
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_003)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_004
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_004)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_005
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_005)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_006
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_006)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_007
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_007)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_008
* Description  : Test API function lvd_stop_int()
***********************************************************************************************************************/
TEST(lvd_stop_int_Test, TG008_008)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD Channel */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD Channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_stop_intTest_TG008_008
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_param_ch_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_param_ch_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_param_ch_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_param_ch_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_param_ch_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_param_ch_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_001
* Description  : Test API function lvd_hw_check_param_ch()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_ch_Test, TG009_001)
{
/* Check if LVD_CFG_CHANNEL_1_USED is not 1 in r_lvd_rx_config.h */
#if (LVD_CFG_CHANNEL_1_USED != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_CHANNEL_1_USED to 1 before executing test")
#endif

    lvd_err_t       ret;   /* Return code*/
    lvd_config_t    config;/* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_chTest_TG009_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_002
* Description  : Test API function lvd_hw_check_param_ch()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_ch_Test, TG009_002)
{
/* Check if LVD_CFG_CHANNEL_1_USED is not 0 in r_lvd_rx_config.h */
#if (LVD_CFG_CHANNEL_1_USED != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_CHANNEL_1_USED to 0 before executing test")
#endif

    lvd_err_t       ret;   /* Return code*/
    lvd_config_t    config;/* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_chTest_TG009_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_003
* Description  : Test API function lvd_hw_check_param_ch()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_ch_Test, TG009_003)
{
/* Check if LVD_CFG_CHANNEL_2_USED is not 1 in r_lvd_rx_config.h */
#if (LVD_CFG_CHANNEL_2_USED != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_CHANNEL_2_USED to 1 before executing test")
#endif

    lvd_err_t       ret;   /* Return code*/
    lvd_config_t    config;/* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_chTest_TG009_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_004
* Description  : Test API function lvd_hw_check_param_ch()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_ch_Test, TG009_004)
{
/* Check if LVD_CFG_CHANNEL_2_USED is not 0 in r_lvd_rx_config.h */
#if (LVD_CFG_CHANNEL_2_USED != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_CHANNEL_2_USED to 0 before executing test")
#endif

    lvd_err_t       ret;   /* Return code*/
    lvd_config_t    config;/* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_chTest_TG009_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_005
* Description  : Test API function lvd_hw_check_param_ch()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_ch_Test, TG009_005)
{
    /* Set LVD_CFG_CHANNEL_1_USED = 1 in r_lvd_rx_config.h */

    /* Set LVD_CFG_CHANNEL_2_USED = 1 in r_lvd_rx_config.h */

    lvd_err_t       ret;   /* Return code*/
    lvd_config_t    config;/* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_INVALID, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_CHAN, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_chTest_TG009_005
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_ptr_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_ptr_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_ptr_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_ptr_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_ptr_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_ptr_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_001
* Description  : Test API function lvd_hw_check_ptr()
***********************************************************************************************************************/
TEST(lvd_hw_check_ptr_Test, TG010_001)
{
    lvd_err_t       ret;   /* Return code*/
    lvd_config_t    config;/* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);


    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_ptrTest_TG010_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_002
* Description  : Test API function lvd_hw_check_ptr()
***********************************************************************************************************************/
TEST(lvd_hw_check_ptr_Test, TG010_002)
{
    lvd_err_t       ret;   /* Return code*/

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, NULL, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_ptrTest_TG010_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_003
* Description  : Test API function lvd_hw_check_ptr()
***********************************************************************************************************************/
TEST(lvd_hw_check_ptr_Test, TG010_003)
{
    lvd_err_t       ret;   /* Return code*/

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, FIT_NO_PTR, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_ptrTest_TG010_003
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_already_open_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_already_open_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_already_open_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_already_open_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_already_open_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_already_open_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG011_001
* Description  : Test API function lvd_hw_check_already_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_already_open_Test, TG011_001)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* Data for test */
    config.trigger = LVD_TRIGGER_RISE;
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(LVD_CHANNEL_1);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_already_openTest_TG011_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG011_002
* Description  : Test API function lvd_hw_check_already_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_already_open_Test, TG011_002)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* Open LVD channel 1 at the first time */
    config.trigger = LVD_TRIGGER_RISE;
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);

   /* Open LVD channel 1 at the second time */
   config.trigger = LVD_TRIGGER_RISE;
   ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);


    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_ALREADY_OPEN, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(LVD_CHANNEL_1);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_already_openTest_TG011_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_not_opened_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_not_opened_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_not_opened_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_not_opened_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_not_opened_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_not_opened_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_001
* Description  : Test API function lvd_hw_check_not_opened()
***********************************************************************************************************************/
TEST(lvd_hw_check_not_opened_Test, TG012_001)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_not_openedTest_TG012_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_002
* Description  : Test API function lvd_hw_check_not_opened()
***********************************************************************************************************************/
TEST(lvd_hw_check_not_opened_Test, TG012_002)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    channel        = LVD_CHANNEL_1;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_NOT_OPENED, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_not_openedTest_TG012_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_getstatus_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_getstatus_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_getstatus_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_getstatus_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_getstatus_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_getstatus_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_001
* Description  : Test API function lvd_hw_check_getstatus()
***********************************************************************************************************************/
TEST(lvd_hw_check_getstatus_Test, TG013_001)
{
   lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_getstatusTest_TG013_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_clearstatus_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_clearstatus_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_clearstatus_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_clearstatus_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_clearstatus_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_clearstatus_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_001
* Description  : Test API function lvd_hw_check_clearstatus()
***********************************************************************************************************************/
TEST(lvd_hw_check_clearstatus_Test, TG014_001)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* LVD Configuration */
    config.trigger = LVD_TRIGGER_RISE;

    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);

   /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD Channel */
    ret = R_LVD_Close(LVD_CHANNEL_1);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_clearstatusTest_TG014_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_param_open_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_param_open_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_param_open_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_param_open_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_param_open_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_param_open_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_001
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_target = LVD_VDET_TARGET_INVALID;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_002
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_target = LVD_VDET_TARGET_CMPA;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_UNSUPPORTED, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_003
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_voltage_level_value = LVD_INVALID_VALUE;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_004
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_dfilter = LVD_ENABLE_INVALID;

    cfg_opt.lvd_dfilter_div_value = LVD_INVALID_VALUE;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_005
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_005)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_INVALID;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_006
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_006)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_RESET;

     cfg_opt.lvd_reset_negate = LVD_STAB_INVALID;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_007
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_007)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_MI;

     cfg_opt.lvd_int_prio = 16;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_008
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_008)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_MI;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, NULL, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_FUNC, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_009
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_009)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_MI;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, FIT_NO_FUNC, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_FUNC, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_010
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_010)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_NMI;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, NULL, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_FUNC, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_011
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_011)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    cfg_opt.lvd_action = LVD_ACTION_NMI;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, FIT_NO_FUNC, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_FUNC, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_012
* Description  : Test API function lvd_hw_check_param_open()
***********************************************************************************************************************/
TEST(lvd_hw_check_param_open_Test, TG015_012)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_cfg_opt_t   cfg_opt;/* LVD Configuration Option */

    /* LVD Configuration Option Default Values */
    cfg_opt.lvd_ch_used              = LVD_CFG_CHANNEL_1_USED;
    cfg_opt.lvd_target               = LVD_CFG_VDET_TARGET_CHANNEL_1;
    cfg_opt.lvd_voltage_level_value  = 11;
    cfg_opt.lvd_dfilter              = LVD_CFG_DIGITAL_FILTER_CHANNEL_1;
    cfg_opt.lvd_dfilter_div_value    = 0;
    cfg_opt.lvd_delay_dfilter_enable = 7;
    cfg_opt.lvd_action               = LVD_CFG_ACTION_CHANNEL_1;
    cfg_opt.lvd_int_prio             = LVD_CFG_INT_PRIORITY_CHANNEL_1;
    cfg_opt.lvd_reset_negate         = LVD_CFG_STABILIZATION_CHANNEL_1;

    /* LVD Configuration Default Value */
    config.trigger                   = LVD_TRIGGER_RISE;

    config.trigger = LVD_TRIGGER_INVALID;

    ret = lvd_hw_check_param_open(LVD_CHANNEL_1, &config, lvd_callback_func, &cfg_opt);

    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_ARG, ret);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_param_open_Test_TG015_012
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_check_loco_limitation_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_check_loco_limitation_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_loco_limitation_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_check_loco_limitation_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_check_loco_limitation_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_check_loco_limitation_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_001
* Description  : Test API function lvd_hw_check_loco_limitation()
***********************************************************************************************************************/
TEST(lvd_hw_check_loco_limitation_Test, TG016_001)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 0;

    /* Set p_cfg_opt->lvd_action = LVD_ACTION_RESET */
    /* Set p_cfg_opt->lvd_reset_negate = LVD_STAB_RESET_ASSERT */
    /* Set p_cfg_opt->lvd_dfilter = LVD_DISABLE */

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_loco_limitationTest_TG016_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_002
* Description  : Test API function lvd_hw_check_loco_limitation()
***********************************************************************************************************************/
TEST(lvd_hw_check_loco_limitation_Test, TG016_002)
{
/* Check interrupt action */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_RESET)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_RESET before executing test");
#endif

/* Check the reset negation timing */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != LVD_STAB_RESET_ASSERT)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to LVD_STAB_RESET_ASSERT before executing test");
#endif

/* Check Digital filter */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != LVD_DISABLE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to LVD_DISABLE before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 1;

    /* Set p_cfg_opt->lvd_action = LVD_ACTION_RESET */
    /* Set p_cfg_opt->lvd_reset_negate = LVD_STAB_RESET_ASSERT */
    /* Set p_cfg_opt->lvd_dfilter = LVD_DISABLE */

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_LOCO_STOPPED, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_loco_limitationTest_TG016_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_003
* Description  : Test API function lvd_hw_check_loco_limitation()
***********************************************************************************************************************/
TEST(lvd_hw_check_loco_limitation_Test, TG016_003)
{
/* Check interrupt action */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NMI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_NMI before executing test");
#endif

/* Check the reset negation timing */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != LVD_STAB_RECOVARY)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to LVD_STAB_RECOVARY before executing test");
#endif

/* Check Digital filter */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != LVD_ENABLE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to LVD_ENABLE before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 1;

    /* Set p_cfg_opt->lvd_action = LVD_ACTION_NMI */
    /* Set p_cfg_opt->lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Set p_cfg_opt->lvd_dfilter = LVD_ENABLE */
    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_LOCO_STOPPED, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_loco_limitationTest_TG016_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_004
* Description  : Test API function lvd_hw_check_loco_limitation()
***********************************************************************************************************************/
TEST(lvd_hw_check_loco_limitation_Test, TG016_004)
{
/* Check interrupt action */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_MI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_MI before executing test");
#endif

/* Check the reset negation timing */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != LVD_STAB_RECOVARY)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to LVD_STAB_RECOVARY before executing test");
#endif

/* Check Digital filter */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != LVD_ENABLE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to LVD_ENABLE before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 1;

    /* Set p_cfg_opt->lvd_action = LVD_ACTION_MI */
    /* Set p_cfg_opt->lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Set p_cfg_opt->lvd_dfilter = LVD_ENABLE */
    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_LOCO_STOPPED, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_loco_limitationTest_TG016_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_005
* Description  : Test API function lvd_hw_check_loco_limitation()
***********************************************************************************************************************/
TEST(lvd_hw_check_loco_limitation_Test, TG016_005)
{
/* Check interrupt action */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NONE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_NONE before executing test");
#endif

/* Check the reset negation timing */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != LVD_STAB_RECOVARY)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to LVD_STAB_RECOVARY before executing test");
#endif

/* Check Digital filter */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != LVD_ENABLE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to LVD_ENABLE before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 1;

    /* Set p_cfg_opt->lvd_action = LVD_ACTION_NONE */
    /* Set p_cfg_opt->lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Set p_cfg_opt->lvd_dfilter = LVD_ENABLE */
    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_LOCO_STOPPED, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_check_loco_limitationTest_TG016_005
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_clear_lvd_status_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_clear_lvd_status_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_clear_lvd_status_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_clear_lvd_status_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_clear_lvd_status_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_clear_lvd_status_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG017_001
* Description  : Test API function lvd_hw_clear_lvd_status()
***********************************************************************************************************************/
TEST(lvd_hw_clear_lvd_status_Test, TG017_001)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* LVD Configuration */
    config.trigger = LVD_TRIGGER_RISE;

    /* Data for test */
    SYSTEM.LVDLVLR.BYTE = 0xBB;

    SYSTEM.LOCOCR.BIT.LCSTP = 0;
    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_1, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

   /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
    TEST_ASSERT_EQUAL_UINT32(0,    SYSTEM.LVD1SR.BIT.LVD1DET);
    TEST_ASSERT_EQUAL_UINT32(0xBB, SYSTEM.LVDLVLR.BYTE);

    /* Close LVD channel */
    ret = R_LVD_Close(LVD_CHANNEL_1);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_clear_lvd_statusTest_TG017_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG017_002
* Description  : Test API function lvd_hw_clear_lvd_status()
***********************************************************************************************************************/
TEST(lvd_hw_clear_lvd_status_Test, TG017_002)
{
    lvd_err_t       ret;    /* Return code */
    lvd_config_t    config; /* LVD Configuration */

    /* LVD Configuration */
    config.trigger = LVD_TRIGGER_RISE;

    /* Data for test */
    SYSTEM.LVDLVLR.BYTE = 0xBB;

    SYSTEM.LOCOCR.BIT.LCSTP = 0;
    /* Open LVD Channel */
    ret = R_LVD_Open(LVD_CHANNEL_2, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_2);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
    TEST_ASSERT_EQUAL_UINT32(0,    SYSTEM.LVD2SR.BIT.LVD2DET);
    TEST_ASSERT_EQUAL_UINT32(0xBB, SYSTEM.LVDLVLR.BYTE);

    /* Close LVD channel */
    ret = R_LVD_Close(LVD_CHANNEL_1);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_clear_lvd_statusTest_TG017_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_get_lvd_status_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_get_lvd_status_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_lvd_status_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_get_lvd_status_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_get_lvd_status_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_lvd_status_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG018_001
* Description  : Test API function lvd_hw_get_lvd_status()
***********************************************************************************************************************/
TEST(lvd_hw_get_lvd_status_Test, TG018_001)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD1SR.BIT.LVD1DET = 0;
    SYSTEM.LVD1SR.BIT.LVD1MON = 0;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_BELOW, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_NONE, cross);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_lvd_statusTest_TG018_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG018_002
* Description  : Test API function lvd_hw_get_lvd_status()
***********************************************************************************************************************/
TEST(lvd_hw_get_lvd_status_Test, TG018_002)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD1SR.BIT.LVD1DET = 1;
    SYSTEM.LVD1SR.BIT.LVD1MON = 1;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_ABOVE, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_OVER, cross);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_lvd_statusTest_TG018_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG018_003
* Description  : Test API function lvd_hw_get_lvd_status()
***********************************************************************************************************************/
TEST(lvd_hw_get_lvd_status_Test, TG018_003)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD2SR.BIT.LVD2DET = 0;
    SYSTEM.LVD2SR.BIT.LVD2MON = 0;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_BELOW, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_NONE, cross);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_lvd_statusTest_TG018_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG018_004
* Description  : Test API function lvd_hw_get_lvd_status()
***********************************************************************************************************************/
TEST(lvd_hw_get_lvd_status_Test, TG018_004)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_status_position_t   pos;    /* Position of monitored voltage */
    lvd_status_cross_t      cross;  /* Monitored voltage crossed Vdet or not */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);

    /* Data for test */
    SYSTEM.LVD2SR.BIT.LVD2DET = 1;
    SYSTEM.LVD2SR.BIT.LVD2MON = 1;

    /* Get status of LVD channel */
    ret = R_LVD_GetStatus(channel, &pos, &cross);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_POSITION_ABOVE, pos);
    TEST_ASSERT_EQUAL_UINT32(LVD_STATUS_CROSS_OVER, cross);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_lvd_statusTest_TG018_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_set_level_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_set_level_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_set_level_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_set_level_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_set_level_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_set_level_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG019_001
* Description  : Test API function lvd_hw_set_level()
***********************************************************************************************************************/
TEST(lvd_hw_set_level_Test, TG019_001)
{
/* Check voltage channel before executing test */
#if (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_VOLTAGE_LEVEL_DEFAULT_VALUE_CH1)
    TEST_IGNORE_MESSAGE("Please set LVD_VOLTAGE_LEVEL_VALUE_CH1 to LVD_VOLTAGE_LEVEL_DEFAULT_VALUE_CH1 before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVDLVLR.BIT.LVD1LVL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Set lvd_cfg_opt[i].lvd_voltage_level_value = 11 */
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(11, SYSTEM.LVDLVLR.BIT.LVD1LVL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_levelTest_TG019_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG019_002
* Description  : Test API function lvd_hw_set_level()
***********************************************************************************************************************/
TEST(lvd_hw_set_level_Test, TG019_002)
{
/* Check voltage channel before executing test */
#if (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE)
    TEST_IGNORE_MESSAGE("Please set LVD_VOLTAGE_LEVEL_VALUE_CH1 to LVD_INVALID_VALUE before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVDLVLR.BIT.LVD1LVL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

    /* Set lvd_cfg_opt[i].lvd_voltage_level_value = LVD_INVALID_VALUE */
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVDLVLR.BIT.LVD1LVL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_levelTest_TG019_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG019_003
* Description  : Test API function lvd_hw_set_level()
***********************************************************************************************************************/
TEST(lvd_hw_set_level_Test, TG019_003)
{
/* Check voltage channel before executing test */
#if (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_VOLTAGE_LEVEL_DEFAULT_VALUE_CH2)
    TEST_IGNORE_MESSAGE("Please set LVD_VOLTAGE_LEVEL_VALUE_CH2 to LVD_VOLTAGE_LEVEL_DEFAULT_VALUE_CH2 before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVDLVLR.BIT.LVD2LVL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Set lvd_cfg_opt[i].lvd_voltage_level_value = 11 */
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(11, SYSTEM.LVDLVLR.BIT.LVD2LVL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_levelTest_TG019_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG019_004
* Description  : Test API function lvd_hw_set_level()
***********************************************************************************************************************/
TEST(lvd_hw_set_level_Test, TG019_004)
{
/* Check voltage channel before executing test */
#if (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE)
    TEST_IGNORE_MESSAGE("Please set LVD_VOLTAGE_LEVEL_VALUE_CH2 to LVD_INVALID_VALUE before executing test");
#endif

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVDLVLR.BIT.LVD2LVL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

    /* Set lvd_cfg_opt[i].lvd_voltage_level_value = LVD_INVALID_VALUE */
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVDLVLR.BIT.LVD2LVL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_levelTest_TG019_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_set_trigger_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_set_trigger_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_set_trigger_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_set_trigger_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_set_trigger_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_set_trigger_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_001
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_001)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR1.BIT.LVD1IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR1.BIT.LVD1IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_002
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_002)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR1.BIT.LVD1IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_FALL;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR1.BIT.LVD1IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_003
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_003)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR1.BIT.LVD1IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_BOTH;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(2, SYSTEM.LVD1CR1.BIT.LVD1IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_004
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_004)
{
    TEST_IGNORE_MESSAGE("Unable to pass LVD_TRIGGER_INVALID to static function lvd_hw_set_trigger");

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR1.BIT.LVD1IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_INVALID;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR1.BIT.LVD1IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_005
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_005)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR1.BIT.LVD2IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR1.BIT.LVD2IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_006
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_006)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR1.BIT.LVD2IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_FALL;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR1.BIT.LVD2IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_007
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_007)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR1.BIT.LVD2IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_BOTH;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(2, SYSTEM.LVD2CR1.BIT.LVD2IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_008
* Description  : Test API function lvd_hw_set_trigger()
***********************************************************************************************************************/
TEST(lvd_hw_set_trigger_Test, TG020_008)
{
    TEST_IGNORE_MESSAGE("Unable to pass LVD_TRIGGER_INVALID to static function lvd_hw_set_trigger");

    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR1.BIT.LVD2IDTSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_INVALID;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR1.BIT.LVD2IDTSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_triggerTest_TG020_008
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_set_target_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_set_target_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_set_target_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_set_target_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_set_target_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_set_target_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_001
* Description  : Test API function lvd_hw_set_target()
***********************************************************************************************************************/
TEST(lvd_hw_set_target_Test, TG021_001)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    /* Do nothing */

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_targetTest_TG021_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_002
* Description  : Test API function lvd_hw_set_target()
***********************************************************************************************************************/
TEST(lvd_hw_set_target_Test, TG021_002)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    /* Do nothing */

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_targetTest_TG021_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_003
* Description  : Test API function lvd_hw_set_target()
***********************************************************************************************************************/
TEST(lvd_hw_set_target_Test, TG021_003)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    /* Do nothing */

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_targetTest_TG021_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_004
* Description  : Test API function lvd_hw_set_target()
***********************************************************************************************************************/
TEST(lvd_hw_set_target_Test, TG021_004)
{
    lvd_err_t               ret;    /* Return code       */
    lvd_config_t            config; /* LVD Configuration */
    lvd_channel_t           channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    /* Do nothing */

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_set_targetTest_TG021_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_select_reset_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_select_reset_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_reset_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_select_reset_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_select_reset_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_reset_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG022_001
* Description  : Test API function lvd_hw_select_reset()
***********************************************************************************************************************/
TEST(lvd_hw_select_reset_Test, TG022_001)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_NMI) && (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_MI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_NMI or LVD_ACTION_MI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2RI = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2RI);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_resetTest_TG022_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG022_002
* Description  : Test API function lvd_hw_select_reset()
***********************************************************************************************************************/
TEST(lvd_hw_select_reset_Test, TG022_002)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_NMI) &&  (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_MI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_NMI or LVD_ACTION_MI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2RI = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2RI);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_resetTest_TG022_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_setup_reset_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_setup_reset_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_setup_reset_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_setup_reset_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_setup_reset_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_setup_reset_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_001
* Description  : Test API function lvd_hw_setup_reset()
***********************************************************************************************************************/
TEST(lvd_hw_setup_reset_Test, TG023_001)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_RESET)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_RESET before executing test");
#endif

/* Check the reset negation timing before executing test */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to 0 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1RN = 0;

     /* Set lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1RN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_resetTest_TG023_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_002
* Description  : Test API function lvd_hw_setup_reset()
***********************************************************************************************************************/
TEST(lvd_hw_setup_reset_Test, TG023_002)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_RESET)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_RESET before executing test");
#endif

/* Check the reset negation timing before executing test */
#if (LVD_CFG_STABILIZATION_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1RN = 0;

     /* Set lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR0.BIT.LVD1RN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_resetTest_TG023_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_003
* Description  : Test API function lvd_hw_setup_reset()
***********************************************************************************************************************/
TEST(lvd_hw_setup_reset_Test, TG023_003)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_RESET)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_RESET before executing test");
#endif

/* Check the reset negation timing before executing test */
#if (LVD_CFG_STABILIZATION_CHANNEL_2 != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_2 to 0 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2RN = 0;

     /* Set lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2RN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_resetTest_TG023_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_004
* Description  : Test API function lvd_hw_setup_reset()
***********************************************************************************************************************/
TEST(lvd_hw_setup_reset_Test, TG023_004)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_RESET)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_RESET before executing test");
#endif

/* Check the reset negation timing before executing test */
#if (LVD_CFG_STABILIZATION_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_STABILIZATION_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2RN = 0;

     /* Set lvd_reset_negate = LVD_STAB_RECOVARY */
    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR0.BIT.LVD2RN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_resetTest_TG023_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_select_int_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_select_int_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_int_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_select_int_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_select_int_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_int_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_001
* Description  : Test API function lvd_hw_select_int()
***********************************************************************************************************************/
TEST(lvd_hw_select_int_Test, TG024_001)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_MI) && (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NMI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_MI or LVD_ACTION_NMI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1RI = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1RI);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_intTest_TG024_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_002
* Description  : Test API function lvd_hw_select_int()
***********************************************************************************************************************/
TEST(lvd_hw_select_int_Test, TG024_002)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_MI) && (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NMI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_MI or LVD_ACTION_NMI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1RI = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1RI);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_intTest_TG024_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_select_mi_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_select_mi_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_mi_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_select_mi_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_select_mi_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_mi_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_001
* Description  : Test API function lvd_hw_select_mi()
***********************************************************************************************************************/
TEST(lvd_hw_select_mi_Test, TG025_001)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_MI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_MI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR1.BIT.LVD1IRQSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR1.BIT.LVD1IRQSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_miTest_TG025_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_002
* Description  : Test API function lvd_hw_select_mi()
***********************************************************************************************************************/
TEST(lvd_hw_select_mi_Test, TG025_002)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_MI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_MI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR1.BIT.LVD2IRQSEL = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR1.BIT.LVD2IRQSEL);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_miTest_TG025_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_select_nmi_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_select_nmi_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_nmi_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_select_nmi_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_select_nmi_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_select_nmi_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG026_001
* Description  : Test API function lvd_hw_select_nmi()
***********************************************************************************************************************/
TEST(lvd_hw_select_nmi_Test, TG026_001)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != LVD_ACTION_NMI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to LVD_ACTION_NMI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR1.BIT.LVD1IRQSEL = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR1.BIT.LVD1IRQSEL);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_nmiTest_TG026_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG026_002
* Description  : Test API function lvd_hw_select_nmi()
***********************************************************************************************************************/
TEST(lvd_hw_select_nmi_Test, TG026_002)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != LVD_ACTION_NMI)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to LVD_ACTION_NMI before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR1.BIT.LVD2IRQSEL = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);
    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR1.BIT.LVD2IRQSEL);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_select_nmiTest_TG026_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_setup_dfilter_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_setup_dfilter_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_setup_dfilter_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_setup_dfilter_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_setup_dfilter_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_setup_dfilter_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_001
* Description  : Test API function lvd_hw_setup_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_setup_dfilter_Test, TG027_001)
{
/* Check LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 before executing test */
#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 != LVD_DEFAULT_VALUE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 to LVD_DEFAULT_VALUE before executing test");
#endif

/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1FSAMP = 1;
    SYSTEM.LOCOCR.BIT.LCSTP      = 0;

    /* Set lvd_cfg_opt[ch].lvd_dfilter_div_value = 0 */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_dfilterTest_TG027_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_002
* Description  : Test API function lvd_hw_setup_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_setup_dfilter_Test, TG027_002)
{
/* Check LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 before executing test */
#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 != LVD_DEFAULT_VALUE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 to LVD_DEFAULT_VALUE before executing test");
#endif

/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2FSAMP = 1;
    SYSTEM.LOCOCR.BIT.LCSTP      = 0;

    /* Set lvd_cfg_opt[ch].lvd_dfilter_div_value = 0 */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2FSAMP);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_dfilterTest_TG027_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_003
* Description  : Test API function lvd_hw_setup_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_setup_dfilter_Test, TG027_003)
{
/* Check LVD_CFG_SAMPLING_CLOCK_CHANNEL_1 before executing test */
#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 != LVD_INVALID_VALUE)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 to LVD_INVALID_VALUE before executing test");
#endif

/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2FSAMP = 1;
    SYSTEM.LOCOCR.BIT.LCSTP      = 0;

    /* Set lvd_cfg_opt[ch].lvd_dfilter_div_value = LVD_INVALID_VALUE */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_ERR_INVALID_DATA, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR0.BIT.LVD2FSAMP);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_setup_dfilterTest_TG027_003
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_get_circuit_enable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_get_circuit_enable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_circuit_enable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_get_circuit_enable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_get_circuit_enable_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_circuit_enable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_001
* Description  : Test API function lvd_hw_get_circuit_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_circuit_enable_Test, TG028_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVCMPCR.BIT.LVD1E = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_circuit_enableTest_TG028_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_002
* Description  : Test API function lvd_hw_get_circuit_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_circuit_enable_Test, TG028_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVCMPCR.BIT.LVD1E = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_circuit_enableTest_TG028_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_003
* Description  : Test API function lvd_hw_get_circuit_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_circuit_enable_Test, TG028_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVCMPCR.BIT.LVD2E = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_circuit_enableTest_TG028_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_004
* Description  : Test API function lvd_hw_get_circuit_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_circuit_enable_Test, TG028_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVCMPCR.BIT.LVD2E = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_circuit_enableTest_TG028_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_get_reset_int_enable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_get_reset_int_enable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_reset_int_enable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_get_reset_int_enable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_get_reset_int_enable_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_reset_int_enable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_001
* Description  : Test API function lvd_hw_get_reset_int_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_reset_int_enable_Test, TG029_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1RIE = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_reset_int_enableTest_TG029_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_002
* Description  : Test API function lvd_hw_get_reset_int_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_reset_int_enable_Test, TG029_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1RIE = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_reset_int_enableTest_TG029_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_003
* Description  : Test API function lvd_hw_get_reset_int_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_reset_int_enable_Test, TG029_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2RIE = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_reset_int_enableTest_TG029_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_004
* Description  : Test API function lvd_hw_get_reset_int_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_reset_int_enable_Test, TG029_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2RIE = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Clear status of LVD channel */
    ret = R_LVD_ClearStatus(LVD_CHANNEL_1);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_reset_int_enableTest_TG029_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_get_dfilter_enable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_get_dfilter_enable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_dfilter_enable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_get_dfilter_enable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_get_dfilter_enable_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_get_dfilter_enable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_001
* Description  : Test API function lvd_hw_get_dfilter_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_dfilter_enable_Test, TG030_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1DFDIS = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_dfilter_enableTest_TG030_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_002
* Description  : Test API function lvd_hw_get_dfilter_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_dfilter_enable_Test, TG030_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD1CR0.BIT.LVD1DFDIS = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_dfilter_enableTest_TG030_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_003
* Description  : Test API function lvd_hw_get_dfilter_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_dfilter_enable_Test, TG030_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2DFDIS = 0;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_dfilter_enableTest_TG030_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_004
* Description  : Test API function lvd_hw_get_dfilter_enable()
***********************************************************************************************************************/
TEST(lvd_hw_get_dfilter_enable_Test, TG030_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Data for test */
    SYSTEM.LVD2CR0.BIT.LVD2DFDIS = 1;

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    //TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1FSAMP);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_get_dfilter_enableTest_TG030_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_enable_output_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_enable_output_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_output_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_enable_output_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_enable_output_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_output_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_001
* Description  : Test API function lvd_hw_enable_output()
***********************************************************************************************************************/
TEST(lvd_hw_enable_output_Test, TG031_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR0.BIT.LVD1CMPE);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_outputTest_TG031_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_002
* Description  : Test API function lvd_hw_enable_output()
***********************************************************************************************************************/
TEST(lvd_hw_enable_output_Test, TG031_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1CMPE);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_outputTest_TG031_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_003
* Description  : Test API function lvd_hw_enable_output()
***********************************************************************************************************************/
TEST(lvd_hw_enable_output_Test, TG031_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR0.BIT.LVD2CMPE);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_outputTest_TG031_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_004
* Description  : Test API function lvd_hw_enable_output()
***********************************************************************************************************************/
TEST(lvd_hw_enable_output_Test, TG031_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2CMPE);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_outputTest_TG031_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_enable_circuit_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_enable_circuit_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_circuit_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_enable_circuit_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_enable_circuit_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_circuit_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_001
* Description  : Test API function lvd_hw_enable_circuit()
***********************************************************************************************************************/
TEST(lvd_hw_enable_circuit_Test, TG032_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVCMPCR.BIT.LVD1E);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_circuitTest_TG032_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_002
* Description  : Test API function lvd_hw_enable_circuit()
***********************************************************************************************************************/
TEST(lvd_hw_enable_circuit_Test, TG032_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVCMPCR.BIT.LVD1E);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_circuitTest_TG032_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_003
* Description  : Test API function lvd_hw_enable_circuit()
***********************************************************************************************************************/
TEST(lvd_hw_enable_circuit_Test, TG032_003)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVCMPCR.BIT.LVD2E);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_circuitTest_TG032_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_004
* Description  : Test API function lvd_hw_enable_circuit()
***********************************************************************************************************************/
TEST(lvd_hw_enable_circuit_Test, TG032_004)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVCMPCR.BIT.LVD2E);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_circuitTest_TG032_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_enable_reset_int_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_enable_reset_int_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_reset_int_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_enable_reset_int_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_enable_reset_int_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_reset_int_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG033_001
* Description  : Test API function lvd_hw_enable_reset_int()
***********************************************************************************************************************/
TEST(lvd_hw_enable_reset_int_Test, TG033_001)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 0 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR0.BIT.LVD1RIE);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_reset_intTest_TG033_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG033_002
* Description  : Test API function lvd_hw_enable_reset_int()
***********************************************************************************************************************/
TEST(lvd_hw_enable_reset_int_Test, TG033_002)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 0 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1RIE);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_reset_intTest_TG033_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG033_003
* Description  : Test API function lvd_hw_enable_reset_int()
***********************************************************************************************************************/
TEST(lvd_hw_enable_reset_int_Test, TG033_003)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 0 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR0.BIT.LVD2RIE);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_reset_intTest_TG033_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG033_004
* Description  : Test API function lvd_hw_enable_reset_int()
***********************************************************************************************************************/
TEST(lvd_hw_enable_reset_int_Test, TG033_004)
{
/* Check interrupt action before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != 0)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 0 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2RIE);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_reset_intTest_TG033_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_enable_dfilter_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_enable_dfilter_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_dfilter_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_enable_dfilter_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_enable_dfilter_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_dfilter_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG034_001
* Description  : Test API function lvd_hw_enable_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_enable_dfilter_Test, TG034_001)
{
/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 0;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1DFDIS);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_dfilterTest_TG034_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG034_002
* Description  : Test API function lvd_hw_enable_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_enable_dfilter_Test, TG034_002)
{
/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 0;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR0.BIT.LVD1DFDIS);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_dfilterTest_TG034_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG034_003
* Description  : Test API function lvd_hw_enable_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_enable_dfilter_Test, TG034_003)
{
/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 0;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2DFDIS);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_dfilterTest_TG034_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG034_004
* Description  : Test API function lvd_hw_enable_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_enable_dfilter_Test, TG034_004)
{
/* Check Digital filter before executing test */
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Data for test */
    SYSTEM.LOCOCR.BIT.LCSTP = 0;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR0.BIT.LVD2DFDIS);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_dfilterTest_TG034_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_enable_mi_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_enable_mi_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_mi_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_enable_mi_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_enable_mi_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_mi_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG035_001
* Description  : Test API function lvd_hw_enable_mi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_mi_Test, TG035_001)
{
/* Check Maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != 2)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 2 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, IR(LVD1, LVD1));
    TEST_ASSERT_EQUAL_UINT32(3, IPR(LVD1, LVD1));
    TEST_ASSERT_EQUAL_UINT32(1, IEN(LVD1, LVD1));
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_miTest_TG035_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG035_002
* Description  : Test API function lvd_hw_enable_mi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_mi_Test, TG035_002)
{
/* Check Maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != 2)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 2 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, IEN(LVD1, LVD1));
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_miTest_TG035_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG035_003
* Description  : Test API function lvd_hw_enable_mi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_mi_Test, TG035_003)
{
/* Check Maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != 2)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 2 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, IR(LVD2, LVD2));
    TEST_ASSERT_EQUAL_UINT32(3, IPR(LVD2, LVD2));
    TEST_ASSERT_EQUAL_UINT32(1, IEN(LVD2, LVD2));
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_miTest_TG035_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG035_004
* Description  : Test API function lvd_hw_enable_mi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_mi_Test, TG035_004)
{
/* Check Maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != 2)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 2 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, IEN(LVD2, LVD2));
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_miTest_TG035_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_enable_nmi_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_enable_nmi_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_nmi_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_enable_nmi_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_enable_nmi_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_enable_nmi_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG036_001
* Description  : Test API function lvd_hw_enable_nmi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_nmi_Test, TG036_001)
{
/* Check Non-maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, ICU.NMICLR.BIT.LVD1CLR);
    TEST_ASSERT_EQUAL_UINT32(1, ICU.NMIER.BIT.LVD1EN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_nmiTest_TG036_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG036_002
* Description  : Test API function lvd_hw_enable_nmi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_nmi_Test, TG036_002)
{
/* Check Non-maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_IGNORE_MESSAGE("Ignore these asserts because the NMICLR and NMIER could not be reset to 0 after setting");
    TEST_ASSERT_EQUAL_UINT32(0, ICU.NMICLR.BIT.LVD1CLR);
    TEST_ASSERT_EQUAL_UINT32(0, ICU.NMIER.BIT.LVD1EN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_nmiTest_TG036_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG036_003
* Description  : Test API function lvd_hw_enable_nmi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_nmi_Test, TG036_003)
{
/* Check Non-maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, ICU.NMICLR.BIT.LVD2CLR);
    TEST_ASSERT_EQUAL_UINT32(1, ICU.NMIER.BIT.LVD2EN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_nmiTest_TG036_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG036_004
* Description  : Test API function lvd_hw_enable_nmi()
***********************************************************************************************************************/
TEST(lvd_hw_enable_nmi_Test, TG036_004)
{
/* Check Non-maskable interrupt before executing test */
#if (LVD_CFG_ACTION_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_ACTION_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Check result */
    TEST_IGNORE_MESSAGE("Ignore these asserts because the NMICLR and NMIER could not be reset to 0 after setting");
    TEST_ASSERT_EQUAL_UINT32(0, ICU.NMICLR.BIT.LVD2CLR);
    TEST_ASSERT_EQUAL_UINT32(0, ICU.NMIER.BIT.LVD2EN);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_enable_nmiTest_TG036_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_dummy_read_dfilter_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_dummy_read_dfilter_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_dummy_read_dfilter_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_dummy_read_dfilter_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_dummy_read_dfilter_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_dummy_read_dfilter_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG037_001
* Description  : Test API function lvd_hw_dummy_read_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_dummy_read_dfilter_Test, TG037_001)
{
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_1 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_1 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD1CR0.BIT.LVD1DFDIS);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_dummy_read_dfilterTest_TG037_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG037_002
* Description  : Test API function lvd_hw_dummy_read_dfilter()
***********************************************************************************************************************/
TEST(lvd_hw_dummy_read_dfilter_Test, TG037_002)
{
#if (LVD_CFG_DIGITAL_FILTER_CHANNEL_2 != 1)
    TEST_IGNORE_MESSAGE("Please set LVD_CFG_DIGITAL_FILTER_CHANNEL_2 to 1 before executing test");
#endif

    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(0, SYSTEM.LVD2CR0.BIT.LVD2DFDIS);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_dummy_read_dfilterTest_TG037_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_dummy_read_circuit_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_dummy_read_circuit_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_dummy_read_circuit_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_dummy_read_circuit_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_dummy_read_circuit_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_dummy_read_circuit_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG038_001
* Description  : Test API function lvd_hw_dummy_read_circuit()
***********************************************************************************************************************/
TEST(lvd_hw_dummy_read_circuit_Test, TG038_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVCMPCR.BIT.LVD1E);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_dummy_read_circuitTest_TG038_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG038_002
* Description  : Test API function lvd_hw_dummy_read_circuit()
***********************************************************************************************************************/
TEST(lvd_hw_dummy_read_circuit_Test, TG038_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVCMPCR.BIT.LVD2E);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);

}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_dummy_read_circuitTest_TG038_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:lvd_hw_dummy_read_output_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(lvd_hw_dummy_read_output_Test)
{

}
/***********************************************************************************************************************
End of function TEST_lvd_hw_dummy_read_output_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_lvd_hw_dummy_read_output_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(lvd_hw_dummy_read_output_Test)
{
    /* Close LVD channel to ensure that they are closed before starting new cases */
    R_LVD_Close(LVD_CHANNEL_1);
    R_LVD_Close(LVD_CHANNEL_2);
}
/***********************************************************************************************************************
End of function TEST_lvd_hw_dummy_read_output_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG039_001
* Description  : Test API function lvd_hw_dummy_read_output()
***********************************************************************************************************************/
TEST(lvd_hw_dummy_read_output_Test, TG039_001)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_1;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD1CR0.BIT.LVD1CMPE);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_dummy_read_outputTest_TG039_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG039_002
* Description  : Test API function lvd_hw_dummy_read_output()
***********************************************************************************************************************/
TEST(lvd_hw_dummy_read_output_Test, TG039_002)
{
    lvd_err_t       ret;    /* Return code       */
    lvd_config_t    config; /* LVD Configuration */
    lvd_channel_t   channel;/* LVD channel */

    /* Configure LVD channel */
    config.trigger = LVD_TRIGGER_RISE;
    channel        = LVD_CHANNEL_2;

    /* Open LVD channel */
    ret = R_LVD_Open(channel, &config, lvd_callback_func);
    TEST_ASSERT_EQUAL_UINT32(LVD_SUCCESS, ret);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT32(1, SYSTEM.LVD2CR0.BIT.LVD2CMPE);

    /* Close LVD channel */
    ret = R_LVD_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_lvd_hw_dummy_read_outputTest_TG039_002
***********************************************************************************************************************/

