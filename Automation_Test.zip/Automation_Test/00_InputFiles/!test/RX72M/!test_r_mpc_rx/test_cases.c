/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : test_cases.c
* Description  : Unity Unit Test for MPC module
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 29.06.2018 1.00    First Release
*         : 07.12.2018 2.00    Test for RX72T
*         : 04.16.2019 3.00    Test for RX72M
***********************************************************************************************************************/

#include "platform.h"
#include "r_gpio_rx_if.h"
#include "r_mpc_rx_if.h"

#include "../!test/unity/unity.h"
#include "../!test/unity/unity_fixture.h"
#include "stdio.h"

#define     MPC_PFS_BASE_REG    ((uint8_t volatile *)(&MPC.PWPR.BYTE+33))
#define     MPC_PFS_BIT_ASEL    ((uint8_t)0x80)
#define     MPC_PFS_BIT_ISEL    ((uint8_t)0x40)
#define     MPC_PFS_BIT_PSEL    ((uint8_t)0x3F)


static uint8_t volatile * mpc_get_addr(uint8_t volatile * base_addr, uint16_t index)
{
	uint32_t port_offset;
	uint32_t pin_offset;

	pin_offset =  (uint32_t)(index & 0x00FFu);
	port_offset = (((uint32_t)index >> 5) & 0x000000FFuL);

	return (uint8_t volatile *)(pin_offset + port_offset + (uint32_t)base_addr);
}

TEST_SETUP(MPC_TEST)
{
	/* Do something */
}

TEST_TEAR_DOWN(MPC_TEST)
{
	/* Do something */
}

TEST(MPC_TEST, TG001_001)
{
    printf("[TG001_001_GetVersion]===");
    uint32_t ret = R_MPC_GetVersion();

    uint32_t ver = (((uint32_t)MPC_RX_VERSION_MAJOR) << 16) | (uint32_t)MPC_RX_VERSION_MINOR;

    TEST_ASSERT_EQUAL(ver, ret);
    printf("Version of MPC is %d.%d\n", GPIO_RX_VERSION_MAJOR, GPIO_RX_VERSION_MINOR);
}

TEST(MPC_TEST, TG002_001)
{
    printf("[TG002_001_MPC_Write]===");
    mpc_config_t wconfig;
    wconfig.analog_enable = true;
    wconfig.irq_enable = true;
    wconfig.pin_function = 0x00;

    mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);

    TEST_ASSERT_EQUAL(MPC_ERR_INVALID_CFG, err);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG002_002)
{
    printf("[TG002_002_MPC_Write]===");
    mpc_config_t wconfig;
    wconfig.analog_enable = true;
    wconfig.irq_enable = false;
    wconfig.pin_function = 0x01;

    mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);

    TEST_ASSERT_EQUAL(MPC_ERR_INVALID_CFG, err);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG002_003)
{
    printf("[TG002_003_MPC_Write]===");
    mpc_config_t wconfig;
    wconfig.analog_enable = true;
    wconfig.irq_enable = false;
    wconfig.pin_function = 0x00;

    uint8_t volatile * pfs_reg;

    mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);

    pfs_reg = mpc_get_addr(MPC_PFS_BASE_REG, (uint16_t)GPIO_PORT_0_PIN_0);

    TEST_ASSERT_EQUAL(MPC_PFS_BIT_ASEL, *pfs_reg);
    TEST_ASSERT_EQUAL(MPC_SUCCESS, err);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG002_004)
{
    printf("[TG002_004_MPC_Write]===");
	mpc_config_t wconfig;
	wconfig.analog_enable = false;
	wconfig.irq_enable = true;
	wconfig.pin_function = 0x01;

	uint8_t volatile * pfs_reg;

	mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);

	pfs_reg = mpc_get_addr(MPC_PFS_BASE_REG, (uint16_t)GPIO_PORT_0_PIN_0);

	TEST_ASSERT_EQUAL((MPC_PFS_BIT_ISEL | (0x01 & MPC_PFS_BIT_PSEL)), *pfs_reg);
	TEST_ASSERT_EQUAL(MPC_SUCCESS, err);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG002_005)
{
    printf("[TG002_005_MPC_Write]===");
	mpc_config_t wconfig;
	wconfig.analog_enable = false;
	wconfig.irq_enable = true;
	wconfig.pin_function = 0x00;

	uint8_t volatile * pfs_reg;

	mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);

	pfs_reg = mpc_get_addr(MPC_PFS_BASE_REG, (uint16_t)GPIO_PORT_0_PIN_0);

	TEST_ASSERT_EQUAL(MPC_PFS_BIT_ISEL, *pfs_reg);
	TEST_ASSERT_EQUAL(MPC_SUCCESS, err);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG003_001)
{
    printf("[TG003_001_MPC_Read]===");
	mpc_config_t wconfig;
	wconfig.analog_enable = true;
	wconfig.irq_enable = false;
	wconfig.pin_function = 0x00;

	mpc_config_t rconfig;

	mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);
	TEST_ASSERT_EQUAL(MPC_SUCCESS, err);

	R_MPC_Read(GPIO_PORT_0_PIN_0, &rconfig);

	TEST_ASSERT_EQUAL(true, rconfig.analog_enable);
	TEST_ASSERT_EQUAL(false, rconfig.irq_enable);
	TEST_ASSERT_EQUAL(0x00, rconfig.pin_function);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG003_002)
{
    printf("[TG003_002_MPC_Read]===");
	mpc_config_t wconfig;
	wconfig.analog_enable = false;
	wconfig.irq_enable = false;
	wconfig.pin_function = 0x01;

	mpc_config_t rconfig;

	mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);
	TEST_ASSERT_EQUAL(MPC_SUCCESS, err);

	R_MPC_Read(GPIO_PORT_0_PIN_0, &rconfig);

	TEST_ASSERT_EQUAL(false, rconfig.analog_enable);
	TEST_ASSERT_EQUAL(false, rconfig.irq_enable);
	TEST_ASSERT_EQUAL(0x01, rconfig.pin_function);
    printf("Test successfully\n");
}

TEST(MPC_TEST, TG003_003)
{
    printf("[TG003_003_MPC_Read]===");
	mpc_config_t wconfig;
	wconfig.analog_enable = false;
	wconfig.irq_enable = true;
	wconfig.pin_function = 0x03;

	mpc_config_t rconfig;

	mpc_err_t err = R_MPC_Write(GPIO_PORT_0_PIN_0, &wconfig);
	TEST_ASSERT_EQUAL(MPC_SUCCESS, err);

	R_MPC_Read(GPIO_PORT_0_PIN_0, &rconfig);

	TEST_ASSERT_EQUAL(false, rconfig.analog_enable);
	TEST_ASSERT_EQUAL(true, rconfig.irq_enable);
	TEST_ASSERT_EQUAL(0x03, rconfig.pin_function);
    printf("Test successfully\n");
}
