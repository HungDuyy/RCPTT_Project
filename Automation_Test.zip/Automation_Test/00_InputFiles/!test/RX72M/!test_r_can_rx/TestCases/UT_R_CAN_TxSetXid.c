#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_TxSetXid_Test)
{
	 uint32_t channel= 0;
	 R_CAN_Create(channel, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_TxSetXid_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG005_001
* Description  : Test API function R_CAN_TxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_TxSetXid_Test, TG005_001)
{
	printf("[TG005_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    api_status= R_CAN_TxSetXid(ch_nr, mbox_nr, &frame, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG005_002
* Description  : Test API function R_CAN_TxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_TxSetXid_Test, TG005_002)
{
	printf("[TG005_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    api_status= R_CAN_TxSetXid(ch_nr, mbox_nr, &frame, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG005_003
* Description  : Test API function R_CAN_TxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_TxSetXid_Test, TG005_003)
{
	printf("[TG005_003]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    api_status= R_CAN_TxSetXid(ch_nr, mbox_nr, &frame, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG005_004
* Description  : Test API function R_CAN_TxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_TxSetXid_Test, TG005_004)
{
	printf("[TG005_004]\n");
    const uint32_t ch_nr = 3;
    const uint32_t mbox_nr = 0;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    api_status= R_CAN_TxSetXid(ch_nr, mbox_nr, &frame, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG005_005
* Description  : Test API function R_CAN_TxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_TxSetXid_Test, TG005_005)
{
	printf("[TG005_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0x1A5A5A5A;
    const uint8_t pkt_length = 8;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    frame.id = pkt_id;
    frame.dlc= pkt_length;
    for (uint8_t i = 0; i < pkt_length; i++)
    {
        frame.data[i] = i + 'A';
    }
    api_status= R_CAN_TxSetXid(ch_nr, mbox_nr, &frame, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}
