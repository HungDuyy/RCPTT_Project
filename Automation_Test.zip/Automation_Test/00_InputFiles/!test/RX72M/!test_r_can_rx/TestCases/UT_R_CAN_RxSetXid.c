#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_RxSetXid_Test)
{
	 uint32_t channel= 0;
	 R_CAN_Create(channel, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_RxSetXid_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG010_001
* Description  : Test API function R_CAN_RxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_RxSetXid_Test, TG010_001)
{
	printf("[TG010_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

   api_status = R_CAN_RxSetXid(ch_nr, mbox_nr, pkt_id, frame_type);
   TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG010_002
* Description  : Test API function R_CAN_RxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_RxSetXid_Test, TG010_002)
{
	printf("[TG010_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 1;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSetXid(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG010_003
* Description  : Test API function R_CAN_RxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_RxSetXid_Test, TG010_003)
{
	printf("[TG010_003]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSetXid(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG010_004
* Description  : Test API function R_CAN_RxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_RxSetXid_Test, TG010_004)
{
	printf("[TG010_004]\n");
    const uint32_t ch_nr = 3;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;

    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSetXid(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG010_005
* Description  : Test API function R_CAN_RxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_RxSetXid_Test, TG010_005)
{
	printf("[TG010_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 32;
    const uint32_t pkt_id = 0x1A5A5A5A;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSetXid(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_SW_BAD_MBX, api_status);
}

/***********************************************************************************************************************
* Function Name: TG010_006
* Description  : Test API function R_CAN_RxSetXid()
***********************************************************************************************************************/
TEST(R_CAN_RxSetXid_Test, TG010_006)
{
	printf("[TG010_006]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0x1A5A5A5A;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSetXid(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}
