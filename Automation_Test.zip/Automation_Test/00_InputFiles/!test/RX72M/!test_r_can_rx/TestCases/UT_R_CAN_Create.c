#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_Create_Test)
{
    /* do nothing */
}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_Create_Test)
{
    /* do nothing */
}

static void tx_callback(void)
{
    R_BSP_NOP();
}
static void rx_callback(void)
{
    R_BSP_NOP();
}

static void error_callback(void)
{
    R_BSP_NOP();
}


/***********************************************************************************************************************
* Function Name: TG001_001
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_001)
{
	printf("[TG001_001]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 0;
    api_status = R_CAN_Create(channel, NULL,NULL,NULL);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

}

/***********************************************************************************************************************
* Function Name: TG001_002
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_002)
{
	printf("[TG001_002]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 1;
    api_status = R_CAN_Create(channel, NULL,NULL,NULL);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

}

/***********************************************************************************************************************
* Function Name: TG001_003
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_003)
{
	printf("[TG001_003]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 2;
    api_status = R_CAN_Create(channel, NULL,NULL,NULL);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}


/***********************************************************************************************************************
* Function Name: TG001_004
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_004)
{
	printf("[TG001_004]\n");
    uint32_t api_status = R_CAN_BAD_CH_NR;
    uint32_t channel= 3;
    api_status = R_CAN_Create(channel, NULL,NULL,NULL);
    TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG001_005
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_005)
{
	printf("[TG001_005]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 0;
    api_status = R_CAN_Create(channel, tx_callback,NULL,NULL);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG001_006
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_006)
{
	printf("[TG001_006]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 0;
    api_status = R_CAN_Create(channel, NULL,rx_callback,NULL);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG001_007
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_007)
{
	printf("[TG001_007]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 0;
    api_status = R_CAN_Create(channel, NULL,NULL,error_callback);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG001_008
* Description  : Test API function R_CAN_Create()
***********************************************************************************************************************/
TEST(R_CAN_Create_Test, TG001_008)
{
	printf("[TG001_008]\n");
    uint32_t api_status = R_CAN_OK;
    uint32_t channel= 0;

    CAN0.STR.BIT.EST = 1;
    CAN0.EIFR.BYTE = 1;
    CAN0.ECSR.BYTE = 1;
    api_status = R_CAN_Create(channel, NULL,NULL,error_callback);
    TEST_ASSERT_EQUAL(R_CAN_SW_RST_ERR, api_status);
}

