#include "test_main.h"

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_RxSetMask_Test)
{
	const uint32_t ch_nr = 0;
	R_CAN_Create(ch_nr, NULL, NULL, NULL);

	const uint32_t ch_nr1 = 1;
	R_CAN_Create(ch_nr1, NULL, NULL, NULL);

	const uint32_t ch_nr2 = 2;
	R_CAN_Create(ch_nr2, NULL, NULL, NULL);


}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_RxSetMask_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);

	uint32_t ch_nr1= 1;
    R_CAN_Control(ch_nr1, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr1, DISABLE);

	uint32_t ch_nr2= 2;
    R_CAN_Control(ch_nr2, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr2, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG013_001
* Description  : Test API function R_CAN_RxSetMask()
***********************************************************************************************************************/
TEST(R_CAN_RxSetMask_Test, TG013_001)
{
	printf("[TG013_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t mask_value = 0xFF;
	CAN0.CTLR.BIT.IDFM = EXT_ID_MODE;
    R_CAN_RxSetMask(ch_nr, mbox_nr, mask_value);

	TEST_ASSERT_EQUAL(R_CAN_OK,0 );
}

/***********************************************************************************************************************
* Function Name: TG013_002
* Description  : Test API function R_CAN_RxSetMask()
***********************************************************************************************************************/
TEST(R_CAN_RxSetMask_Test, TG013_002)
{
	printf("[TG013_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 0;
    const uint32_t mask_value = 0xFF;

    R_CAN_RxSetMask(ch_nr, mbox_nr, mask_value);

	TEST_ASSERT_EQUAL(R_CAN_OK, 0);
}

/***********************************************************************************************************************
* Function Name: TG013_003
* Description  : Test API function R_CAN_RxSetMask()
***********************************************************************************************************************/
TEST(R_CAN_RxSetMask_Test, TG013_003)
{
	printf("[TG013_003]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 0;
    const uint32_t mask_value = 0xFF;

	CAN2.CTLR.BIT.IDFM = MIXED_ID_MODE;
    R_CAN_RxSetMask(ch_nr, mbox_nr, mask_value);

	TEST_ASSERT_EQUAL(R_CAN_OK, 0);
}

/***********************************************************************************************************************
* Function Name: TG013_004
* Description  : Test API function R_CAN_RxSetMask()
***********************************************************************************************************************/
TEST(R_CAN_RxSetMask_Test, TG013_004)
{
	printf("[TG013_004]\n");
    const uint32_t ch_nr = 3;
    const uint32_t mbox_nr = 0;
    const uint32_t mask_value = 0xFF;

    R_CAN_RxSetMask(ch_nr, mbox_nr, mask_value);

	TEST_ASSERT_EQUAL(R_CAN_OK, 0);
}

/***********************************************************************************************************************
* Function Name: TG013_005
* Description  : Test API function R_CAN_RxSetMask()
***********************************************************************************************************************/
TEST(R_CAN_RxSetMask_Test, TG013_005)
{
	printf("[TG013_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 32;
    const uint32_t mask_value = 0xFF;

    R_CAN_RxSetMask(ch_nr, mbox_nr, mask_value);

	TEST_ASSERT_EQUAL(R_CAN_OK, 0);
}
