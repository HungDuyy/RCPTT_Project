#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_Tx_Test)
{
	 uint32_t channel = 0;
	 R_CAN_Create(channel, NULL, NULL, NULL);

	 uint32_t channel1 = 1;
	 R_CAN_Create(channel1, NULL, NULL, NULL);

	 uint32_t channel2 = 2;
	 R_CAN_Create(channel2, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_Tx_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);

	uint32_t ch_nr1 = 1;
    R_CAN_Control(ch_nr1, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr1, DISABLE);

	uint32_t ch_nr2 = 2;
    R_CAN_Control(ch_nr2, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr2, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG006_001
* Description  : Test API function R_CAN_Tx()
***********************************************************************************************************************/
TEST(R_CAN_Tx_Test, TG006_001)
{
	printf("[TG006_001]\n");
	const uint32_t ch_nr = 0;
	const uint32_t mbox_nr = 0;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_Tx(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG006_002
* Description  : Test API function R_CAN_Tx()
***********************************************************************************************************************/
TEST(R_CAN_Tx_Test, TG006_002)
{
	printf("[TG006_002]\n");
	const uint32_t ch_nr = 1;
	const uint32_t mbox_nr = 1;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_Tx(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG006_003
* Description  : Test API function R_CAN_Tx()
***********************************************************************************************************************/
TEST(R_CAN_Tx_Test, TG006_003)
{
	printf("[TG006_003]\n");
	const uint32_t ch_nr = 2;
	const uint32_t mbox_nr = 2;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_Tx(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG006_004
* Description  : Test API function R_CAN_Tx()
***********************************************************************************************************************/
TEST(R_CAN_Tx_Test, TG006_004)
{
	printf("[TG006_004]\n");
	const uint32_t ch_nr = 3;
	const uint32_t mbox_nr = 3;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_Tx(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG006_005
* Description  : Test API function R_CAN_Tx()
***********************************************************************************************************************/
TEST(R_CAN_Tx_Test, TG006_005)
{
	printf("[TG006_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 32;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_Tx(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_SW_BAD_MBX, api_status);
}
