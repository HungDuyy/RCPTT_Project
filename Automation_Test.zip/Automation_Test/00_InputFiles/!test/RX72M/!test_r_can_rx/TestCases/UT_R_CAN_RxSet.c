#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_RxSet_Test)
{
	 uint32_t channel= 0;
	 R_CAN_Create(channel, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_RxSet_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG009_001
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_001)
{
	printf("[TG009_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_002
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_002)
{
	printf("[TG009_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 1;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_003
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_003)
{
	printf("[TG009_003]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_004
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_004)
{
	printf("[TG009_004]\n");
    const uint32_t ch_nr = 3;
    const uint32_t mbox_nr = 3;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_005
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_005)
{
	printf("[TG009_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 32;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_SW_BAD_MBX, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_006
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_006)
{
	printf("[TG009_006]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xE0000000;
    const uint32_t frame_type = DATA_FRAME;

    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_007
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_007)
{
	printf("[TG009_007]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = REMOTE_FRAME;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_008
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_008)
{
	printf("[TG009_008]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xA1;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    CAN0.CTLR.BIT.IDFM = MIXED_ID_MODE;

    api_status= R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG009_009
* Description  : Test API function R_CAN_RxSet()
***********************************************************************************************************************/
TEST(R_CAN_RxSet_Test, TG009_009)
{
	printf("[TG009_009]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    const uint32_t pkt_id = 0xE0000000;
    const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

    CAN0.CTLR.BIT.IDFM = MIXED_ID_MODE ;
    api_status= R_CAN_RxSet(ch_nr, mbox_nr, pkt_id, frame_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}
