#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_TxStopMsg_Test)
{
	 uint32_t channel= 0;
	 R_CAN_Create(channel, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_TxStopMsg_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG008_001
* Description  : Test API function R_CAN_TxStopMsg()
***********************************************************************************************************************/
TEST(R_CAN_TxStopMsg_Test, TG008_001)
{
	printf("[TG008_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_TxStopMsg(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

}

/***********************************************************************************************************************
* Function Name: TG008_002
* Description  : Test API function R_CAN_TxStopMsg()
***********************************************************************************************************************/
TEST(R_CAN_TxStopMsg_Test, TG008_002)
{
	printf("[TG008_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 1;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_TxStopMsg(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

}

/***********************************************************************************************************************
* Function Name: TG008_003
* Description  : Test API function R_CAN_TxStopMsg()
***********************************************************************************************************************/
TEST(R_CAN_TxStopMsg_Test, TG008_003)
{
	printf("[TG008_003]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_TxStopMsg(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

}

/***********************************************************************************************************************
* Function Name: TG008_004
* Description  : Test API function R_CAN_TxStopMsg()
***********************************************************************************************************************/
TEST(R_CAN_TxStopMsg_Test, TG008_004)
{
	printf("[TG008_004]\n");
    const uint32_t ch_nr = 3;
    const uint32_t mbox_nr = 3;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_TxStopMsg(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);

}

/***********************************************************************************************************************
* Function Name: TG008_005
* Description  : Test API function R_CAN_TxStopMsg()
***********************************************************************************************************************/
TEST(R_CAN_TxStopMsg_Test, TG008_005)
{
	printf("[TG008_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 32;
	uint32_t api_status = R_CAN_OK;

	api_status= R_CAN_TxStopMsg(ch_nr, mbox_nr);
	TEST_ASSERT_EQUAL(R_CAN_SW_BAD_MBX, api_status);

}

