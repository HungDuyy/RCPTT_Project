#include "test_main.h"



/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_Control_Test)
{
	 uint32_t channel= 0;
	 R_CAN_Create(channel, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_Control_Test)
{
	 uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);
}


/***********************************************************************************************************************
* Function Name: TG003_001
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_001)
{
	printf("[TG003_001]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = OPERATE_CANMODE;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG003_002
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_002)
{
	printf("[TG003_002]\n");
    uint32_t ch_nr = 1;
    uint32_t action_type = OPERATE_CANMODE;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG003_003
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_003)
{
	printf("[TG003_003]\n");
    uint32_t ch_nr = 2;
    uint32_t action_type = OPERATE_CANMODE;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}
/***********************************************************************************************************************
* Function Name: TG003_004
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_004)
{
	printf("[TG003_004]\n");
    uint32_t ch_nr = 3;
    uint32_t action_type = OPERATE_CANMODE;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG003_005
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_005)
{
	printf("[TG003_005]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = EXITSLEEP_CANMODE;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG003_006
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_006)
{
	printf("[TG003_006]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = EXITSLEEP_CANMODE;
    uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.SLPST = 1;  // change SFR directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);

    CAN0.STR.BIT.SLPST = 0;
    TEST_ASSERT_EQUAL(R_CAN_SW_WAKEUP_ERR, api_status);
}


/***********************************************************************************************************************
* Function Name: TG003_007
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_007)
{
	printf("[TG003_007]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = ENTERSLEEP_CANMODE;
    uint32_t api_status = R_CAN_OK;
    CAN0.STR.BIT.SLPST = 1;  // change SFR (sleep mode flag) directly for simulator
    CAN0.STR.BIT.HLTST = 1;  // change SFR (halt mode flag) directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

    CAN0.STR.BIT.SLPST = 0;
    CAN0.STR.BIT.HLTST = 0;
}

/***********************************************************************************************************************
* Function Name: TG003_008
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_008)
{
	printf("[TG003_008]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = ENTERSLEEP_CANMODE;
    uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.SLPST = 0;  // change SFR (sleep mode flag) directly for simulator
    CAN0.STR.BIT.HLTST = 1;  // change SFR (halt mode flag) directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_SW_SLEEP_ERR, api_status);

    CAN0.STR.BIT.HLTST = 0;
}


/***********************************************************************************************************************
* Function Name: TG003_009
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_009)
{
	printf("[TG003_009]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = RESET_CANMODE;
    uint32_t api_status = R_CAN_OK;
    CAN0.STR.BIT.RSTST = 1;  // change SFR (reset state flag) directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

    CAN0.STR.BIT.RSTST = 0;
}

/***********************************************************************************************************************
* Function Name: TG003_010
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_010)
{
	printf("[TG003_010]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = RESET_CANMODE;
    uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.RSTST = 0;  // change SFR (reset state flag) directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_SW_RST_ERR, api_status);

    CAN0.STR.BIT.RSTST = 0;
}

/***********************************************************************************************************************
* Function Name: TG003_011
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_011)
{
	printf("[TG003_011]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = HALT_CANMODE;
    uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.HLTST = 1;  // change SFR (halt mode flag) directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

    CAN0.STR.BIT.HLTST = 0;
}

/***********************************************************************************************************************
* Function Name: TG003_012
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_012)
{
	printf("[TG003_012]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = HALT_CANMODE;
    uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.HLTST = 0;  // change SFR (halt mode flag) directly for simulator

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_SW_HALT_ERR, api_status);

    CAN0.STR.BIT.HLTST = 0;
}

/***********************************************************************************************************************
* Function Name: TG003_013
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_013)
{
	printf("[TG003_013]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = OPERATE_CANMODE;
    uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.HLTST = 1;  // change SFR (halt mode flag) directly for simulator
    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_SW_HALT_ERR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG003_014
* Description  : Test API function R_CAN_Control()
***********************************************************************************************************************/
TEST(R_CAN_Control_Test, TG003_014)
{
	printf("[TG003_014]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = 1;
    uint32_t api_status = R_CAN_OK;

    api_status= R_CAN_Control(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_ACTION_TYPE, api_status);

}



