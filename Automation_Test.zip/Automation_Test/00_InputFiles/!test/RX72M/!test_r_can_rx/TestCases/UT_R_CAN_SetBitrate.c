#include "test_main.h"

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_SetBitrate_Test)
{
	const uint32_t ch_nr = 0;
	R_CAN_Create(ch_nr, NULL, NULL, NULL);

	const uint32_t ch_nr1 = 1;
	R_CAN_Create(ch_nr1, NULL, NULL, NULL);

	const uint32_t ch_nr2 = 2;
	R_CAN_Create(ch_nr2, NULL, NULL, NULL);


}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_SetBitrate_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);

	uint32_t ch_nr1= 1;
    R_CAN_Control(ch_nr1, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr1, DISABLE);

	uint32_t ch_nr2= 2;
    R_CAN_Control(ch_nr2, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr2, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG015_001
* Description  : Test API function R_CAN_SetBitrate()
***********************************************************************************************************************/
TEST(R_CAN_SetBitrate_Test, TG015_001)
{
	printf("[TG015_001]\n");
    const uint32_t ch_nr = 0;

    R_CAN_SetBitrate(ch_nr);
	TEST_ASSERT_EQUAL(0,0);
}

/***********************************************************************************************************************
* Function Name: TG015_002
* Description  : Test API function R_CAN_SetBitrate()
***********************************************************************************************************************/
TEST(R_CAN_SetBitrate_Test, TG015_002)
{
	printf("[TG015_002]\n");
    const uint32_t ch_nr = 1;

    R_CAN_SetBitrate(ch_nr);
	TEST_ASSERT_EQUAL(0,0);
}

/***********************************************************************************************************************
* Function Name: TG015_003
* Description  : Test API function R_CAN_SetBitrate()
***********************************************************************************************************************/
TEST(R_CAN_SetBitrate_Test, TG015_003)
{
	printf("[TG015_003]\n");
    const uint32_t ch_nr = 2;

    R_CAN_SetBitrate(ch_nr);
	TEST_ASSERT_EQUAL(0,0);
}

/***********************************************************************************************************************
* Function Name: TG015_004
* Description  : Test API function R_CAN_SetBitrate()
***********************************************************************************************************************/
TEST(R_CAN_SetBitrate_Test, TG015_004)
{
	printf("[TG015_004]\n");
    const uint32_t ch_nr = 3;

    R_CAN_SetBitrate(ch_nr);
	TEST_ASSERT_EQUAL(0,0);
}
