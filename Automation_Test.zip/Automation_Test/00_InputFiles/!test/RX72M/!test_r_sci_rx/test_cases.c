/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No 
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all 
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM 
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES 
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS 
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of 
* this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer 
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name       : test_cases.c
* Description     : Unity unit tests for RX SCI module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 16.06.2017 1.00     First Release
*         : 07.07.2017 2.00     Improve test cases, add test cases for internal functions
*         : 23.04.2017 3.00     Add test cases for data match feature
*         : 07.06.2018 3.10     Improve test cases, add test cases for re-entrancy implementation
*         : 07.12.2018 3.20     Support RX72T
*         : 18.04.2019 4.00     Support RX72M
*         : 08.08.2019 4.10     Support RX72M- Retest SCI v3.20
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "platform.h"
#include "unity_fixture.h"
#include "r_sci_rx_if.h"        // The SCI module API interface file.
#include "r_byteq_if.h"         // The BYTEQ module API interface file.
#include "r_sci_rx_config.h"    // User configurable options for the SCI module
#include "r_byteq_private.h"
#include "r_byteq_config.h"

#if defined(BSP_MCU_RX65N)
#include "r_sci_rx65n_private.h"
#elif defined(BSP_MCU_RX66T)
#include "r_sci_rx66t_private.h"
#elif defined(BSP_MCU_RX72T)
#include "r_sci_rx72t_private.h"
#elif defined(BSP_MCU_RX72M)
#include "r_sci_rx72m_private.h"
#else
#endif

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
extern bool r_byteq_open_fail_flag;
extern bool r_byteq_unused_fail_flag;
extern bool r_byteq_put_fail_flag;
extern bool r_byteq_use_true_flag;
extern bool r_byteq_use_false_flag;
extern bool r_byteq_get_fail_flag;

/***********************************************************************************************************************
Imported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
/* Declare test groups. */
TEST_GROUP(R_SCI_Open_Test);
TEST_GROUP(R_SCI_Close_Test);
TEST_GROUP(R_SCI_Send_Test);
TEST_GROUP(R_SCI_Receive_Test);
TEST_GROUP(R_SCI_SendReceive_Test);
TEST_GROUP(R_SCI_Control_Test);
TEST_GROUP(R_SCI_GetVersion_Test);
TEST_GROUP(txi_handler_Test);
TEST_GROUP(rxi_handler_Test);
TEST_GROUP(eri_handler_Test);
TEST_GROUP(power_on_Test);
TEST_GROUP(power_off_Test);
TEST_GROUP(sci_init_register_Test);
TEST_GROUP(sci_init_async_Test);
TEST_GROUP(sci_init_sync_Test);
TEST_GROUP(sci_init_queues_Test);
TEST_GROUP(sci_initialize_ints_Test);
TEST_GROUP(sci_init_bit_rate_Test);
TEST_GROUP(sci_disable_ints_Test);
TEST_GROUP(sci_send_async_data_Test);
TEST_GROUP(sci_send_sync_data_Test);
TEST_GROUP(sci_receive_async_data_Test);
TEST_GROUP(sci_receive_sync_data_Test);
TEST_GROUP(sci_async_cmds_Test);
TEST_GROUP(sci_sync_cmds_Test);
#if (SCI_CFG_DATA_MATCH_INCLUDED == 1)
TEST_GROUP(sci_receive_data_match_Test);
#endif


void test_sci_callback(void *pArgs);

/* Handle storage. Needs to persist as long as SCI calls are going to be made.*/
static sci_hdl_t   g_sci_handle;
static sci_cfg_t   g_config;
static bool callback_called_flag = false;
static bool callback_called_flag_matched = false;

extern void txi_handler(sci_hdl_t const hdl);
extern void rxi_handler(sci_hdl_t const hdl);
extern void eri_handler(sci_hdl_t const hdl);
extern void tei_handler(sci_hdl_t const hdl);

/*****************************************************************************
* Function Name: my_sci_callback
* Description  : This is a template for an SCI Async Mode callback function.
* Arguments    : pArgs -
*                    pointer to sci_cb_args_t structure cast to a void. Structure
*                    contains event and associated data.
* Return Value : none
******************************************************************************/
void test_sci_callback(void *pArgs)
{
    sci_cb_args_t   *args;

    args = (sci_cb_args_t *)pArgs;
    callback_called_flag = true;

    if (args->event == SCI_EVT_RX_CHAR)
    {
        /* From RXI interrupt; received character data is in args->byte */
        nop();
    }
    else if (args->event == SCI_EVT_RX_CHAR_MATCH)
    {
        callback_called_flag_matched = true;
    }
    else if (args->event == SCI_EVT_RXBUF_OVFL)
    {
        /* From RXI interrupt; rx queue is full; 'lost' data is in args->byte
           You will need to increase buffer size or reduce baud rate */
        nop();
    }
    else if (args->event == SCI_EVT_OVFL_ERR)
    {
        /* From receiver overflow error interrupt; error data is in args->byte
           Error condition is cleared in calling interrupt routine */
        nop();
    }
    else if (args->event == SCI_EVT_FRAMING_ERR)
    {
        /* From receiver framing error interrupt; error data is in args->byte
           Error condition is cleared in calling interrupt routine */
        nop();
    }
    else if (args->event == SCI_EVT_PARITY_ERR)
    {
        /* From receiver parity error interrupt; error data is in args->byte
           Error condition is cleared in calling interrupt routine */
        nop();
    }
}

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Open_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_Open_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
    g_sci_handle->mode = SCI_MODE_OFF;
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Open_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Open_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_Open_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Open_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_001
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = 100;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_CHAN, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_002
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_OFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_003
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = (sci_mode_t)100;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_004
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;
    p_cfg = NULL;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_005
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;
    p_cfg = FIT_NO_PTR;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_006
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_006)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;
    p_callback = NULL;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_007
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_007)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;
    p_callback = FIT_NO_PTR;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_008
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_008)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    p_callback = test_sci_callback;
    mode = SCI_MODE_ASYNC;
    p_hdl = NULL;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_009
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_009)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    p_callback = test_sci_callback;
    mode = SCI_MODE_ASYNC;
    p_hdl = FIT_NO_PTR;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_010
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_010)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_011
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_011)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH5;
    mode = SCI_MODE_SSPI;

    p_cfg->sspi.bit_rate       = 1000000;
    p_cfg->sspi.int_priority   = 3;
    p_cfg->sspi.invert_data    = false;
    p_cfg->sspi.msb_first      = false;
    p_cfg->sspi.spi_mode       = SCI_SPI_MODE_0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_012
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_012)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH6;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_013
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_013)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH8;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_014
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_014)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SSPI;

    p_cfg->sspi.bit_rate       = 1000000;
    p_cfg->sspi.int_priority   = 3;
    p_cfg->sspi.invert_data    = false;
    p_cfg->sspi.msb_first      = false;
    p_cfg->sspi.spi_mode       = SCI_SPI_MODE_0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_015
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_015)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_016
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_016)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH11;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_017
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_017)
{
#if defined (BSP_MCU_RX65N)
    TEST_IGNORE_MESSAGE("TG001_017 NOT support RX65N MCU");
#elif defined (BSP_MCU_RX72M)
    TEST_IGNORE_MESSAGE("TG001_017 NOT support RX72M MCU");
#else
#endif
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH2;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_NOT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_018
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_018)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.data_size    = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_NOT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_019
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_019)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    r_byteq_open_fail_flag = true;
    chan = SCI_CH1;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_QUEUE_UNAVAILABLE, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_020
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_020)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_cfg->sync.spi_mode     = SCI_SPI_MODE_0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_NOT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_021
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
 TEST(R_SCI_Open_Test, TG001_021)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH1;
    mode = SCI_MODE_SYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_022
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_022)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.data_size    = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_023
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_023)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.stop_bits    = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_024
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_024)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.int_priority = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_025
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_025)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.parity_en    = SCI_PARITY_ON;
    p_cfg->async.parity_type  = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_025
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_026
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_026)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.parity_en    = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_026
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_027
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_027)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.baud_rate    = 0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_027
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_028
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_028)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.clk_src      = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_028
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_029
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_029)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);
    R_SCI_Close(*p_hdl);

    g_sci_handle->pclk_speed = 0;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_029
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_030
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_030)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.clk_src      = SCI_CLK_EXT8X;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_030
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_031
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_031)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_cfg->async.clk_src      = SCI_CLK_EXT16X;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_031
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_032
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_032)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SSPI;

    p_cfg->sspi.bit_rate       = 1000000;
    p_cfg->sspi.int_priority   = 3;
    p_cfg->sspi.invert_data    = false;
    p_cfg->sspi.msb_first      = false;
    p_cfg->sspi.spi_mode       = SCI_SPI_MODE_0;
    p_cfg->sspi.spi_mode     = SCI_SPI_MODE_OFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_032
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_033
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_033)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_cfg->sync.spi_mode     = SCI_SPI_MODE_0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_033
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_034
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_034)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_cfg->sync.bit_rate     = 0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_034
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_035
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_035)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_cfg->sync.int_priority   = 0;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_035
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_036
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_036)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_cfg->sync.int_priority   = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_036
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_037
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_037)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_cfg->sync.spi_mode       = 0xFF;
    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_037
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_038
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_038)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH12;
    mode = SCI_MODE_SYNC;

    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority    = 3;
    p_cfg->sync.invert_data     = false;
    p_cfg->sync.msb_first       = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    p_callback = test_sci_callback;

    R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);
    R_SCI_Close(*p_hdl);

    g_sci_handle->pclk_speed = 0;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_038
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_039
* Description  : Test API function R_SCI_Open()
***********************************************************************************************************************/
TEST(R_SCI_Open_Test, TG001_039)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t* p_cfg = &g_config;
    void (*p_callback)(void *p_args);
    sci_hdl_t *p_hdl = &g_sci_handle;

    chan = SCI_CH9;
    mode = SCI_MODE_ASYNC;

    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest

    p_callback = test_sci_callback;

    error = R_SCI_Open(chan, mode, p_cfg, p_callback, p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Open_Test_TG001_039
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Close_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_Close_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Close_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Close_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_Close_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_SCI_Close_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_001
* Description  : Test API function R_SCI_Close()
***********************************************************************************************************************/
TEST(R_SCI_Close_Test, TG002_001)
{
    sci_err_t error = SCI_SUCCESS;
    sci_hdl_t *p_hdl = NULL;
    uint8_t chan;
    sci_cfg_t cfg;

    chan = SCI_CH1;

    error = R_SCI_Close(*p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Close_Test_TG002_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_002
* Description  : Test API function R_SCI_Close()
***********************************************************************************************************************/
TEST(R_SCI_Close_Test, TG002_002)
{
    sci_err_t error = SCI_SUCCESS;
    sci_hdl_t *p_hdl = NULL;
    uint8_t chan;
    sci_cfg_t cfg;

    p_hdl = &g_sci_handle;
    chan = SCI_CH1;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    error = R_SCI_Open(chan, SCI_MODE_ASYNC, &cfg, test_sci_callback, &g_sci_handle);


    error = R_SCI_Close(*p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Close_Test_TG002_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_003
* Description  : Test API function R_SCI_Close()
***********************************************************************************************************************/
TEST(R_SCI_Close_Test, TG002_003)
{
    sci_err_t error = SCI_SUCCESS;
    sci_hdl_t *p_hdl = NULL;
    uint8_t chan;
    sci_cfg_t cfg;

    p_hdl = &g_sci_handle;
    chan = SCI_CH1;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    error = R_SCI_Open(chan, SCI_MODE_SSPI, &cfg, test_sci_callback, &g_sci_handle);


    error = R_SCI_Close(*p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Close_Test_TG002_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_004
* Description  : Test API function R_SCI_Close()
***********************************************************************************************************************/
TEST(R_SCI_Close_Test, TG002_004)
{
    sci_err_t error = SCI_SUCCESS;
    sci_hdl_t *p_hdl = NULL;
    uint8_t chan;
    sci_cfg_t cfg;

    p_hdl = FIT_NO_PTR;
    chan = SCI_CH1;

    error = R_SCI_Close(*p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Close_Test_TG002_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_005
* Description  : Test API function R_SCI_Close()
***********************************************************************************************************************/
TEST(R_SCI_Close_Test, TG002_005)
{
    sci_err_t error = SCI_SUCCESS;
    sci_hdl_t *p_hdl = NULL;
    uint8_t chan;
    sci_cfg_t cfg;

    p_hdl = &g_sci_handle;
    chan = SCI_CH11;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    error = R_SCI_Open(chan, SCI_MODE_ASYNC, &cfg, test_sci_callback, &g_sci_handle);


    error = R_SCI_Close(*p_hdl);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rx_curr_thresh);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Close_Test_TG002_005
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Send_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_Send_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Send_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Send_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_Send_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }

}
/***********************************************************************************************************************
End of function TEST_R_SCI_Send_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_001
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_001)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 1;
    uint8_t *psrc      = NULL;

    g_sci_handle->mode = SCI_MODE_ASYNC;
    psrc = (uint8_t *)malloc(length);

    ret = R_SCI_Send(NULL, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_002
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_002)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 1;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_OFF;
    psrc = (uint8_t *)malloc(length);

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_003
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_003)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 1;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_MAX;
    psrc = (uint8_t *)malloc(length);

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_004
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_004)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;

    ret = R_SCI_Send(*p_hdl, psrc, length);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_005
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_005)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    psrc = (uint8_t *)malloc(length);

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_006
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_006)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest
    length = 1;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_007
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_007)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest
    length = 10;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_008
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_008)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest
    length = 10;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);

    g_sci_handle->tx_idle = false;

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_009
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_009)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    mode = SCI_MODE_SYNC;
    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority   = 3;
    p_cfg->sync.invert_data    = false;
    p_cfg->sync.msb_first        = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    length = 1;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_010
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_010)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    mode = SCI_MODE_SYNC;
    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority   = 3;
    p_cfg->sync.invert_data    = false;
    p_cfg->sync.msb_first        = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    length = 10;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_011
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_011)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    mode = SCI_MODE_SYNC;
    p_cfg->sync.bit_rate        = 1000000;
    p_cfg->sync.int_priority   = 3;
    p_cfg->sync.invert_data    = false;
    p_cfg->sync.msb_first        = false;
    p_cfg->sync.spi_mode        = SCI_SPI_MODE_OFF;
    length = 10;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);

    g_sci_handle->tx_idle = false;

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_012
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_012)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    mode = SCI_MODE_SSPI;
    p_cfg->sspi.bit_rate        = 1000000;
    p_cfg->sspi.int_priority    = 3;
    p_cfg->sspi.invert_data     = false;
    p_cfg->sspi.msb_first       = false;
    p_cfg->sspi.spi_mode        = SCI_SPI_MODE_1;
    length = 1;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_013
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_013)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    mode = SCI_MODE_SSPI;
    p_cfg->sspi.bit_rate        = 1000000;
    p_cfg->sspi.int_priority    = 3;
    p_cfg->sspi.invert_data     = false;
    p_cfg->sspi.msb_first       = false;
    p_cfg->sspi.spi_mode        = SCI_SPI_MODE_1;
    length = 10;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_014
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_014)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    mode = SCI_MODE_SSPI;
    p_cfg->sspi.bit_rate        = 1000000;
    p_cfg->sspi.int_priority    = 3;
    p_cfg->sspi.invert_data     = false;
    p_cfg->sspi.msb_first       = false;
    p_cfg->sspi.spi_mode        = SCI_SPI_MODE_1;
    length = 10;
    psrc = (uint8_t *)malloc(length);

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);

    g_sci_handle->tx_idle = false;

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_015
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_015)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest
    length = 1;
    psrc = (uint8_t *)malloc(length);
    r_byteq_unused_fail_flag = true;

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);


    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INSUFFICIENT_SPACE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_016
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_016)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    p_cfg->async.baud_rate    = 115200;
    p_cfg->async.clk_src      = SCI_CLK_INT;
    p_cfg->async.data_size    = SCI_DATA_8BIT;
    p_cfg->async.parity_en    = SCI_PARITY_OFF;
    p_cfg->async.parity_type  = SCI_EVEN_PARITY;
    p_cfg->async.stop_bits    = SCI_STOPBITS_1;
    p_cfg->async.int_priority = 3;    // 1=lowest, 15=highest
    length = 1;
    psrc = (uint8_t *)malloc(length);
    r_byteq_put_fail_flag    = true;

    R_SCI_Open(chan, mode, p_cfg, test_sci_callback, p_hdl);

    ret = R_SCI_Send(*p_hdl, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INSUFFICIENT_SPACE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_017
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_017)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 0;
    uint8_t *psrc      = NULL;
    sci_hdl_t *p_hdl    = NULL;

    p_hdl   = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    psrc = FIT_NO_PTR;

    ret = R_SCI_Send(*p_hdl, psrc, length);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_018
* Description  : Test API function R_SCI_Send()
***********************************************************************************************************************/
TEST(R_SCI_Send_Test, TG003_018)
{
    sci_err_t ret      = SCI_SUCCESS;
    uint8_t chan       = SCI_CH11;
    sci_mode_t mode    = SCI_MODE_ASYNC;
    sci_cfg_t *p_cfg   = &g_config;
    uint16_t length    = 1;
    uint8_t *psrc      = NULL;

    g_sci_handle->mode = SCI_MODE_ASYNC;
    psrc = (uint8_t *)malloc(length);

    ret = R_SCI_Send(FIT_NO_PTR, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Send_Test_TG003_018
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Receive_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_Receive_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Receive_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Receive_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_Receive_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_get_fail_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Receive_Test_TEAR_DOWN
 ***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_001
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_001)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;

    g_sci_handle->mode = SCI_MODE_ASYNC;
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_Receive(NULL, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_002
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_002)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_OFF;
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_003
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_003)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_MAX;
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_004
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_004)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_005
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_005)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    pdst = malloc(1);
    length = 0;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_006
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_006)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                   = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    count = ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count;
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = 10;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = count;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_007
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_007)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                   = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    count = ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count;
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = 9;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = count;
    TEST_ASSERT_NOT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_008
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_008)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    count = ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count;
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = 10;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = count;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_009
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_009)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    count = ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count;
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = 10;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = count;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_010
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_010)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    g_sci_handle->tx_idle = false;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_011
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_011)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                   = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    count = ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count;
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = 9;
    r_byteq_get_fail_flag = true;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = count;
    TEST_ASSERT_EQUAL(SCI_ERR_INSUFFICIENT_DATA, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_012
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_012)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    p_hdl = &g_sci_handle;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);
    count = ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count;
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = 10;
    g_sci_handle->rom->regs->SSR.BYTE = 0x80;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    free(pdst);
    ((byteq_ctrl_t *)(g_sci_handle->u_rx_data.que))->count = count;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_013
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_013)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;

    g_sci_handle->mode = SCI_MODE_ASYNC;
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_Receive(FIT_NO_PTR, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_014
* Description  : Test API function R_SCI_Receive()
***********************************************************************************************************************/
TEST(R_SCI_Receive_Test, TG004_014)
{
    sci_err_t ret = SCI_ERR_XCVR_BUSY;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = NULL;
    sci_hdl_t *p_hdl = NULL;

    g_sci_handle->mode = SCI_MODE_ASYNC;
    pdst = FIT_NO_PTR;
    ret = R_SCI_Receive(*p_hdl, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Receive_Test_TG004_014
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_R_SCI_SendReceive_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_SendReceive_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_R_SCI_SendReceive_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_SendReceive_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_SendReceive_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_R_SCI_SendReceive_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_001
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_001)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;

    g_sci_handle->mode = SCI_MODE_SYNC;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(NULL, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_002
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_002)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    g_sci_handle->mode = (sci_mode_t)100;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_003
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_003)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_SYNC;
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_004
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_004)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_SYNC;
    psrc = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_005
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_005)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    psrc = (uint8_t *)malloc(1);
    pdst = (uint8_t *)malloc(1);
    length = 0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, hdl);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_006
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_006)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_007
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_007)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, hdl);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_008
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_008)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, hdl);
    g_sci_handle->tx_idle = false;
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_NOT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_009
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_009)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, hdl);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_010
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_010)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, hdl);
    g_sci_handle->tx_idle = false;
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_NOT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_011
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_011)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;

    g_sci_handle->mode = SCI_MODE_SYNC;
    psrc = (uint8_t *)malloc(length);
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(FIT_NO_PTR, psrc, pdst, length);
    free(pdst);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_012
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_012)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_SYNC;
    psrc = FIT_NO_PTR;
    pdst = (uint8_t *)malloc(length);
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(pdst);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_013
* Description  : Test API function R_SCI_SendReceive()
***********************************************************************************************************************/
TEST(R_SCI_SendReceive_Test, TG005_013)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = NULL;
    uint8_t *pdst = NULL;
    sci_hdl_t *hdl = NULL;

    hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_SYNC;
    psrc = (uint8_t *)malloc(length);
    pdst = FIT_NO_PTR;
    ret = R_SCI_SendReceive(*hdl, psrc, pdst, length);
    free(psrc);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_SendReceive_Test_TG005_013
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Control_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_Control_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Control_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_Control_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_Control_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    callback_called_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_R_SCI_Control_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_001
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_001)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = NULL;

    chan = SCI_CH11;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_BAUD;
    pargs = malloc(sizeof(sci_baud_t));
    pargs->rate = 57600;
    pargs->pclk = 12000000;
    ret = R_SCI_Control(NULL, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_002
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_002)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    sci_baud_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_OFF;
    cmd = SCI_CMD_CHANGE_BAUD;
    pargs = malloc(sizeof(sci_baud_t));
    pargs->rate = 57600;
    pargs->pclk = 12000000;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_003
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_003)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    sci_baud_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_MAX;
    cmd = SCI_CMD_CHANGE_BAUD;
    pargs = malloc(sizeof(sci_baud_t));
    pargs->rate = 57600;
    pargs->pclk = 12000000;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_BAD_MODE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_004
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_004)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    sci_baud_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_BAUD;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_005
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_005)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_TX_FIFO_THRESH;
    pargs = (uint8_t *)malloc(1);
    *pargs = 20;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_NOT_EQUAL(*((uint8_t *)pargs), g_sci_handle->tx_curr_thresh);
    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_006
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_006)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_RX_FIFO_THRESH;
    pargs = (uint8_t *)malloc(1);
    *pargs = 16;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_NOT_EQUAL(*((uint8_t *)pargs), g_sci_handle->rx_curr_thresh);
    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_007
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_007)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    sci_baud_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHANGE_BAUD;
    pargs = malloc(sizeof(sci_baud_t));
    pargs->rate = 57600;
    pargs->pclk = 12000000;
    pargs->rate = 0;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_008
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_008)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    sci_baud_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHANGE_BAUD;
    pargs = malloc(sizeof(sci_baud_t));
    pargs->rate = 57600;
    pargs->pclk = 12000000;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_009
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_009)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_SSPI;
    cmd = SCI_CMD_EN_CTS_IN;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_010
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_010)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode  = SCI_MODE_SYNC;

    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_EN_CTS_IN;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_011
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_011)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHANGE_TX_FIFO_THRESH;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(*((uint8_t *)pargs), g_sci_handle->tx_curr_thresh);
    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_012
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_012)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH1;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHANGE_TX_FIFO_THRESH;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_013
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_013)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHANGE_RX_FIFO_THRESH;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(*((uint8_t *)pargs), g_sci_handle->rx_curr_thresh);
    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_014
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_014)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH1;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHANGE_RX_FIFO_THRESH;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_015
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_015)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_EN_NOISE_CANCEL;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_016
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_016)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_TX_Q_BYTES_FREE;
    pargs = FIT_NO_PTR;
    g_sci_handle->tx_idle = true;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_017
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_017)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_SSPI;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_XFER_LSB_FIRST;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_018
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_018)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_SSPI;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHECK_XFER_DONE;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_019
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_019)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode  = SCI_MODE_SYNC;

    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_ABORT_XFER;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_020
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_020)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode  = SCI_MODE_SYNC;

    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_CHECK_XFER_DONE;
    pargs = malloc(1);
    *pargs = 5;
    g_sci_handle->tx_idle = false;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_XFER_NOT_DONE, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_021
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_021)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_TX_FIFO_THRESH;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(FIT_NO_PTR, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_022
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_022)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_TX_FIFO_THRESH;
    pargs = FIT_NO_PTR;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_023
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_023)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_CHANGE_RX_FIFO_THRESH;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_024
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_024)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_SET_TXI_PRIORITY;
    pargs = FIT_NO_PTR;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_025
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_025)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_SET_RXI_PRIORITY;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_025
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_026
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_026)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_SET_TXI_PRIORITY;
    pargs = (uint8_t *)malloc(1);
    *pargs = 0;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_026
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_027
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_027)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    g_sci_handle->mode = SCI_MODE_ASYNC;
    cmd = SCI_CMD_SET_RXI_PRIORITY;
    pargs = (uint8_t *)malloc(1);
    *pargs = 0;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    free(pargs);

    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_027
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_028
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_028)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_ASYNC;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_SET_TXI_PRIORITY;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(*((uint8_t *)pargs), *g_sci_handle->rom->ipr_txi);
    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_028
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_029
* Description  : Test API function R_SCI_Control()
***********************************************************************************************************************/
TEST(R_SCI_Control_Test, TG006_029)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_hdl_t  *p_hdl = NULL;
    uint8_t *pargs = NULL;

    chan = SCI_CH11;
    p_hdl = &g_sci_handle;
    mode = SCI_MODE_SSPI;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, p_hdl);

    cmd = SCI_CMD_SET_RXI_PRIORITY;
    pargs = malloc(1);
    *pargs = 5;
    ret = R_SCI_Control(*p_hdl, cmd, pargs);

    TEST_ASSERT_EQUAL(*((uint8_t *)pargs), *g_sci_handle->rom->ipr_rxi);
    free(pargs);

    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_Control_Test_TG006_029
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_R_SCI_GetVersion_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_SCI_GetVersion_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_SCI_GetVersion_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_SCI_GetVersion_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_SCI_GetVersion_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_SCI_GetVersion_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_001
* Description  : Test API function R_SCI_GetVersion()
***********************************************************************************************************************/
TEST(R_SCI_GetVersion_Test, TG007_001)
{
    TEST_ASSERT_EQUAL(0x00030014, R_SCI_GetVersion());
}
/***********************************************************************************************************************
* End of function TEST_R_SCI_GetVersion_Test_TG007_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_txi_handler_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(txi_handler_Test)
{

}
/***********************************************************************************************************************
End of function TEST_txi_handler_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_txi_handler_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(txi_handler_Test)
{
    r_byteq_use_true_flag = false;
}
/***********************************************************************************************************************
End of function TEST_txi_handler_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_001
* Description  : Test API function txi_handler()
***********************************************************************************************************************/
TEST(txi_handler_Test, TG008_001)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    *g_sci_handle->rom->icu_txi |= g_sci_handle->rom->txi_en_mask;
#if SCI_CFG_TEI_INCLUDED
    g_sci_handle->rom->regs->SCR.BIT.TEIE = 0;
    *g_sci_handle->rom->icu_grp &= ~(g_sci_handle->rom->tei_ch_mask);
#endif
    g_sci_handle->tx_idle = false;

    txi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_txi & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.TEIE);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->tei_ch_mask,
                      *g_sci_handle->rom->icu_grp & g_sci_handle->rom->tei_ch_mask);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
}
/***********************************************************************************************************************
* End of function TEST_txi_handler_Test_TG008_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_002
* Description  : Test API function txi_handler()
***********************************************************************************************************************/
TEST(txi_handler_Test, TG008_002)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    r_byteq_use_true_flag = true;

    *g_sci_handle->rom->icu_txi |= g_sci_handle->rom->txi_en_mask;
#if SCI_CFG_TEI_INCLUDED
    g_sci_handle->rom->regs->SCR.BIT.TEIE = 0;
    *g_sci_handle->rom->icu_grp &= ~(g_sci_handle->rom->tei_ch_mask);
#endif
    g_sci_handle->tx_idle = false;

    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL(0, *g_sci_handle->rom->icu_txi & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_NOT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.TEIE);
    TEST_ASSERT_NOT_EQUAL(g_sci_handle->rom->tei_ch_mask,
                      *g_sci_handle->rom->icu_grp & g_sci_handle->rom->tei_ch_mask);
    TEST_ASSERT_NOT_EQUAL(true, g_sci_handle->tx_idle);

    g_sci_handle->tx_idle = true;
}
/***********************************************************************************************************************
* End of function TEST_txi_handler_Test_TG008_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_rxi_handler_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(rxi_handler_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_rxi_handler_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_rxi_handler_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(rxi_handler_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_put_fail_flag = false;
    callback_called_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_rxi_handler_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_001
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_001)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                   = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_002
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_002)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_003
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_003)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_004
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_004)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                   = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    r_byteq_put_fail_flag = true;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_005
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_005)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    mode                   = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_006
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_006)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->tx_cnt = 10;
    g_sci_handle->rx_cnt = 10;
    g_sci_handle->tx_dummy = true;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_007
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_007)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->tx_cnt = 1;
    g_sci_handle->rx_cnt = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_008
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_008)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->tx_cnt = 1;
    g_sci_handle->rx_cnt = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_009
* Description  : Test API function rxi_handler()
***********************************************************************************************************************/
TEST(rxi_handler_Test, TG009_009)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->tx_cnt = 10;
    g_sci_handle->rx_cnt = 10;
    g_sci_handle->tx_dummy = false;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_rxi_handler_Test_TG009_009
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_eri_handler_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(eri_handler_Test)
{

}
/***********************************************************************************************************************
End of function TEST_eri_handler_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_eri_handler_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(eri_handler_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_put_fail_flag = false;
    callback_called_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_eri_handler_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_001
* Description  : Test API function eri_handler()
***********************************************************************************************************************/
TEST(eri_handler_Test, TG010_001)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSR.BYTE = 0;
    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_eri_handler_Test_TG010_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_002
* Description  : Test API function eri_handler()
***********************************************************************************************************************/
TEST(eri_handler_Test, TG010_002)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    char key;
    printf("Set breakpoint at line 1845 r_sci_rx.c\n");
    printf("Press any key to continue\n");
    printf("At line 1845: Set hdl->rom->regs->SSR.BYTE to 0xC8\n");
    printf("Press F8\n");
    printf("Remove breakpoint\n");
    key = getchar();

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSR.BYTE = SCI_SSR_ORER_MASK;
    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_eri_handler_Test_TG010_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_003
* Description  : Test API function eri_handler()
***********************************************************************************************************************/
TEST(eri_handler_Test, TG010_003)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSR.BYTE = SCI_SSR_PER_MASK;
    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_eri_handler_Test_TG010_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_004
* Description  : Test API function eri_handler()
***********************************************************************************************************************/
TEST(eri_handler_Test, TG010_004)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSR.BYTE = SCI_SSR_FER_MASK;
    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_eri_handler_Test_TG010_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_005
* Description  : Test API function eri_handler()
***********************************************************************************************************************/
TEST(eri_handler_Test, TG010_005)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSR.BYTE = SCI_SSR_FER_MASK;
    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_eri_handler_Test_TG010_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_006
* Description  : Test API function eri_handler()
***********************************************************************************************************************/
TEST(eri_handler_Test, TG010_006)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSR.BYTE = SCI_SSR_FER_MASK;
    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_eri_handler_Test_TG010_006
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_power_on_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(power_on_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_power_on_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_power_on_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(power_on_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_put_fail_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_power_on_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG011_001
* Description  : Test API function power_on()
***********************************************************************************************************************/
TEST(power_on_Test, TG011_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_power_on_Test_TG011_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_power_off_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(power_off_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_power_off_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_power_off_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(power_off_Test)
{
}
/***********************************************************************************************************************
End of function TEST_power_off_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_001
* Description  : Test API function power_off()
***********************************************************************************************************************/
TEST(power_off_Test, TG012_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Close(g_sci_handle);

    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->stop_mask, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_power_off_Test_TG012_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_init_register_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_init_register_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_init_register_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_init_register_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_init_register_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret =  R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_init_register_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_001
* Description  : Test API function sci_init_register()
***********************************************************************************************************************/
TEST(sci_init_register_Test, TG013_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    g_sci_handle->rom->regs->SCR.BIT.TE   = 1;
    g_sci_handle->rom->regs->SCR.BIT.RE   = 0;
    g_sci_handle->rom->regs->SSR.BIT.ORER = 1;
    g_sci_handle->rom->regs->SSR.BIT.PER  = 0;
    g_sci_handle->rom->regs->SSR.BIT.FER  = 0;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.TE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.RE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0xF0, g_sci_handle->rom->regs->SCR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SSR.BIT.ORER);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(0x19, g_sci_handle->rom->regs->BRR);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SEMR.BIT.NFEN);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SNFR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CTSE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPOL);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPH);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_register_Test_TG013_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_002
* Description  : Test API function sci_init_register()
***********************************************************************************************************************/
TEST(sci_init_register_Test, TG013_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    g_sci_handle->rom->regs->SCR.BIT.TE   = 0;
    g_sci_handle->rom->regs->SCR.BIT.RE   = 0;
    g_sci_handle->rom->regs->SSR.BIT.ORER = 0;
    g_sci_handle->rom->regs->SSR.BIT.PER  = 1;
    g_sci_handle->rom->regs->SSR.BIT.FER  = 0;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.TE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.RE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0xF0, g_sci_handle->rom->regs->SCR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SSR.BIT.PER);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(0x19, g_sci_handle->rom->regs->BRR);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SEMR.BIT.NFEN);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SNFR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CTSE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPOL);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPH);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_register_Test_TG013_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_003
* Description  : Test API function sci_init_register()
***********************************************************************************************************************/
TEST(sci_init_register_Test, TG013_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    g_sci_handle->rom->regs->SCR.BIT.TE   = 1;
    g_sci_handle->rom->regs->SCR.BIT.RE   = 1;
    g_sci_handle->rom->regs->SSR.BIT.ORER = 0;
    g_sci_handle->rom->regs->SSR.BIT.PER  = 0;
    g_sci_handle->rom->regs->SSR.BIT.FER  = 1;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.TE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.RE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0xF0, g_sci_handle->rom->regs->SCR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SSR.BIT.FER);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(0x19, g_sci_handle->rom->regs->BRR);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SEMR.BIT.NFEN);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SNFR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CTSE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPOL);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPH);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_register_Test_TG013_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_004
* Description  : Test API function sci_init_register()
***********************************************************************************************************************/
TEST(sci_init_register_Test, TG013_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    g_sci_handle->rom->regs->SCR.BIT.TE   = 1;
    g_sci_handle->rom->regs->SCR.BIT.RE   = 0;
    g_sci_handle->rom->regs->SSR.BIT.ORER = 0;
    g_sci_handle->rom->regs->SSR.BIT.PER  = 0;
    g_sci_handle->rom->regs->SSR.BIT.FER  = 0;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.TE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCR.BIT.RE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0xF0, g_sci_handle->rom->regs->SCR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(0x19, g_sci_handle->rom->regs->BRR);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SEMR.BIT.NFEN);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SNFR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CTSE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPOL);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BIT.CKPH);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_register_Test_TG013_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_init_async_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_init_async_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_init_async_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_init_async_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_init_async_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_init_async_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_001
* Description  : Test API function sci_init_async()
***********************************************************************************************************************/
TEST(sci_init_async_Test, TG014_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_7BIT;
    cfg.async.parity_en    = SCI_PARITY_ON;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(0x60, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(115200, g_sci_handle->baud_rate);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCR.BIT.CKE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_async_Test_TG014_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_002
* Description  : Test API function sci_init_async()
***********************************************************************************************************************/
TEST(sci_init_async_Test, TG014_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_7BIT;
    cfg.async.parity_en    = SCI_PARITY_ON;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.stop_bits    = SCI_STOPBITS_2;
    cfg.async.parity_type  = SCI_ODD_PARITY;
    cfg.async.clk_src      = SCI_CLK_EXT8X;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(0x38, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(115200, g_sci_handle->baud_rate);
    TEST_ASSERT_EQUAL(0x02, g_sci_handle->rom->regs->SCR.BIT.CKE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_async_Test_TG014_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_003
* Description  : Test API function sci_init_async()
***********************************************************************************************************************/
TEST(sci_init_async_Test, TG014_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_7BIT;
    cfg.async.parity_en    = SCI_PARITY_ON;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.clk_src      = SCI_CLK_EXT16X;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(115200, g_sci_handle->baud_rate);
    TEST_ASSERT_EQUAL(0x02, g_sci_handle->rom->regs->SCR.BIT.CKE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_async_Test_TG014_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_004
* Description  : Test API function sci_init_async()
***********************************************************************************************************************/
TEST(sci_init_async_Test, TG014_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_7BIT;
    cfg.async.parity_en    = SCI_PARITY_ON;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.baud_rate    = 0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->pclk_speed = 0;
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_async_Test_TG014_004
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_init_sync_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_init_sync_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_init_sync_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_init_sync_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_init_sync_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_init_sync_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_001
* Description  : Test API function sci_init_sync()
***********************************************************************************************************************/
TEST(sci_init_sync_Test, TG015_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = true;
    cfg.sync.msb_first       = true;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;
    cfg.sspi.invert_data    = true;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(0x80, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SIMR1.BIT.IICM);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SPMR.BYTE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_sync_Test_TG015_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_002
* Description  : Test API function sci_init_sync()
***********************************************************************************************************************/
TEST(sci_init_sync_Test, TG015_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode                    = SCI_MODE_SSPI;
    cfg.sspi.bit_rate       = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first      = true;
    cfg.sspi.spi_mode       = SCI_SPI_MODE_0;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(0x80, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(cfg.sspi.spi_mode, g_sci_handle->rom->regs->SPMR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_sync_Test_TG015_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_003
* Description  : Test API function sci_init_sync()
***********************************************************************************************************************/
TEST(sci_init_sync_Test, TG015_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode                    = SCI_MODE_SSPI;
    cfg.sspi.bit_rate       = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first      = true;
    cfg.sspi.spi_mode       = SCI_SPI_MODE_1;
    cfg.sspi.invert_data    = true;
    cfg.sspi.msb_first      = false;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(0x80, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(cfg.sspi.spi_mode, g_sci_handle->rom->regs->SPMR.BYTE);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_sync_Test_TG015_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_004
* Description  : Test API function sci_init_sync()
***********************************************************************************************************************/
TEST(sci_init_sync_Test, TG015_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode                    = SCI_MODE_SSPI;
    cfg.sspi.bit_rate       = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first      = true;
    cfg.sspi.spi_mode       = SCI_SPI_MODE_2;
    cfg.sspi.msb_first      = false;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(0x80, g_sci_handle->rom->regs->SMR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SMIF);
    TEST_ASSERT_EQUAL(cfg.sspi.spi_mode, g_sci_handle->rom->regs->SPMR.BYTE);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(3, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_sync_Test_TG015_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_005
* Description  : Test API function sci_init_sync()
***********************************************************************************************************************/
TEST(sci_init_sync_Test, TG015_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode                    = SCI_MODE_SSPI;
    cfg.sspi.bit_rate       = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first      = true;
    cfg.sspi.spi_mode       = SCI_SPI_MODE_3;
    cfg.sspi.invert_data    = true;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->pclk_speed = 0;
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_MODE_OFF, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_sync_Test_TG015_005
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_init_queues_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_init_queues_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_init_queues_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_init_queues_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_init_queues_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_init_queues_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_001
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH1;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_002
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH5;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_003
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH6;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_004
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH8;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_005
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH11;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_006
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_006)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH12;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_007
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_007)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH9;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_007
***********************************************************************************************************************/

#if defined (BSP_MCU_RX65N) || defined (BSP_MCU_RX72M)
/***********************************************************************************************************************
* Function Name: TG016_008
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_008)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_009
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_009)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH3;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_010
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_010)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH4;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_011
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_011)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH7;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_012
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_012)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH10;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_013
* Description  : Test API function sci_init_queues()
***********************************************************************************************************************/
TEST(sci_init_queues_Test, TG016_013)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    chan = SCI_CH2;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_tx_data.que);
    TEST_ASSERT_NOT_EQUAL(NULL, g_sci_handle->u_rx_data.que);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, (*g_sci_handle->rom->mstp & g_sci_handle->rom->stop_mask));
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_queues_Test_TG016_013
***********************************************************************************************************************/
#endif

/***********************************************************************************************************************
* Function Name: TEST_sci_initialize_ints_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_initialize_ints_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_initialize_ints_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_initialize_ints_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_initialize_ints_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_initialize_ints_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG017_001
* Description  : Test API function sci_initialize_ints()
***********************************************************************************************************************/
TEST(sci_initialize_ints_Test, TG017_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(cfg.async.int_priority, *g_sci_handle->rom->ipr_rxi);
    TEST_ASSERT_EQUAL(cfg.async.int_priority, *g_sci_handle->rom->ipr_txi);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->eri_ch_mask, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->eri_ch_mask);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->rxi_en_mask, *g_sci_handle->rom->icu_rxi & g_sci_handle->rom->rxi_en_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->tei_ch_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_rxi);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
}
/***********************************************************************************************************************
* End of function TEST_sci_initialize_ints_Test_TG017_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_init_bit_rate_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_init_bit_rate_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_init_bit_rate_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_init_bit_rate_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_init_bit_rate_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_init_bit_rate_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG018_001
* Description  : Test API function sci_init_bit_rate()
***********************************************************************************************************************/
TEST(sci_init_bit_rate_Test, TG018_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(0x19, g_sci_handle->rom->regs->BRR);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SMR.BIT.CKS);

}
/***********************************************************************************************************************
* End of function TEST_sci_init_bit_rate_Test_TG018_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG018_002
* Description  : Test API function sci_init_bit_rate()
***********************************************************************************************************************/
TEST(sci_init_bit_rate_Test, TG018_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(5, g_sci_handle->rom->regs->BRR);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SEMR.BIT.ABCS);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SMR.BIT.CKS);

}
/***********************************************************************************************************************
* End of function TEST_sci_init_bit_rate_Test_TG018_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_disable_ints_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_disable_ints_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_disable_ints_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_disable_ints_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_disable_ints_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_disable_ints_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG019_001
* Description  : Test API function sci_disable_ints()
***********************************************************************************************************************/
TEST(sci_disable_ints_Test, TG019_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Close(g_sci_handle);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->eri_ch_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->rxi_en_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->tei_ch_mask);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCR.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_disable_ints_Test_TG019_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_send_async_data_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_send_async_data_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_send_async_data_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_send_async_data_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_send_async_data_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;
    
    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_send_async_data_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_001
* Description  : Test API function sci_send_async_data()
***********************************************************************************************************************/
TEST(sci_send_async_data_Test, TG020_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = (uint8_t *)malloc(length);

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    chan = SCI_CH1;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
   
    g_sci_handle->tx_idle = true;

    error = R_SCI_Send(g_sci_handle, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);

    TEST_ASSERT_EQUAL(g_sci_handle->rom->txi_en_mask, *g_sci_handle->rom->icu_txi & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_send_async_data_Test_TG020_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_002
* Description  : Test API function sci_send_async_data()
***********************************************************************************************************************/
TEST(sci_send_async_data_Test, TG020_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = (uint8_t *)malloc(length);

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    chan = SCI_CH11;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    g_sci_handle->rom->regs->FDR.BIT.T = 1;

    error = R_SCI_Send(g_sci_handle, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);

    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_send_async_data_Test_TG020_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG020_003
* Description  : Test API function sci_send_async_data()
***********************************************************************************************************************/
TEST(sci_send_async_data_Test, TG020_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = (uint8_t *)malloc(length);

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    chan = SCI_CH11;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    g_sci_handle->rom->regs->FDR.BIT.T = 0;

    error = R_SCI_Send(g_sci_handle, psrc, length);
    free(psrc);

    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);

    TEST_ASSERT_EQUAL(g_sci_handle->rom->txi_en_mask, *g_sci_handle->rom->icu_txi & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_send_async_data_Test_TG020_003
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_send_sync_data_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_send_sync_data_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_send_sync_data_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_send_sync_data_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_send_sync_data_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_send_sync_data_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_001
* Description  : Test API function sci_send_sync_data()
***********************************************************************************************************************/
TEST(sci_send_sync_data_Test, TG021_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = (uint8_t *)malloc(length);
    
    chan = SCI_CH11;
    mode = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first        = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->tx_idle = true;

    error = R_SCI_Send(g_sci_handle, psrc, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(false, g_sci_handle->save_rx_data);
    //TODO TEST_ASSERT_EQUAL(length-1, g_sci_handle->tx_cnt);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    free(psrc);
}
/***********************************************************************************************************************
* End of function TEST_sci_send_sync_data_Test_TG021_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_002
* Description  : Test API function sci_send_sync_data()
***********************************************************************************************************************/
TEST(sci_send_sync_data_Test, TG021_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = (uint8_t *)malloc(length);
    
    chan = SCI_CH11;
    mode = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->tx_idle = false;
    error = R_SCI_Send(g_sci_handle, psrc, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
    free(psrc);
}
/***********************************************************************************************************************
* End of function TEST_sci_send_sync_data_Test_TG021_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG021_003
* Description  : Test API function sci_send_sync_data()
***********************************************************************************************************************/
TEST(sci_send_sync_data_Test, TG021_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint8_t *psrc = (uint8_t *)malloc(length);
    
    chan = SCI_CH1;
    mode = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first        = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->tx_idle = true;

    error = R_SCI_Send(g_sci_handle, psrc, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    TEST_ASSERT_EQUAL(false, g_sci_handle->save_rx_data);
    //TODO TEST_ASSERT_EQUAL(length-1, g_sci_handle->tx_cnt);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    free(psrc);
}
/***********************************************************************************************************************
* End of function TEST_sci_send_sync_data_Test_TG021_003
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_receive_async_data_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_receive_async_data_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_receive_async_data_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_receive_async_data_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_receive_async_data_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_receive_async_data_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG022_001
* Description  : Test API function sci_receive_async_data()
***********************************************************************************************************************/
TEST(sci_receive_async_data_Test, TG022_001)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = (uint8_t *)malloc(length);

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->u_rx_data.que->count = length;
    ret = R_SCI_Receive(g_sci_handle, pdst, length);

    TEST_ASSERT_EQUAL(0, g_sci_handle->u_rx_data.que->count);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, ret);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_async_data_Test_TG022_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG022_002
* Description  : Test API function sci_receive_async_data()
***********************************************************************************************************************/
TEST(sci_receive_async_data_Test, TG022_002)
{
    sci_err_t ret = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    uint16_t length = 10;
    uint16_t count = 0;
    uint8_t *pdst = (uint8_t *)malloc(length);

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    r_byteq_get_fail_flag = true;
    g_sci_handle->u_rx_data.que->count = length;
    ret = R_SCI_Receive(g_sci_handle, pdst, length);

    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INSUFFICIENT_DATA, ret);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_async_data_Test_TG022_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_receive_sync_data_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_receive_sync_data_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_receive_sync_data_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_receive_sync_data_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_receive_sync_data_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_put_fail_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_receive_sync_data_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_001
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH11;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = false;
    length = 5;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_002
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH11;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 20;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_003
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH11;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 15;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_004
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH11;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 10;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_005
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH1;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    length = 5;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_006
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_006)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = false;
    length = 5;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_007
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_007)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 20;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_008
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_008)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 15;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_009
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_009)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 10;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_010
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_010)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH8;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = false;
    length = 5;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_011
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_011)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH8;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 20;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_012
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_012)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH8;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 15;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_013
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_013)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH8;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 10;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_014
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_014)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH9;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = false;
    length = 5;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_015
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_015)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH9;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 20;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_016
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_016)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH9;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 15;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_017
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_017)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH9;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 10;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_018
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_018)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH10;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = false;
    length = 5;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_ERR_XCVR_BUSY, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_019
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_019)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH10;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 20;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_020
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_020)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH10;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 15;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG023_021
* Description  : Test API function sci_receive_sync_data()
***********************************************************************************************************************/
TEST(sci_receive_sync_data_Test, TG023_021)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    uint16_t length;
    uint8_t *pdst;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    chan = SCI_CH10;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_idle = true;
    length = 12;
    g_sci_handle->rx_curr_thresh = 10;
    pdst = (uint8_t *)malloc(length);
    error = R_SCI_Receive(g_sci_handle, pdst, length);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(pdst, g_sci_handle->u_rx_data.buf);
    TEST_ASSERT_EQUAL(true, g_sci_handle->save_rx_data);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(length, g_sci_handle->rx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pdst);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_sync_data_Test_TG023_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_async_cmds_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_async_cmds_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_async_cmds_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_async_cmds_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_async_cmds_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_async_cmds_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_001
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_EN_NOISE_CANCEL;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.NFEN);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SNFR.BYTE);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(0xF0, g_sci_handle->rom->regs->SCR.BYTE);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_002
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_OUTPUT_BAUD_CLK;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(0x01, g_sci_handle->rom->regs->SCR.BIT.CKE);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_003
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_TX_Q_FLUSH;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->txi_en_mask, *g_sci_handle->rom->icu_txi & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_004
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_RX_Q_FLUSH;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->rxi_en_mask, *g_sci_handle->rom->icu_rxi & g_sci_handle->rom->rxi_en_mask);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_005
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_TX_Q_BYTES_FREE;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_006
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_006)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_RX_Q_BYTES_AVAIL_TO_READ;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_007
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_007)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    char key;
#if defined (BSP_MCU_RX65N)
    printf("Set breakpoint 1 at line 1040 (r_sci_rx65n.c) and change hdl->rom->regs->SSR.BIT.TEND value to 1 to continue to run\n");
    printf("Please strictly follow steps below to run this test case:\n");
    printf("1. Set breakpoint at line 1040 (r_sci_rx65n.c), press any key to continue.\n");
    printf("2. At breakpoint line 1040, change hdl->rom->regs->SSR.BIT.TEND value to 1, remove breakpoint, then press F8\n");
#elif defined (BSP_MCU_RX66T)
    printf("Set breakpoint at line 637 (r_sci_66t.c) and change hdl->rom->regs->SSR.BIT.TEND value to 1 to continue to run\n");
    printf("Please strictly follow steps below to run this test case:\n");
    printf("1. Set breakpoint at line 637 (r_sci_66t.c), press any key to continue.\n");
    printf("2. At breakpoint line 637, change hdl->rom->regs->SSR.BIT.TEND value to 1, remove breakpoint, then press F8\n");
#elif defined (BSP_MCU_RX72T)
    printf("Set breakpoint at line 635 (r_sci_72t.c) and change hdl->rom->regs->SSR.BIT.TEND value to 1 to continue to run\n");
    printf("Please strictly follow steps below to run this test case:\n");
    printf("1. Set breakpoint at line 635 (r_sci_72t.c), press any key to continue.\n");
    printf("2. At breakpoint line 635, change hdl->rom->regs->SSR.BIT.TEND value to 1, remove breakpoint, then press F8\n");
#elif defined (BSP_MCU_RX72M)
    printf("Set breakpoint 1 at line 1031 (r_sci_rx72m.c) and change hdl->rom->regs->SSR.BIT.TEND value to 1 to continue to run\n");
    printf("Please strictly follow steps below to run this test case:\n");
    printf("1. Set breakpoint at line 1031 (r_sci_rx72m.c), press any key to continue.\n");
    printf("2. At breakpoint line 1031, change hdl->rom->regs->SSR.BIT.TEND value to 1, remove breakpoint, then press F8\n");
#else
#endif
    key = getchar();

    cmd = SCI_CMD_GENERATE_BREAK;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->txi_en_mask, *g_sci_handle->rom->icu_txi & g_sci_handle->rom->txi_en_mask);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_008
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_008)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = 0xFE;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_009
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_009)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_START_BIT_EDGE;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SEMR.BIT.RXDESEL);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_010
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_010)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_COMPARE_RECEIVED_DATA;
    pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->DCCR.BIT.DFER);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->DCCR.BIT.DPER);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->DCCR.BIT.DCME);
    TEST_ASSERT_EQUAL(*((unsigned char *)pargs), g_sci_handle->rom->regs->CDR.BIT.CMPD);
    TEST_ASSERT_EQUAL(SCI_MODE_ASYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_011
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_011)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_COMPARE_RECEIVED_DATA;
    pargs = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG024_012
* Description  : Test API function sci_async_cmds()
***********************************************************************************************************************/
TEST(sci_async_cmds_Test, TG024_012)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs;


    cmd = SCI_CMD_COMPARE_RECEIVED_DATA;
    pargs = FIT_NO_PTR;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest

    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    error = R_SCI_Control(g_sci_handle, cmd, pargs);
    TEST_ASSERT_EQUAL(SCI_ERR_NULL_PTR, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_async_cmds_Test_TG024_012
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_sync_cmds_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_sync_cmds_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_sync_cmds_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_sync_cmds_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_sync_cmds_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_sync_cmds_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_001
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_CHECK_XFER_DONE;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->tx_idle = false;
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_ERR_XFER_NOT_DONE, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_002
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_002)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_CHECK_XFER_DONE;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->tx_idle = true;
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_003
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_XFER_LSB_FIRST;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_004
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_XFER_MSB_FIRST;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->SCMR.BIT.SDIR);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_005
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_INVERT_DATA;
    unsigned char sdir_reg = g_sci_handle->rom->regs->SCMR.BIT.SINV;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL((sdir_reg == 0) ? 1 : 0, g_sci_handle->rom->regs->SCMR.BIT.SINV);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_006
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_006)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_ABORT_XFER;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(0, g_sci_handle->tx_cnt);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
    TEST_ASSERT_EQUAL(false, g_sci_handle->tx_dummy);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_rxi);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->eri_ch_mask, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->eri_ch_mask);
    TEST_ASSERT_EQUAL(g_sci_handle->rom->rxi_en_mask, *g_sci_handle->rom->icu_rxi & g_sci_handle->rom->rxi_en_mask);
    TEST_ASSERT_EQUAL(SCI_SCR_RE_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_SCR_RE_MASK);
    TEST_ASSERT_EQUAL(SCI_SCR_TE_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_SCR_TE_MASK);
    TEST_ASSERT_EQUAL(SCI_SCR_REI_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_SCR_REI_MASK);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_007
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_007)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_baud_t *pargs = (sci_baud_t *)malloc(sizeof(sci_baud_t));
    pargs->rate = 0;

    mode                     = SCI_MODE_SYNC;
    cfg.sync.bit_rate        = 1000000;
    cfg.sync.int_priority    = 3;
    cfg.sync.invert_data     = false;
    cfg.sync.msb_first       = false;
    cfg.sync.spi_mode        = SCI_SPI_MODE_OFF;

    cmd                      = SCI_CMD_CHANGE_SPI_MODE;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SYNC, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
    free(pargs);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_008
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_008)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_spi_mode_t pargs = SCI_SPI_MODE_OFF;

    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    cmd                      = SCI_CMD_CHANGE_SPI_MODE;
    pargs = 0xFF;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_009
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_009)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_spi_mode_t pargs = SCI_SPI_MODE_OFF;

    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    cmd                      = SCI_CMD_CHANGE_SPI_MODE;
    pargs = SCI_SPI_MODE_3;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(*((uint8_t *)pargs), g_sci_handle->rom->regs->SPMR.BYTE & *((uint8_t *)pargs));
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->ir_txi);
    TEST_ASSERT_EQUAL(SCI_EN_XCVR_MASK, g_sci_handle->rom->regs->SCR.BYTE & SCI_EN_XCVR_MASK);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG025_010
* Description  : Test API function sci_sync_cmds()
***********************************************************************************************************************/
TEST(sci_sync_cmds_Test, TG025_010)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    sci_cmd_t cmd;
    sci_spi_mode_t pargs = SCI_SPI_MODE_OFF;

    mode                     = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;

    cmd                      = 0xFE;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    error = R_SCI_Control(g_sci_handle, cmd, &pargs);
    TEST_ASSERT_EQUAL(SCI_MODE_SSPI, g_sci_handle->mode);
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_sync_cmds_Test_TG025_010
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_tei_handler_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(tei_handler_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_tei_handler_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_tei_handler_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(tei_handler_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_tei_handler_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG026_001
* Description  : Test API function tei_handler()
***********************************************************************************************************************/
TEST(tei_handler_Test, TG026_001)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    tei_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->tei_ch_mask);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCR.BIT.TEIE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_tei_handler_Test_TG026_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG026_002
* Description  : Test API function tei_handler()
***********************************************************************************************************************/
TEST(tei_handler_Test, TG026_002)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    tei_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, *g_sci_handle->rom->icu_grp & g_sci_handle->rom->tei_ch_mask);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->SCR.BIT.TEIE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_tei_handler_Test_TG026_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_transfer_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_fifo_transfer_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_transfer_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_transfer_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_fifo_transfer_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_use_false_flag   = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_transfer_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_001
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_001)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 1;
    txi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_002
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_002)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    g_sci_handle->tx_idle = false;
    r_byteq_use_true_flag = true;

    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_003
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_003)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    r_byteq_use_false_flag = true;
    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_004
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_004)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 1;
    txi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_005
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_005)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    g_sci_handle->tx_idle = false;
    r_byteq_use_true_flag = true;

    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_006
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_006)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    r_byteq_use_false_flag = true;
    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_007
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_007)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 1;
    txi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_008
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_008)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    g_sci_handle->tx_idle = false;
    r_byteq_use_true_flag = true;

    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_009
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_009)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    r_byteq_use_false_flag = true;
    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_010
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_010)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 1;
    txi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_011
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_011)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    g_sci_handle->tx_idle = false;
    r_byteq_use_true_flag = true;

    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_012
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_012)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    r_byteq_use_false_flag = true;
    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_013
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_013)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 1;
    txi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_014
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_014)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    g_sci_handle->tx_idle = false;
    r_byteq_use_true_flag = true;

    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG027_015
* Description  : Test API function sci_fifo_transfer()
***********************************************************************************************************************/
TEST(sci_fifo_transfer_Test, TG027_015)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.TDFE = 0;
    r_byteq_use_false_flag = true;
    txi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_TDFE_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_transfer_Test_TG027_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_receive_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_fifo_receive_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_receive_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_receive_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_fifo_receive_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;
    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_receive_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_001
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_001)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_002
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_002)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_003
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_003)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_004
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_004)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_005
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_005)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_006
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_006)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_007
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_007)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    r_byteq_unused_fail_flag = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_007
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TG028_008
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_008)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_009
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_009)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_010
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_010)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_011
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_011)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_012
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_012)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_013
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_013)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_014
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_014)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    r_byteq_unused_fail_flag = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_014
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TG028_015
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_015)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_016
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_016)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_017
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_017)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_018
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_018)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_019
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_019)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_020
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_020)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_021
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_021)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    r_byteq_unused_fail_flag = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_021
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TG028_022
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_022)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_023
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_023)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_024
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_024)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_025
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_025)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_025
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_026
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_026)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_026
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_027
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_027)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_027
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_028
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_028)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    r_byteq_unused_fail_flag = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_028
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TG028_029
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_029)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_029
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_030
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_030)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_030
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_031
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_031)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_031
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_032
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_032)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_032
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_033
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_033)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    mode                    = SCI_MODE_SYNC;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_033
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_034
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_034)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    g_sci_handle->rom->regs->SSRFIFO.BIT.RDF = 1;
    g_sci_handle->rom->regs->SSRFIFO.BIT.DR = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_NOT_EQUAL((unsigned char)~SCI_SSRFIFO_RDF_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL((unsigned char)~SCI_SSRFIFO_DR_MASK, g_sci_handle->rom->regs->SSRFIFO.BYTE);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_034
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG028_035
* Description  : Test API function sci_fifo_receive()
***********************************************************************************************************************/
TEST(sci_fifo_receive_Test, TG028_035)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);
    unsigned char fifo_num = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    r_byteq_unused_fail_flag = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_Test_TG028_035
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_receive_sync_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_fifo_receive_sync_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_receive_sync_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_receive_sync_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_fifo_receive_sync_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_receive_sync_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_001
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_001)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = true;
    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_002
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_002)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = false;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_003
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_003)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R + 1;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_004
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_004)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R - 1;
    g_sci_handle->tx_dummy = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_005
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_005)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = 0;
    g_sci_handle->tx_dummy = false;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_006
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_006)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    g_sci_handle->callback = NULL;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_007
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_007)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_curr_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_008
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_008)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = true;
    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_009
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_009)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = false;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_010
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_010)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R + 1;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_011
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_011)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R - 1;
    g_sci_handle->tx_dummy = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_012
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_012)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = 0;
    g_sci_handle->tx_dummy = false;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_013
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_013)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    g_sci_handle->callback = NULL;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_014
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_014)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_curr_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_015
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_015)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = true;
    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_016
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_016)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = false;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_017
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_017)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R + 1;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_018
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_018)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R - 1;
    g_sci_handle->tx_dummy = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_019
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_019)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = 0;
    g_sci_handle->tx_dummy = false;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_020
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_020)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    g_sci_handle->callback = NULL;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_021
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_021)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_curr_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_022
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_022)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = true;
    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_023
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_023)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = false;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_024
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_024)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R + 1;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_025
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_025)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R - 1;
    g_sci_handle->tx_dummy = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_025
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_026
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_026)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = 0;
    g_sci_handle->tx_dummy = false;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_026
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_027
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_027)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    g_sci_handle->callback = NULL;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_027
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_028
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_028)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_curr_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_028
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_029
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_029)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = true;
    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_029
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_030
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_030)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->save_rx_data = false;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_030
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_031
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_031)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R + 1;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_031
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_032
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_032)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = g_sci_handle->rom->regs->FDR.BIT.R - 1;
    g_sci_handle->tx_dummy = true;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_032
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_033
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_033)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 10;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 5;
    g_sci_handle->tx_cnt = 0;
    g_sci_handle->tx_dummy = false;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_033
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_034
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_034)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    g_sci_handle->callback = NULL;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_034
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG029_035
* Description  : Test API function sci_fifo_receive_sync()
***********************************************************************************************************************/
TEST(sci_fifo_receive_sync_Test, TG029_035)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SSPI;
    sci_cfg_t cfg;
    unsigned char fifo_num_rx;

    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority    = 3;
    cfg.sspi.invert_data     = false;
    cfg.sspi.msb_first       = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rx_cnt = 0;
    fifo_num_rx = g_sci_handle->rom->regs->FDR.BIT.R;
    g_sci_handle->rom->regs->FDR.BIT.R = 0;
    rxi_handler(g_sci_handle);
    g_sci_handle->rom->regs->FDR.BIT.R = fifo_num_rx;
    TEST_ASSERT_EQUAL(true, callback_called_flag);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_curr_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    TEST_ASSERT_EQUAL(true, g_sci_handle->tx_idle);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_receive_sync_Test_TG029_035
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_error_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_fifo_error_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_error_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_fifo_error_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_fifo_error_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag = false;
    r_byteq_put_fail_flag = false;
    callback_called_flag = false;

    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_fifo_error_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_001
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_001)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_002
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_002)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);


    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_003
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_003)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_004
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_004)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    char key;
    printf("SCI_CFG_CH11_FIFO_INCLUDED\n");
    printf("Set breakpoint at line 1917 and 1928 of r_sci_rx.c\n");
    printf("Press any key to continue\n");
    printf("At line 1917:\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 1\n");
    printf("- Press F8\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 0\n");
    printf("- Press F8\n");
    printf("At line 1928:\n");
    printf("- Set hdl->rom->regs->SSRFIFO.BYTE to 0xCF\n");
    printf("- Press F8\n");
    printf("- Remove breakpoints 1917 and 1928\n");
    key = getchar();

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_PER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_005
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_005)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_FER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_006
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_006)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 1;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_007
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_007)
{
    uint8_t chan = SCI_CH11;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_008
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_008)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_009
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_009)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);


    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_010
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_010)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_011
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_011)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    char key;
    printf("SCI_CFG_CH7_FIFO_INCLUDED\n");
    printf("Set breakpoint at line 1917 and 1928 of r_sci_rx.c\n");
    printf("Press any key to continue\n");
    printf("At line 1917:\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 1\n");
    printf("- Press F8\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 0\n");
    printf("- Press F8\n");
    printf("At line 1928:\n");
    printf("- Set hdl->rom->regs->SSRFIFO.BYTE to 0xCF\n");
    printf("- Press F8\n");
    printf("- Remove breakpoints 1917 and 1928\n");
    key = getchar();

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_PER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_012
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_012)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_FER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_013
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_013)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 1;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_014
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_014)
{
    uint8_t chan = SCI_CH7;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_015
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_015)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_016
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_016)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);


    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_017
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_017)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_018
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_018)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    char key;
    printf("SCI_CFG_CH8_FIFO_INCLUDED\n");
    printf("Set breakpoint at line 1917 and 1928 of r_sci_rx.c\n");
    printf("Press any key to continue\n");
    printf("At line 1917:\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 1\n");
    printf("- Press F8\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 0\n");
    printf("- Press F8\n");
    printf("At line 1928:\n");
    printf("- Set hdl->rom->regs->SSRFIFO.BYTE to 0xCF\n");
    printf("- Press F8\n");
    printf("- Remove breakpoints 1917 and 1928\n");
    key = getchar();

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_PER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_019
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_019)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_FER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_020
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_020)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 1;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_021
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_021)
{
    uint8_t chan = SCI_CH8;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_022
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_022)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_023
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_023)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);


    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_024
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_024)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_025
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_025)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    char key;
    printf("SCI_CFG_CH9_FIFO_INCLUDED\n");
    printf("Set breakpoint at line 1917 and 1928 of r_sci_rx.c\n");
    printf("Press any key to continue\n");
    printf("At line 1917:\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 1\n");
    printf("- Press F8\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 0\n");
    printf("- Press F8\n");
    printf("At line 1928:\n");
    printf("- Set hdl->rom->regs->SSRFIFO.BYTE to 0xCF\n");
    printf("- Press F8\n");
    printf("- Remove breakpoints 1917 and 1928\n");
    key = getchar();

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_PER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_025
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_026
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_026)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_FER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_026
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_027
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_027)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 1;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_027
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_028
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_028)
{
    uint8_t chan = SCI_CH9;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_028
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_029
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_029)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_029
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_030
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_030)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);


    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_030
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_031
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_031)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_031
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_032
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_032)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    char key;
    printf("SCI_CFG_CH10_FIFO_INCLUDED\n");
    printf("Set breakpoint at line 1917 and 1928 of r_sci_rx.c\n");
    printf("Press any key to continue\n");
    printf("At line 1917:\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 1\n");
    printf("- Press F8\n");
    printf("- Set hdl->rom->regs->FRDR.BIT to 0\n");
    printf("- Press F8\n");
    printf("At line 1928:\n");
    printf("- Set hdl->rom->regs->SSRFIFO.BYTE to 0xCF\n");
    printf("- Press F8\n");
    printf("- Remove breakpoints 1917 and 1928\n");
    key = getchar();

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_PER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_032
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_033
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_033)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_FER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(true, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_033
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_034
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_034)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = test_sci_callback;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 1;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_034
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG030_035
* Description  : Test API function sci_fifo_error()
***********************************************************************************************************************/
TEST(sci_fifo_error_Test, TG030_035)
{
    uint8_t chan = SCI_CH10;
    sci_mode_t mode = SCI_MODE_SYNC;
    sci_cfg_t cfg;
    void (*p_callback)(void *p_args);

    p_callback = NULL;
    cfg.sync.bit_rate       = 1000000;
    cfg.sync.int_priority   = 3;
    cfg.sync.invert_data    = false;
    cfg.sync.msb_first      = false;
    cfg.sync.spi_mode       = SCI_SPI_MODE_OFF;
    R_SCI_Open(chan, mode, &cfg, p_callback, &g_sci_handle);

    g_sci_handle->rom->regs->SSRFIFO.BYTE = 0;
    g_sci_handle->rom->regs->SSRFIFO.BYTE |= SCI_SSR_ORER_MASK;

    eri_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag);
}
/***********************************************************************************************************************
* End of function TEST_sci_fifo_error_Test_TG030_035
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TEST_sci_init_fifo_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_init_fifo_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_init_fifo_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_init_fifo_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_init_fifo_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;
    
    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_init_fifo_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_001
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_001)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH11_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH11_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
    //------------------------------------------------------------------------
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_002
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_002)
{
#if ((BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS != 0) && (BYTEQ_CFG_MAX_CTRL_BLKS < 2))
    TEST_IGNORE_MESSAGE("Set BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS to (0) and"
                        "BYTEQ_CFG_MAX_CTRL_BLKS >= 2 to test this TC");
#else
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint32_t idx = 0;
    byteq_hdl_t queues_tmp_ptr[BYTEQ_CFG_MAX_CTRL_BLKS+1];
    uint8_t  ch11_buf[SCI_CFG_CH11_TX_BUFSIZ];

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    // Open queues, leave 2 empty queues for SCI Open (tx + rx)
    for (idx = 0; idx <= BYTEQ_CFG_MAX_CTRL_BLKS; idx++)
    {
        if (R_BYTEQ_Open(ch11_buf,SCI_CFG_CH11_TX_BUFSIZ, &queues_tmp_ptr[idx])
           == BYTEQ_ERR_NO_MORE_CTRL_BLKS)
        {
            R_BYTEQ_Close(queues_tmp_ptr[idx-1]);
            R_BYTEQ_Close(queues_tmp_ptr[idx-2]);
            idx = idx - 3;
            break;
        }
    }

    // SCI Open with init fifo failed
    g_sci_handle->rx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH11_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH11_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // Call R_SCI_Close() to close current channel,
    // Confirm that return error is SCI_SUCCESS.
    error = R_SCI_Close(g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    // Call R_SCI_Open() in ASYNC mode, same channel with previous R_SCI_Open()
    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
//    for (idxtmp = 0; idxtmp <= idx; idxtmp++)
//    {
//        R_BYTEQ_Close(queues_tmp_ptr[idxtmp]);
//    }
    //------------------------------------------------------------------------

    // Confirm SCI_SUCCESS when re-open after fifo init failed
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    R_SCI_Close(g_sci_handle);

#endif
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_003
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_003)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 8;
    g_sci_handle->rx_dflt_thresh = 7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH11_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH11_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_004
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_004)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH11_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH11_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_005
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_005)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH11;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH11_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH11_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_006
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_006)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH7;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH7_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH7_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
    //------------------------------------------------------------------------
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_007
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_007)
{
#if ((BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS != 0) && (BYTEQ_CFG_MAX_CTRL_BLKS < 2))
    TEST_IGNORE_MESSAGE("Set BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS to (0) and"
                        "BYTEQ_CFG_MAX_CTRL_BLKS >= 2 to test this TC");
#else
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH7;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint32_t idx = 0;
    byteq_hdl_t queues_tmp_ptr[BYTEQ_CFG_MAX_CTRL_BLKS+1];
    uint8_t  ch7_buf[SCI_CFG_CH7_TX_BUFSIZ];

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    // Open queues, leave 2 empty queues for SCI Open (tx + rx)
    for (idx = 0; idx <= BYTEQ_CFG_MAX_CTRL_BLKS; idx++)
    {
        if (R_BYTEQ_Open(ch7_buf,SCI_CFG_CH7_TX_BUFSIZ, &queues_tmp_ptr[idx])
           == BYTEQ_ERR_NO_MORE_CTRL_BLKS)
        {
            R_BYTEQ_Close(queues_tmp_ptr[idx-1]);
            R_BYTEQ_Close(queues_tmp_ptr[idx-2]);
            idx = idx - 3;
            break;
        }
    }

    // SCI Open with init fifo failed
    g_sci_handle->rx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH7_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH7_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // Call R_SCI_Close() to close current channel,
    // Confirm that return error is SCI_SUCCESS.
    error = R_SCI_Close(g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    // Call R_SCI_Open() in ASYNC mode, same channel with previous R_SCI_Open()
    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
//    for (idxtmp = 0; idxtmp <= idx; idxtmp++)
//    {
//        R_BYTEQ_Close(queues_tmp_ptr[idxtmp]);
//    }
    //------------------------------------------------------------------------

    // Confirm SCI_SUCCESS when re-open after fifo init failed
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    R_SCI_Close(g_sci_handle);

#endif
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_008
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_008)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH7;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 8;
    g_sci_handle->rx_dflt_thresh = 7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH7_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH7_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_009
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_009)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH7;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH7_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH7_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_010
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_010)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH7;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH7_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH7_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_011
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_011)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH8;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH8_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH8_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
    //------------------------------------------------------------------------
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_012
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_012)
{
#if ((BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS != 0) && (BYTEQ_CFG_MAX_CTRL_BLKS < 2))
    TEST_IGNORE_MESSAGE("Set BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS to (0) and"
                        "BYTEQ_CFG_MAX_CTRL_BLKS >= 2 to test this TC");
#else
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH8;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint32_t idx = 0;
    byteq_hdl_t queues_tmp_ptr[BYTEQ_CFG_MAX_CTRL_BLKS+1];
    uint8_t  ch8_buf[SCI_CFG_CH8_TX_BUFSIZ];

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    // Open queues, leave 2 empty queues for SCI Open (tx + rx)
    for (idx = 0; idx <= BYTEQ_CFG_MAX_CTRL_BLKS; idx++)
    {
        if (R_BYTEQ_Open(ch8_buf,SCI_CFG_CH8_TX_BUFSIZ, &queues_tmp_ptr[idx])
           == BYTEQ_ERR_NO_MORE_CTRL_BLKS)
        {
            R_BYTEQ_Close(queues_tmp_ptr[idx-1]);
            R_BYTEQ_Close(queues_tmp_ptr[idx-2]);
            idx = idx - 3;
            break;
        }
    }

    // SCI Open with init fifo failed
    g_sci_handle->rx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH8_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH8_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // Call R_SCI_Close() to close current channel,
    // Confirm that return error is SCI_SUCCESS.
    error = R_SCI_Close(g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    // Call R_SCI_Open() in ASYNC mode, same channel with previous R_SCI_Open()
    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
//    for (idxtmp = 0; idxtmp <= idx; idxtmp++)
//    {
//        R_BYTEQ_Close(queues_tmp_ptr[idxtmp]);
//    }
    //------------------------------------------------------------------------

    // Confirm SCI_SUCCESS when re-open after fifo init failed
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    R_SCI_Close(g_sci_handle);

#endif
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_013
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_013)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH8;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 8;
    g_sci_handle->rx_dflt_thresh = 7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH8_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH8_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_014
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_014)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH8;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH8_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH8_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_015
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_015)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH8;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH8_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH8_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_016
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_016)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH9;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH9_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH9_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
    //------------------------------------------------------------------------
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_017
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_017)
{
#if ((BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS != 0) && (BYTEQ_CFG_MAX_CTRL_BLKS < 2))
    TEST_IGNORE_MESSAGE("Set BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS to (0) and"
                        "BYTEQ_CFG_MAX_CTRL_BLKS >= 2 to test this TC");
#else
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH9;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint32_t idx = 0;
    byteq_hdl_t queues_tmp_ptr[BYTEQ_CFG_MAX_CTRL_BLKS+1];
    uint8_t  ch9_buf[SCI_CFG_CH9_TX_BUFSIZ];

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    // Open queues, leave 2 empty queues for SCI Open (tx + rx)
    for (idx = 0; idx <= BYTEQ_CFG_MAX_CTRL_BLKS; idx++)
    {
        if (R_BYTEQ_Open(ch9_buf,SCI_CFG_CH9_TX_BUFSIZ, &queues_tmp_ptr[idx])
           == BYTEQ_ERR_NO_MORE_CTRL_BLKS)
        {
            R_BYTEQ_Close(queues_tmp_ptr[idx-1]);
            R_BYTEQ_Close(queues_tmp_ptr[idx-2]);
            idx = idx - 3;
            break;
        }
    }

    // SCI Open with init fifo failed
    g_sci_handle->rx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH9_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH9_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // Call R_SCI_Close() to close current channel,
    // Confirm that return error is SCI_SUCCESS.
    error = R_SCI_Close(g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    // Call R_SCI_Open() in ASYNC mode, same channel with previous R_SCI_Open()
    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
//    for (idxtmp = 0; idxtmp <= idx; idxtmp++)
//    {
//        R_BYTEQ_Close(queues_tmp_ptr[idxtmp]);
//    }
    //------------------------------------------------------------------------

    // Confirm SCI_SUCCESS when re-open after fifo init failed
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    R_SCI_Close(g_sci_handle);

#endif
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_018
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_018)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH9;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 8;
    g_sci_handle->rx_dflt_thresh = 7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH9_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH9_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_019
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_019)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH9;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH9_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH9_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_020
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_020)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH9;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH9_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH9_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_021
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_021)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH10;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH10_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH10_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
    //------------------------------------------------------------------------
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_022
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_022)
{
#if ((BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS != 0) && (BYTEQ_CFG_MAX_CTRL_BLKS < 2))
    TEST_IGNORE_MESSAGE("Set BYTEQ_CFG_USE_HEAP_FOR_CTRL_BLKS to (0) and"
                        "BYTEQ_CFG_MAX_CTRL_BLKS >= 2 to test this TC");
#else
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH10;
    sci_mode_t mode;
    sci_cfg_t cfg;
    uint32_t idx = 0;
    byteq_hdl_t queues_tmp_ptr[BYTEQ_CFG_MAX_CTRL_BLKS+1];
    uint8_t  ch10_buf[SCI_CFG_CH10_TX_BUFSIZ];

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    // Open queues, leave 2 empty queues for SCI Open (tx + rx)
    for (idx = 0; idx <= BYTEQ_CFG_MAX_CTRL_BLKS; idx++)
    {
        if (R_BYTEQ_Open(ch10_buf,SCI_CFG_CH10_TX_BUFSIZ, &queues_tmp_ptr[idx])
           == BYTEQ_ERR_NO_MORE_CTRL_BLKS)
        {
            R_BYTEQ_Close(queues_tmp_ptr[idx-1]);
            R_BYTEQ_Close(queues_tmp_ptr[idx-2]);
            idx = idx - 3;
            break;
        }
    }

    // SCI Open with init fifo failed
    g_sci_handle->rx_dflt_thresh = 16;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH10_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH10_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);

    // Call R_SCI_Close() to close current channel,
    // Confirm that return error is SCI_SUCCESS.
    error = R_SCI_Close(g_sci_handle);
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    // Call R_SCI_Open() in ASYNC mode, same channel with previous R_SCI_Open()
    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    // FIXME: Close queues manually to bypass the bug. Should remove when fixed
//    R_BYTEQ_Close(g_sci_handle->u_tx_data.que);
//    R_BYTEQ_Close(g_sci_handle->u_rx_data.que);
//    for (idxtmp = 0; idxtmp <= idx; idxtmp++)
//    {
//        R_BYTEQ_Close(queues_tmp_ptr[idxtmp]);
//    }
    //------------------------------------------------------------------------

    // Confirm SCI_SUCCESS when re-open after fifo init failed
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);

    R_SCI_Close(g_sci_handle);

#endif
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_023
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_023)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH10;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_SSPI;
    cfg.sspi.bit_rate        = 1000000;
    cfg.sspi.int_priority   = 3;
    cfg.sspi.invert_data    = false;
    cfg.sspi.msb_first        = false;
    cfg.sspi.spi_mode        = SCI_SPI_MODE_0;
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    g_sci_handle->tx_dflt_thresh = 8;
    g_sci_handle->rx_dflt_thresh = 7;
    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH10_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH10_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_ERR_INVALID_ARG, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_024
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_024)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH10;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH10_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH10_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG031_025
* Description  : Test API function sci_init_fifo()
***********************************************************************************************************************/
TEST(sci_init_fifo_Test, TG031_025)
{
    sci_err_t error = SCI_SUCCESS;
    uint8_t chan = SCI_CH10;
    sci_mode_t mode;
    sci_cfg_t cfg;

    mode = SCI_MODE_ASYNC;
    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);
    R_SCI_Close(g_sci_handle);

    error = R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.FM);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.TFRST);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->FCR.BIT.RFRST);
    TEST_ASSERT_EQUAL(g_sci_handle->tx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.TTRG);
    TEST_ASSERT_EQUAL(g_sci_handle->rx_dflt_thresh, g_sci_handle->rom->regs->FCR.BIT.RTRG);
    g_sci_handle->tx_dflt_thresh = SCI_CFG_CH10_TX_FIFO_THRESH;
    g_sci_handle->rx_dflt_thresh = SCI_CFG_CH10_RX_FIFO_THRESH;
    TEST_ASSERT_EQUAL(SCI_SUCCESS, error);
}
/***********************************************************************************************************************
* End of function TEST_sci_init_fifo_Test_TG031_025
***********************************************************************************************************************/

#if (SCI_CFG_DATA_MATCH_INCLUDED == 1)
/***********************************************************************************************************************
* Function Name: TEST_sci_receive_data_match_Test_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(sci_receive_data_match_Test)
{
    g_sci_handle->baud_rate = 115200;
    g_sci_handle->pclk_speed = 24000000;
}
/***********************************************************************************************************************
End of function TEST_sci_receive_data_match_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_sci_receive_data_match_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(sci_receive_data_match_Test)
{
    sci_err_t ret;

    r_byteq_open_fail_flag   = false;
    r_byteq_unused_fail_flag = false;
    r_byteq_put_fail_flag    = false;
    r_byteq_use_true_flag    = false;
    r_byteq_get_fail_flag    = false;
    callback_called_flag     = false;
    callback_called_flag_matched = false;

    
    /* Stop the timer */
    ret = R_SCI_Close(g_sci_handle);
    switch (ret){
    case SCI_SUCCESS:
        break;
    case SCI_ERR_NULL_PTR:
        //printf("NULL g_sci_handle.\n");
        break;
    default:
        printf("Can not stop the channel.\n");
        break;
    }
}
/***********************************************************************************************************************
End of function TEST_sci_receive_data_match_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_001
* Description  : Test API function sci_receive_data_match()
***********************************************************************************************************************/
TEST(sci_receive_data_match_Test, TG032_001)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rom->regs->DCCR.BIT.DCME = 0; //XXX Clear to 0 because the simulator can not auto-clear this bit when data match detected
    g_sci_handle->rom->regs->DCCR.BIT.DCMF = 0;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(false, callback_called_flag_matched);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_data_match_Test_TG032_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_002
* Description  : Test API function sci_receive_data_match()
***********************************************************************************************************************/
TEST(sci_receive_data_match_Test, TG032_002)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rom->regs->DCCR.BIT.DCME = 0; //XXX Clear to 0 because the simulator can not auto-clear this bit when data match detected
    g_sci_handle->rom->regs->DCCR.BIT.DCMF = 1;
    g_sci_handle->rom->regs->DCCR.BIT.DFER = 1;
    g_sci_handle->rom->regs->DCCR.BIT.DPER = 1;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->DCCR.BIT.DCMF);
    TEST_ASSERT_EQUAL(false, callback_called_flag_matched);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_data_match_Test_TG032_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_003
* Description  : Test API function sci_receive_data_match()
***********************************************************************************************************************/
TEST(sci_receive_data_match_Test, TG032_003)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rom->regs->DCCR.BIT.DCME = 0; //XXX Clear to 0 because the simulator can not auto-clear this bit when data match detected
    g_sci_handle->rom->regs->DCCR.BIT.DCMF = 1;
    g_sci_handle->rom->regs->DCCR.BIT.DFER = 0;
    g_sci_handle->rom->regs->DCCR.BIT.DPER = 0;
    r_byteq_put_fail_flag = true;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->DCCR.BIT.DCMF);
    TEST_ASSERT_EQUAL(false, callback_called_flag_matched);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_data_match_Test_TG032_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_004
* Description  : Test API function sci_receive_data_match()
***********************************************************************************************************************/
TEST(sci_receive_data_match_Test, TG032_004)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rom->regs->DCCR.BIT.DCME = 0; //XXX Clear to 0 because the simulator can not auto-clear this bit when data match detected
    g_sci_handle->rom->regs->DCCR.BIT.DCMF = 1;
    g_sci_handle->rom->regs->DCCR.BIT.DFER = 0;
    g_sci_handle->rom->regs->DCCR.BIT.DPER = 0;
    r_byteq_put_fail_flag = false;
    g_sci_handle->callback = NULL;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->DCCR.BIT.DCMF);
    TEST_ASSERT_EQUAL(false, callback_called_flag_matched);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_data_match_Test_TG032_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_005
* Description  : Test API function sci_receive_data_match()
***********************************************************************************************************************/
TEST(sci_receive_data_match_Test, TG032_005)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rom->regs->DCCR.BIT.DCME = 0; //XXX Clear to 0 because the simulator can not auto-clear this bit when data match detected
    g_sci_handle->rom->regs->DCCR.BIT.DCMF = 1;
    g_sci_handle->rom->regs->DCCR.BIT.DFER = 0;
    g_sci_handle->rom->regs->DCCR.BIT.DPER = 0;
    r_byteq_put_fail_flag = false;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(0, g_sci_handle->rom->regs->DCCR.BIT.DCMF);
    TEST_ASSERT_EQUAL(true, callback_called_flag_matched);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_data_match_Test_TG032_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG032_006
* Description  : Test API function sci_receive_data_match()
***********************************************************************************************************************/
TEST(sci_receive_data_match_Test, TG032_006)
{
    uint8_t chan = SCI_CH1;
    sci_mode_t mode = SCI_MODE_ASYNC;
    sci_cfg_t cfg;

    cfg.async.baud_rate    = 115200;
    cfg.async.clk_src      = SCI_CLK_INT;
    cfg.async.data_size    = SCI_DATA_8BIT;
    cfg.async.parity_en    = SCI_PARITY_OFF;
    cfg.async.parity_type  = SCI_EVEN_PARITY;
    cfg.async.stop_bits    = SCI_STOPBITS_1;
    cfg.async.int_priority = 3;    // 1=lowest, 15=highest
    R_SCI_Open(chan, mode, &cfg, test_sci_callback, &g_sci_handle);

    g_sci_handle->rom->regs->DCCR.BIT.DCME = 1; //XXX Set to 1 because the simulator can not auto-clear this bit when data match detected
    g_sci_handle->rom->regs->DCCR.BIT.DCMF = 1;
    g_sci_handle->rom->regs->DCCR.BIT.DFER = 0;
    g_sci_handle->rom->regs->DCCR.BIT.DPER = 0;
    r_byteq_put_fail_flag = false;
    rxi_handler(g_sci_handle);
    TEST_ASSERT_EQUAL(1, g_sci_handle->rom->regs->DCCR.BIT.DCMF);
    TEST_ASSERT_EQUAL(false, callback_called_flag_matched);
}
/***********************************************************************************************************************
* End of function TEST_sci_receive_data_match_Test_TG032_006
***********************************************************************************************************************/
#endif
