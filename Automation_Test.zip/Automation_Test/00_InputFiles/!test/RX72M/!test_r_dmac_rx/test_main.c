/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : test_main.c
* Description  : Unit test for DMAC using Unity
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 07.12.2018 1.00     First Release
***********************************************************************************************************************/


/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include "platform.h"
#include "r_dmaca_rx_config.h"
#include "r_dmaca_rx_if.h"

#include "../!test/unity/unity.h"
#include "../!test/unity/unity_fixture.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

TEST_GROUP_RUNNER(R_DMACA_Open_Test)
{
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_001);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_002);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_003);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_004);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_005);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_006);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_007);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_008);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_009);
    RUN_TEST_CASE(R_DMACA_Open_Test, TG001_010);
}

TEST_GROUP_RUNNER(R_DMACA_Close_Test)
{
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_001);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_002);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_003);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_004);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_005);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_006);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_007);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_008);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_009);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_010);
    RUN_TEST_CASE(R_DMACA_Close_Test, TG002_011);
}

TEST_GROUP_RUNNER(R_DMACA_Create_Test)
{
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_001);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_002);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_003);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_004);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_005);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_006);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_007);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_008);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_009);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_010);
    RUN_TEST_CASE(R_DMACA_Create_Test, TG003_011);
}

TEST_GROUP_RUNNER(R_DMACA_Control_Test)
{
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_001);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_002);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_003);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_004);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_005);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_006);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_007);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_008);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_009);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_010);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_011);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_012);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_013);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_014);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_015);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_016);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_017);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_018);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_019);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_020);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_021);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_022);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_023);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_024);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_025);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_026);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_027);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_028);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_029);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_030);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_031);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_032);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_033);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_034);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_035);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_036);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_037);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_038);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_039);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_040);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_041);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_042);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_043);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_044);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_045);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_046);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_047);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_048);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_049);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_050);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_051);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_052);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_053);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_054);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_055);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_056);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_057);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_058);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_059);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_060);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_061);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_062);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_063);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_064);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_065);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_066);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_067);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_068);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_069);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_070);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_071);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_072);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_073);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_074);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_075);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_076);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_077);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_078);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_079);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_080);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_081);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_082);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_083);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_084);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_085);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_086);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_087);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_088);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_089);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_090);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_091);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_092);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_093);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_094);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_095);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_096);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_097);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_098);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_099);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_100);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_101);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_102);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_103);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_104);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_105);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_106);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_107);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_108);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_109);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_110);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_111);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_112);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_113);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_114);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_115);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_116);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_117);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_118);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_119);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_120);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_121);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_122);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_123);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_124);
    RUN_TEST_CASE(R_DMACA_Control_Test, TG004_125);
}

TEST_GROUP_RUNNER(R_DMACA_Init_Test)
{
    RUN_TEST_CASE(R_DMACA_Init_Test, TG005_001);
}

TEST_GROUP_RUNNER(R_DMACA_Int_Callback_Test)
{
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_001);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_002);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_003);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_004);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_005);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_006);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_007);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_008);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_009);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_010);
    RUN_TEST_CASE(R_DMACA_Int_Callback_Test, TG006_011);
}

TEST_GROUP_RUNNER(R_DMACA_Int_Enable_Test)
{
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_001);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_002);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_003);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_004);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_005);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_006);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_007);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_008);
    RUN_TEST_CASE(R_DMACA_Int_Enable_Test, TG007_009);
}

TEST_GROUP_RUNNER(R_DMACA_Int_Disable_Test)
{
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_001);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_002);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_003);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_004);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_005);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_006);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_007);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_008);
    RUN_TEST_CASE(R_DMACA_Int_Disable_Test, TG008_009);
}

TEST_GROUP_RUNNER(R_DMACA_GetVersion_Test)
{
    RUN_TEST_CASE(R_DMACA_GetVersion_Test, TG009_001);
}

TEST_GROUP_RUNNER(r_dmaca_set_transfer_data_Test)
{
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_001);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_002);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_003);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_004);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_005);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_006);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_007);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_008);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_009);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_010);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_011);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_012);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_013);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_014);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_015);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_016);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_017);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_018);
    RUN_TEST_CASE(r_dmaca_set_transfer_data_Test, TG010_019);
}

TEST_GROUP_RUNNER(r_dmaca_check_locking_sw_Test)
{
    RUN_TEST_CASE(r_dmaca_check_locking_sw_Test, TG011_001);
    RUN_TEST_CASE(r_dmaca_check_locking_sw_Test, TG011_002);
}

TEST_GROUP_RUNNER(r_dmaca_channel_valid_check_Test)
{
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_001);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_002);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_003);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_004);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_005);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_006);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_007);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_008);
    RUN_TEST_CASE(r_dmaca_channel_valid_check_Test, TG012_009);
}

TEST_GROUP_RUNNER(r_dmaca_int_disable_Test)
{
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_001);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_002);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_003);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_004);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_005);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_006);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_007);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_008);
    RUN_TEST_CASE(r_dmaca_int_disable_Test, TG013_009);
}

TEST_GROUP_RUNNER(r_dmaca_int_enable_Test)
{
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_001);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_002);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_003);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_004);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_005);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_006);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_007);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_008);
    RUN_TEST_CASE(r_dmaca_int_enable_Test, TG014_009);
}

TEST_GROUP_RUNNER(r_dmaca_module_enable_Test)
{
    RUN_TEST_CASE(r_dmaca_module_enable_Test, TG015_001);
}

TEST_GROUP_RUNNER(r_dmaca_module_disable_Test)
{
    RUN_TEST_CASE(r_dmaca_module_disable_Test, TG016_001);
}


TEST_GROUP_RUNNER(r_dmaca_check_dtc_locking_byuser_Test)
{
    RUN_TEST_CASE(r_dmaca_check_dtc_locking_byuser_Test, TG017_001);
}

static void RunAllTests(void);

/***********************************************************************************************************************
* Function Name: RunAllTests
* Description  : Call test groups
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
static void RunAllTests(void)
{
    printf("RUN TEST GROUP: R_DMACA_Open_Test\n");
    RUN_TEST_GROUP(R_DMACA_Open_Test);
    printf("END TEST GROUP: R_DMACA_Open_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Close_Test\n");
    RUN_TEST_GROUP(R_DMACA_Close_Test);
    printf("END TEST GROUP: R_DMACA_Close_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Create_Test\n");
    RUN_TEST_GROUP(R_DMACA_Create_Test);
    printf("END TEST GROUP: R_DMACA_Create_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Control_Test\n");
    RUN_TEST_GROUP(R_DMACA_Control_Test);
    printf("END TEST GROUP: R_DMACA_Control_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Init_Test\n");
    RUN_TEST_GROUP(R_DMACA_Init_Test);
    printf("END TEST GROUP: R_DMACA_Init_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Int_Callback_Test\n");
    RUN_TEST_GROUP(R_DMACA_Int_Callback_Test);
    printf("END TEST GROUP: R_DMACA_Int_Callback_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Int_Enable_Test\n");
    RUN_TEST_GROUP(R_DMACA_Int_Enable_Test);
    printf("END TEST GROUP: R_DMACA_Int_Enable_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_Int_Disable_Test\n");
    RUN_TEST_GROUP(R_DMACA_Int_Disable_Test);
    printf("END TEST GROUP: R_DMACA_Int_Disable_Test\n\n");

    printf("RUN TEST GROUP: R_DMACA_GetVersion_Test\n");
    RUN_TEST_GROUP(R_DMACA_GetVersion_Test);
    printf("END TEST GROUP: R_DMACA_GetVersion_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_set_transfer_data_Test\n");
    RUN_TEST_GROUP(r_dmaca_set_transfer_data_Test);
    printf("END TEST GROUP: r_dmaca_set_transfer_data_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_check_locking_sw_Test\n");
    RUN_TEST_GROUP(r_dmaca_check_locking_sw_Test);
    printf("END TEST GROUP: r_dmaca_check_locking_sw_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_channel_valid_check_Test\n");
    RUN_TEST_GROUP(r_dmaca_channel_valid_check_Test);
    printf("END TEST GROUP: r_dmaca_channel_valid_check_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_int_disable_Test\n");
    RUN_TEST_GROUP(r_dmaca_int_disable_Test);
    printf("END TEST GROUP: r_dmaca_int_disable_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_int_enable_Test\n");
    RUN_TEST_GROUP(r_dmaca_int_enable_Test);
    printf("END TEST GROUP: r_dmaca_int_enable_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_module_enable_Test\n");
    RUN_TEST_GROUP(r_dmaca_module_enable_Test);
    printf("END TEST GROUP: r_dmaca_module_enable_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_module_disable_Test\n");
    RUN_TEST_GROUP(r_dmaca_module_disable_Test);
    printf("END TEST GROUP: r_dmaca_module_disable_Test\n\n");

    printf("RUN TEST GROUP: r_dmaca_check_dtc_locking_byuser_Test\n");
    RUN_TEST_GROUP(r_dmaca_check_dtc_locking_byuser_Test);
    printf("END TEST GROUP: r_dmaca_check_dtc_locking_byuser_Test\n\n");
}

void main(void)
{
    UnityMain(0, 0, RunAllTests);

    while(1)
    {
        /* Infinite loop. */
    }
}
