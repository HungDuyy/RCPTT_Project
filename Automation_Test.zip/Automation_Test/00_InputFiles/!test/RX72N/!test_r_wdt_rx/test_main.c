/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : test_main.c
* Description  : Test runner of WDT RX72M unit test
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 28.05.2018 1.00		First release
***********************************************************************************************************************/

#include "platform.h"
#include "r_wdt_rx_if.h"

#include <stdio.h>
#include "unity_fixture.h"


TEST_GROUP_RUNNER(WDT_TEST)
{
	/* WDT_GetVersion() test cases */
	RUN_TEST_CASE(WDT_TEST, TG001_001);

	/* TG003_006 is test calling WDT control before calling WDT open.
	 * So, It must be run before running WDT open tests*/
	RUN_TEST_CASE(WDT_TEST, TG003_006);

	/* WDT_Open() test cases */
	RUN_TEST_CASE(WDT_TEST, TG002_001);
	RUN_TEST_CASE(WDT_TEST, TG002_002);
	RUN_TEST_CASE(WDT_TEST, TG002_003);
	RUN_TEST_CASE(WDT_TEST, TG002_004);
	RUN_TEST_CASE(WDT_TEST, TG002_005);
	RUN_TEST_CASE(WDT_TEST, TG002_006);
	RUN_TEST_CASE(WDT_TEST, TG002_007);
	RUN_TEST_CASE(WDT_TEST, TG002_008);
	RUN_TEST_CASE(WDT_TEST, TG002_009);

	/* WDT_Control() test cases */
	RUN_TEST_CASE(WDT_TEST, TG003_001);
	RUN_TEST_CASE(WDT_TEST, TG003_002);
	RUN_TEST_CASE(WDT_TEST, TG003_003);
	RUN_TEST_CASE(WDT_TEST, TG003_004);
	RUN_TEST_CASE(WDT_TEST, TG003_005);
}

static void RunTest()
{
	printf("Running RX72M WDT Unit Test...\n");

	RUN_TEST_GROUP(WDT_TEST);
}

void main()
{
	UnityMain(0, 0, RunTest);
	printf("TEST DONE!!!\n");
}
