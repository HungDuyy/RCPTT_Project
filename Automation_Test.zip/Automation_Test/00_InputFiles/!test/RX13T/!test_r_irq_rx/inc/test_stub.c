/*
 * test_stuff.c
 *
 *  Created on: May 30, 2018
 *      Author: isadmin
 */

#include <test_stub.h>

void my_irq_callback(void *pargs)
{
    nop();
}
