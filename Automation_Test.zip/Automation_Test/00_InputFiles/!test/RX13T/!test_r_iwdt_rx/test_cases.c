/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name       : test_cases.c
* Description  : Test cases of IWDT unit test.
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 12.06.2019 1.00     First release
***********************************************************************************************************************/

#include "platform.h"
#include "r_iwdt_rx_if.h"

#include "stdio.h"
#include "../!test/unity/unity.h"
#include "../!test/unity/unity_fixture.h"



TEST_GROUP(IWTD_TEST);

/***********************************************************************************************************************
* Function Name: IWDT_TEST_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(IWDT_TEST)
{
    /* DO SOMETHING */
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: IWDT_TEST_TEARDOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(IWDT_TEST)
{
    /* DO SOMETHING */
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TC_001_GetVersion
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG001_001)
{
    uint32_t ret = R_IWDT_GetVersion();
    printf("[TG001_001]===");
    uint32_t ver = (uint32_t)((IWDT_RX_VERSION_MAJOR << 16) | IWDT_RX_VERSION_MINOR);

    TEST_ASSERT_EQUAL(ver, ret);
    if(ret == ver)
    {
        printf("Version of IWDT is: %d.%d", IWDT_RX_VERSION_MAJOR, IWDT_RX_VERSION_MINOR);
    }
    printf("===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_001
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_001)
{
    iwdt_config_t * p_cfg = NULL;
    printf("[TG002_001]===");

    iwdt_err_t err = R_IWDT_Open((void*)p_cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_NULL_PTR, err);

    printf("IWDT configuration is NULL===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_002
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_002)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_NUM_TIMEOUTS;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;

    printf("[TG002_002]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("IWDT Time-Out Period is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_003
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_003)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = (iwdt_timeout_control_t)(IWDT_TIMEOUT_NMI + 1);
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;

    printf("[TG002_003]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("Signal control is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_004
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_004)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = (iwdt_clock_div_t)(IWDT_CLOCK_DIV_256 + 1);
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;

    printf("[TG002_004]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("IWDT Clock Division Ratio is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_005
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_005)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = (iwdt_window_end_t)(IWDT_WINDOW_END_0 + 1);
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;
    printf("[TG002_005]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("Window End Position is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_006
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_006)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = (iwdt_window_start_t)(IWDT_WINDOW_START_100 + 1);
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;

    printf("[TG002_006]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("Window Start Position is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_007
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_007)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = (iwdt_count_stop_t)(IWDT_COUNT_STOP_ENABLE + 1);

    printf("[TG002_007]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("Sleep mode count is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_008
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_008)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;

    bool bsp_err = R_BSP_HardwareLock(BSP_LOCK_IWDT);
    TEST_ASSERT_EQUAL(true, bsp_err);

    printf("[TG002_008]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_BUSY, err);

    printf("Fail to get the lock===[OK]");
    printf("\n");

    R_BSP_HardwareUnlock(BSP_LOCK_IWDT);
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_009
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_009)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;

    uint16_t ret = (uint16_t)((IWDT_TIMEOUT_1024 | IWDT_CLOCK_DIV_1) | (IWDT_WINDOW_END_0 | IWDT_WINDOW_START_100));

    printf("[TG002_009]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(ret, IWDT.IWDTCR.WORD);
    TEST_ASSERT_EQUAL((uint8_t)IWDT_TIMEOUT_NMI, IWDT.IWDTRCR.BYTE);
    TEST_ASSERT_EQUAL(IWDT_COUNT_STOP_DISABLE, IWDT.IWDTCSTPR.BYTE);
    TEST_ASSERT_EQUAL(0x1, ICU.NMIER.BIT.IWDTEN);
    TEST_ASSERT_EQUAL(IWDT_SUCCESS, err);

    printf("Open success===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_010
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG002_010)
{
    iwdt_config_t cfg;
    cfg.timeout = IWDT_TIMEOUT_1024;
    cfg.timeout_control = IWDT_TIMEOUT_NMI;
    cfg.iwdtclk_div = IWDT_CLOCK_DIV_1;
    cfg.window_end = IWDT_WINDOW_END_0;
    cfg.window_start = IWDT_WINDOW_START_100;
    cfg.count_stop_enable = IWDT_COUNT_STOP_DISABLE;


    printf("[TG002_010]===");

    iwdt_err_t err = R_IWDT_Open((void*)&cfg);
    TEST_ASSERT_EQUAL(IWDT_ERR_OPEN_IGNORED, err);

    printf("Already Opened===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_001
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_001)
{
    iwdt_cmd_t cmd = (iwdt_cmd_t)(IWDT_CMD_REFRESH_COUNTING + 1);
    uint16_t * p_status = NULL;

    printf("[TG003_001]===");

    iwdt_err_t err = R_IWDT_Control(cmd, p_status);
    TEST_ASSERT_EQUAL(IWDT_ERR_INVALID_ARG, err);

    printf("Command is invalid===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_002
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_002)
{
    iwdt_cmd_t cmd = IWDT_CMD_GET_STATUS;
    uint16_t * p_status = NULL;

    printf("[TG003_002]===");

    iwdt_err_t err = R_IWDT_Control(cmd, p_status);
    TEST_ASSERT_EQUAL(IWDT_ERR_NULL_PTR, err);

    printf("Null pointer===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_003
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_003)
{
    iwdt_cmd_t cmd = IWDT_CMD_GET_STATUS;
    uint16_t * p_status = FIT_NO_PTR;

    printf("[TG003_003]===");

    iwdt_err_t err = R_IWDT_Control(cmd, p_status);
    TEST_ASSERT_EQUAL(IWDT_ERR_NULL_PTR, err);

    printf("Null pointer===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_004
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_004)
{
    iwdt_cmd_t cmd = IWDT_CMD_GET_STATUS;
    uint16_t status;

    bool bsp_err = R_BSP_HardwareLock(BSP_LOCK_IWDT);
    TEST_ASSERT_EQUAL(true, bsp_err);

    printf("[TG003_004]===");

    iwdt_err_t err = R_IWDT_Control(cmd, &status);
    TEST_ASSERT_EQUAL(IWDT_ERR_BUSY, err);

    printf("Fail to get the lock===[OK]");
    printf("\n");
    R_BSP_HardwareUnlock(BSP_LOCK_IWDT);
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_005
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_005)
{
    iwdt_cmd_t cmd = IWDT_CMD_REFRESH_COUNTING;
    uint16_t status;

    printf("[TG003_005]===");

    iwdt_err_t err = R_IWDT_Control(cmd, &status);
    TEST_ASSERT_EQUAL(0xFFu, IWDT.IWDTRR);
    TEST_ASSERT_EQUAL(IWDT_SUCCESS, err);

    printf("Refresh counting===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_006
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_006)
{
    iwdt_cmd_t cmd = IWDT_CMD_GET_STATUS;
    uint16_t status;

    printf("[TG003_006]===");

    iwdt_err_t err = R_IWDT_Control(cmd, &status);

    TEST_ASSERT_EQUAL(IWDT.IWDTSR.WORD, status);
    TEST_ASSERT_EQUAL(IWDT_SUCCESS, err);

    printf("Get Status===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_007
* Description  :
***********************************************************************************************************************/
TEST(IWDT_TEST, TG003_007)
{
    iwdt_cmd_t cmd = IWDT_CMD_GET_STATUS;
    uint16_t status;

    printf("[TG003_007]===");

    iwdt_err_t err = R_IWDT_Control(cmd, &status);
    TEST_ASSERT_EQUAL(IWDT_ERR_NOT_OPENED, err);

    printf("IWDT not open===[OK]");
    printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/
