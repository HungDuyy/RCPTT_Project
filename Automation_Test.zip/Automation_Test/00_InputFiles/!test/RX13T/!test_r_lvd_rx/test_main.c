/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : test_main.c
* Description  : Tests for lvd UT using Unity
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 24.04.2019 2.70     Test for RX72M
***********************************************************************************************************************/


/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include "unity.h"
#include "unity_fixture.h"
#include "platform.h"
#include "r_lvd_rx_if.h"
#include "r_lvd_rx_config.h"
#include "r_lvd_rx_private_targets.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
TEST_GROUP_RUNNER(R_LVD_GetVersion_Test)
{
    RUN_TEST_CASE(R_LVD_GetVersion_Test, TG001_001);
}

TEST_GROUP_RUNNER(R_LVD_Open_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_001);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_002);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_003);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_004);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_005);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_006);
    //RUN_TEST_CASE(R_LVD_Open_Test, TG002_007);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_008);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_009);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_010);
    //RUN_TEST_CASE(R_LVD_Open_Test, TG002_011);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_012);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_013);
    RUN_TEST_CASE(R_LVD_Open_Test, TG002_014);
#endif
}

TEST_GROUP_RUNNER(R_LVD_Close_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(R_LVD_Close_Test, TG003_001);
    RUN_TEST_CASE(R_LVD_Close_Test, TG003_002);
    RUN_TEST_CASE(R_LVD_Close_Test, TG003_003);
#endif
}

TEST_GROUP_RUNNER(R_LVD_GetStatus_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_001);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_002);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_003);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_004);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_005);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_006);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_007);
    RUN_TEST_CASE(R_LVD_GetStatus_Test, TG004_008);
#endif
}

TEST_GROUP_RUNNER(R_LVD_ClearStatus_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(R_LVD_ClearStatus_Test, TG005_001);
    RUN_TEST_CASE(R_LVD_ClearStatus_Test, TG005_002);
    RUN_TEST_CASE(R_LVD_ClearStatus_Test, TG005_003);
    RUN_TEST_CASE(R_LVD_ClearStatus_Test, TG005_004);
#endif
}

TEST_GROUP_RUNNER(lvd_init_lvd_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_init_lvd_Test, TG006_001);
    RUN_TEST_CASE(lvd_init_lvd_Test, TG006_002);
    RUN_TEST_CASE(lvd_init_lvd_Test, TG006_003);
    RUN_TEST_CASE(lvd_init_lvd_Test, TG006_004);
#endif
}

TEST_GROUP_RUNNER( lvd_start_lvd_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    //RUN_TEST_CASE( lvd_start_lvd_Test, TG007_001);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_002);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_003);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_004);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_005);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_006);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_007);
//    RUN_TEST_CASE( lvd_start_lvd_Test, TG007_008);
#endif
}

TEST_GROUP_RUNNER(lvd_stop_int_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_001);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_002);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_003);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_004);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_005);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_006);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_007);
    RUN_TEST_CASE(lvd_stop_int_Test, TG008_008);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_param_ch_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_param_ch_Test, TG009_001);
    RUN_TEST_CASE(lvd_hw_check_param_ch_Test, TG009_003);
    RUN_TEST_CASE(lvd_hw_check_param_ch_Test, TG009_005);
#else
#if (LVD_CFG_CHANNEL_1_USED == 0)
    RUN_TEST_CASE(lvd_hw_check_param_ch_Test, TG009_002);
#endif
#if (LVD_CFG_CHANNEL_2_USED == 0)
    RUN_TEST_CASE(lvd_hw_check_param_ch_Test, TG009_004);
#endif
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_ptr_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_ptr_Test, TG010_001);
    RUN_TEST_CASE(lvd_hw_check_ptr_Test, TG010_002);
    RUN_TEST_CASE(lvd_hw_check_ptr_Test, TG010_003);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_already_open_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_already_open_Test, TG011_001);
    RUN_TEST_CASE(lvd_hw_check_already_open_Test, TG011_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_not_opened_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE) && (LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 != LVD_INVALID_VALUE))
//    RUN_TEST_CASE(lvd_hw_check_not_opened_Test, TG012_001);
//    RUN_TEST_CASE(lvd_hw_check_not_opened_Test, TG012_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_getstatus_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_getstatus_Test, TG013_001);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_clearstatus_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_clearstatus_Test, TG014_001);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_param_open_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_001);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_002);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_003);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_004);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_005);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_006);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_007);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_008);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_009);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_010);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_011);
    RUN_TEST_CASE(lvd_hw_check_param_open_Test, TG015_012);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_check_loco_limitation_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_check_loco_limitation_Test, TG016_001);
//    RUN_TEST_CASE(lvd_hw_check_loco_limitation_Test, TG016_002);
//    RUN_TEST_CASE(lvd_hw_check_loco_limitation_Test, TG016_003);
//    RUN_TEST_CASE(lvd_hw_check_loco_limitation_Test, TG016_004);
    //RUN_TEST_CASE(lvd_hw_check_loco_limitation_Test, TG016_005);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_clear_lvd_status_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_clear_lvd_status_Test, TG017_001);
    RUN_TEST_CASE(lvd_hw_clear_lvd_status_Test, TG017_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_get_lvd_status_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_get_lvd_status_Test, TG018_001);
    RUN_TEST_CASE(lvd_hw_get_lvd_status_Test, TG018_002);
    RUN_TEST_CASE(lvd_hw_get_lvd_status_Test, TG018_003);
    RUN_TEST_CASE(lvd_hw_get_lvd_status_Test, TG018_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_set_level_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_set_level_Test, TG019_001);
    RUN_TEST_CASE(lvd_hw_set_level_Test, TG019_003);
#else
#if (LVD_VOLTAGE_LEVEL_VALUE_CH1 == LVD_INVALID_VALUE)
    RUN_TEST_CASE(lvd_hw_set_level_Test, TG019_002);
#endif
#if (LVD_VOLTAGE_LEVEL_VALUE_CH2 == LVD_INVALID_VALUE)
    RUN_TEST_CASE(lvd_hw_set_level_Test, TG019_004);
#endif
#endif
}

TEST_GROUP_RUNNER(lvd_hw_set_trigger_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_001);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_002);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_003);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_004);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_005);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_006);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_007);
    RUN_TEST_CASE(lvd_hw_set_trigger_Test, TG020_008);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_set_target_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_set_target_Test, TG021_001);
    RUN_TEST_CASE(lvd_hw_set_target_Test, TG021_002);
    RUN_TEST_CASE(lvd_hw_set_target_Test, TG021_003);
    RUN_TEST_CASE(lvd_hw_set_target_Test, TG021_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_select_reset_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_select_reset_Test, TG022_001);
    RUN_TEST_CASE(lvd_hw_select_reset_Test, TG022_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_setup_reset_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_setup_reset_Test, TG023_001);
    RUN_TEST_CASE(lvd_hw_setup_reset_Test, TG023_002);
    RUN_TEST_CASE(lvd_hw_setup_reset_Test, TG023_003);
    RUN_TEST_CASE(lvd_hw_setup_reset_Test, TG023_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_select_int_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_select_int_Test, TG024_001);
    RUN_TEST_CASE(lvd_hw_select_int_Test, TG024_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_select_mi_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_select_mi_Test, TG025_001);
    RUN_TEST_CASE(lvd_hw_select_mi_Test, TG025_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_select_nmi_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_select_nmi_Test, TG026_001);
    RUN_TEST_CASE(lvd_hw_select_nmi_Test, TG026_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_setup_dfilter_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 != LVD_INVALID_VALUE)
//    RUN_TEST_CASE(lvd_hw_setup_dfilter_Test, TG027_001);
//    RUN_TEST_CASE(lvd_hw_setup_dfilter_Test, TG027_002);
#else
    //RUN_TEST_CASE(lvd_hw_setup_dfilter_Test, TG027_003);
#endif
#endif
}

TEST_GROUP_RUNNER(lvd_hw_get_circuit_enable_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_get_circuit_enable_Test, TG028_001);
    RUN_TEST_CASE(lvd_hw_get_circuit_enable_Test, TG028_002);
    RUN_TEST_CASE(lvd_hw_get_circuit_enable_Test, TG028_003);
    RUN_TEST_CASE(lvd_hw_get_circuit_enable_Test, TG028_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_get_reset_int_enable_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_get_reset_int_enable_Test, TG029_001);
    RUN_TEST_CASE(lvd_hw_get_reset_int_enable_Test, TG029_002);
    RUN_TEST_CASE(lvd_hw_get_reset_int_enable_Test, TG029_003);
    RUN_TEST_CASE(lvd_hw_get_reset_int_enable_Test, TG029_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_get_dfilter_enable_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
//	#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 != LVD_INVALID_VALUE)
//		RUN_TEST_CASE(lvd_hw_get_dfilter_enable_Test, TG030_001);
//		RUN_TEST_CASE(lvd_hw_get_dfilter_enable_Test, TG030_002);
//		RUN_TEST_CASE(lvd_hw_get_dfilter_enable_Test, TG030_003);
//		RUN_TEST_CASE(lvd_hw_get_dfilter_enable_Test, TG030_004);
//	#endif
#endif
}

TEST_GROUP_RUNNER(lvd_hw_enable_output_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_enable_output_Test, TG031_001);
    RUN_TEST_CASE(lvd_hw_enable_output_Test, TG031_002);
    RUN_TEST_CASE(lvd_hw_enable_output_Test, TG031_003);
    RUN_TEST_CASE(lvd_hw_enable_output_Test, TG031_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_enable_circuit_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_enable_circuit_Test, TG032_001);
    RUN_TEST_CASE(lvd_hw_enable_circuit_Test, TG032_002);
    RUN_TEST_CASE(lvd_hw_enable_circuit_Test, TG032_003);
    RUN_TEST_CASE(lvd_hw_enable_circuit_Test, TG032_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_enable_reset_int_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_enable_reset_int_Test, TG033_001);
    RUN_TEST_CASE(lvd_hw_enable_reset_int_Test, TG033_002);
    RUN_TEST_CASE(lvd_hw_enable_reset_int_Test, TG033_003);
    RUN_TEST_CASE(lvd_hw_enable_reset_int_Test, TG033_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_enable_dfilter_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
//	#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 != LVD_INVALID_VALUE)
//	RUN_TEST_CASE(lvd_hw_enable_dfilter_Test, TG034_001);
//    RUN_TEST_CASE(lvd_hw_enable_dfilter_Test, TG034_002);
//    RUN_TEST_CASE(lvd_hw_enable_dfilter_Test, TG034_003);
//    RUN_TEST_CASE(lvd_hw_enable_dfilter_Test, TG034_004);
//	#endif
#endif
}

TEST_GROUP_RUNNER(lvd_hw_enable_mi_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_enable_mi_Test, TG035_001);
    RUN_TEST_CASE(lvd_hw_enable_mi_Test, TG035_002);
    RUN_TEST_CASE(lvd_hw_enable_mi_Test, TG035_003);
    RUN_TEST_CASE(lvd_hw_enable_mi_Test, TG035_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_enable_nmi_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_enable_nmi_Test, TG036_001);
    RUN_TEST_CASE(lvd_hw_enable_nmi_Test, TG036_002);
    RUN_TEST_CASE(lvd_hw_enable_nmi_Test, TG036_003);
    RUN_TEST_CASE(lvd_hw_enable_nmi_Test, TG036_004);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_dummy_read_dfilter_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
//	#if (LVD_CFG_SAMPLING_CLOCK_CHANNEL_2 != LVD_INVALID_VALUE)
//		RUN_TEST_CASE(lvd_hw_dummy_read_dfilter_Test, TG037_001);
//		RUN_TEST_CASE(lvd_hw_dummy_read_dfilter_Test, TG037_002);
//	#endif
#endif
}

TEST_GROUP_RUNNER(lvd_hw_dummy_read_circuit_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_dummy_read_circuit_Test, TG038_001);
    RUN_TEST_CASE(lvd_hw_dummy_read_circuit_Test, TG038_002);
#endif
}

TEST_GROUP_RUNNER(lvd_hw_dummy_read_output_Test)
{
#if ((LVD_CFG_CHANNEL_1_USED == 1) && (LVD_CFG_CHANNEL_2_USED == 1) && (LVD_VOLTAGE_LEVEL_VALUE_CH1 != LVD_INVALID_VALUE) && (LVD_VOLTAGE_LEVEL_VALUE_CH2 != LVD_INVALID_VALUE))
    RUN_TEST_CASE(lvd_hw_dummy_read_output_Test, TG039_001);
    RUN_TEST_CASE(lvd_hw_dummy_read_output_Test, TG039_002);
#endif
}


/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static void RunAllTests(void);

/***********************************************************************************************************************
* Function Name: RunAllTests
* Description  : Call test groups
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
static void RunAllTests(void)
{
    printf("RUN TEST GROUP: R_LVD_GetVersion_Test\n");
    RUN_TEST_GROUP(R_LVD_GetVersion_Test);
    printf("END TEST GROUP: R_LVD_GetVersion_Test\n\n");

    printf("RUN TEST GROUP: R_LVD_Open_Test\n");
    RUN_TEST_GROUP(R_LVD_Open_Test);
    printf("END TEST GROUP: R_LVD_Open_Test\n\n");

    printf("RUN TEST GROUP: R_LVD_Close_Test\n");
    RUN_TEST_GROUP(R_LVD_Close_Test);
    printf("END TEST GROUP: R_LVD_Close_Test\n\n");

    printf("RUN TEST GROUP: R_LVD_GetStatus_Test\n");
    RUN_TEST_GROUP(R_LVD_GetStatus_Test);
    printf("END TEST GROUP: R_LVD_GetStatus_Test\n\n");

    printf("RUN TEST GROUP: R_LVD_ClearStatus_Test\n");
    RUN_TEST_GROUP(R_LVD_ClearStatus_Test);
    printf("END TEST GROUP: R_LVD_ClearStatus_Test\n\n");

    printf("RUN TEST GROUP: lvd_init_lvd_Test\n");
    RUN_TEST_GROUP(lvd_init_lvd_Test);
    printf("END TEST GROUP: lvd_init_lvd_Test\n\n");

    printf("RUN TEST GROUP:  lvd_start_lvd_Test\n");
    RUN_TEST_GROUP( lvd_start_lvd_Test);
    printf("END TEST GROUP:  lvd_start_lvd_Test\n\n");

    printf("RUN TEST GROUP: lvd_stop_int_Test\n");
    RUN_TEST_GROUP(lvd_stop_int_Test);
    printf("END TEST GROUP: lvd_stop_int_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_param_ch_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_param_ch_Test);
    printf("END TEST GROUP: lvd_hw_check_param_ch_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_ptr_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_ptr_Test);
    printf("END TEST GROUP: lvd_hw_check_ptr_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_already_open_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_already_open_Test);
    printf("END TEST GROUP: lvd_hw_check_already_open_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_not_opened_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_not_opened_Test);
    printf("END TEST GROUP: lvd_hw_check_not_opened_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_getstatus_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_getstatus_Test);
    printf("END TEST GROUP: lvd_hw_check_getstatus_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_clearstatus_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_clearstatus_Test);
    printf("END TEST GROUP: lvd_hw_check_clearstatus_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_param_open_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_param_open_Test);
    printf("END TEST GROUP: lvd_hw_check_param_open_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_check_loco_limitation_Test\n");
    RUN_TEST_GROUP(lvd_hw_check_loco_limitation_Test);
    printf("END TEST GROUP: lvd_hw_check_loco_limitation_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_clear_lvd_status_Test\n");
    RUN_TEST_GROUP(lvd_hw_clear_lvd_status_Test);
    printf("END TEST GROUP: lvd_hw_clear_lvd_status_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_get_lvd_status_Test\n");
    RUN_TEST_GROUP(lvd_hw_get_lvd_status_Test);
    printf("END TEST GROUP: lvd_hw_get_lvd_status_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_set_level_Test\n");
    RUN_TEST_GROUP(lvd_hw_set_level_Test);
    printf("END TEST GROUP: lvd_hw_set_level_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_set_trigger_Test\n");
    RUN_TEST_GROUP(lvd_hw_set_trigger_Test);
    printf("END TEST GROUP: lvd_hw_set_trigger_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_set_target_Test\n");
    RUN_TEST_GROUP(lvd_hw_set_target_Test);
    printf("END TEST GROUP: lvd_hw_set_target_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_select_reset_Test\n");
    RUN_TEST_GROUP(lvd_hw_select_reset_Test);
    printf("END TEST GROUP: lvd_hw_select_reset_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_setup_reset_Test\n");
    RUN_TEST_GROUP(lvd_hw_setup_reset_Test);
    printf("END TEST GROUP: lvd_hw_setup_reset_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_select_int_Test\n");
    RUN_TEST_GROUP(lvd_hw_select_int_Test);
    printf("END TEST GROUP: lvd_hw_select_int_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_select_mi_Test\n");
    RUN_TEST_GROUP(lvd_hw_select_mi_Test);
    printf("END TEST GROUP: lvd_hw_select_mi_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_select_nmi_Test\n");
    RUN_TEST_GROUP(lvd_hw_select_nmi_Test);
    printf("END TEST GROUP: lvd_hw_select_nmi_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_setup_dfilter_Test\n");
    RUN_TEST_GROUP(lvd_hw_setup_dfilter_Test);
    printf("END TEST GROUP: lvd_hw_setup_dfilter_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_get_circuit_enable_Test\n");
    RUN_TEST_GROUP(lvd_hw_get_circuit_enable_Test);
    printf("END TEST GROUP: lvd_hw_get_circuit_enable_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_get_reset_int_enable_Test\n");
    RUN_TEST_GROUP(lvd_hw_get_reset_int_enable_Test);
    printf("END TEST GROUP: lvd_hw_get_reset_int_enable_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_get_dfilter_enable_Test\n");
    RUN_TEST_GROUP(lvd_hw_get_dfilter_enable_Test);
    printf("END TEST GROUP: lvd_hw_get_dfilter_enable_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_enable_output_Test\n");
    RUN_TEST_GROUP(lvd_hw_enable_output_Test);
    printf("END TEST GROUP: lvd_hw_enable_output_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_enable_circuit_Test\n");
    RUN_TEST_GROUP(lvd_hw_enable_circuit_Test);
    printf("END TEST GROUP: lvd_hw_enable_circuit_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_enable_reset_int_Test\n");
    RUN_TEST_GROUP(lvd_hw_enable_reset_int_Test);
    printf("END TEST GROUP: lvd_hw_enable_reset_int_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_enable_dfilter_Test\n");
    RUN_TEST_GROUP(lvd_hw_enable_dfilter_Test);
    printf("END TEST GROUP: lvd_hw_enable_dfilter_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_enable_mi_Test\n");
    RUN_TEST_GROUP(lvd_hw_enable_mi_Test);
    printf("END TEST GROUP: lvd_hw_enable_mi_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_enable_nmi_Test\n");
    RUN_TEST_GROUP(lvd_hw_enable_nmi_Test);
    printf("END TEST GROUP: lvd_hw_enable_nmi_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_dummy_read_dfilter_Test\n");
    RUN_TEST_GROUP(lvd_hw_dummy_read_dfilter_Test);
    printf("END TEST GROUP: lvd_hw_dummy_read_dfilter_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_dummy_read_circuit_Test\n");
    RUN_TEST_GROUP(lvd_hw_dummy_read_circuit_Test);
    printf("END TEST GROUP: lvd_hw_dummy_read_circuit_Test\n\n");

    printf("RUN TEST GROUP: lvd_hw_dummy_read_output_Test\n");
    RUN_TEST_GROUP(lvd_hw_dummy_read_output_Test);
    printf("END TEST GROUP: lvd_hw_dummy_read_output_Test\n\n");
}

void main(void)
{
    UnityMain(0, 0, RunAllTests);

    while(1)
    {
        /* Infinite loop. */
    }
}
